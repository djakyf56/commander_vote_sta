package cn.blockforge.generated.nbt6commandervotesta.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 指挥官系统配置中心（JSON + // 中文注释）。
 * 六个模块均可单独开关；等级限制、冷却、音效、粒子、增益、战利品、自定义 NBT 全部可改。
 * 配置文件里的 // 注释会被自动剥掉再解析；缺的字段在加载时自动按默认值补全。
 */
public class CommanderConfig {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static CommanderConfig INSTANCE = new CommanderConfig();

    // ===== 六个模块的开关（对应六个可选模块） =====
    public boolean moduleIdentity = true;    // 模块1：指挥官身份与投票管理
    public boolean moduleLevelLimit = true;  // 模块2：技能等级与NBT配置中心
    public boolean moduleScan = true;        // 模块3：侦察扫描
    public boolean moduleAirdrop = true;     // 模块4：空投补给与烟雾掩护
    public boolean moduleSmoke = true;       // 模块4：空投补给与烟雾掩护
    public boolean moduleArtillery = true;   // 模块5：炮击支援
    public boolean moduleAssault = true;     // 模块6：全军突击与战略撤退
    public boolean moduleRetreat = true;     // 模块6：全军突击与战略撤退

    public BuffCfg retreat = new BuffCfg();

    // ===== 投票 =====
    public VoteCfg vote = new VoteCfg();
    public static class VoteCfg {
        public int durationSeconds = 60;
    }

    // ===== 等级限制（默认开启；等级默认读记分榜，不再用原版经验） =====
    public LevelsCfg levels = new LevelsCfg();
    public static class LevelsCfg {
        public boolean enabled = true;
        public int scan = 5;
        public int airdrop = 10;
        public int smoke = 15;
        public int artillery = 20;
        public int assault = 25;
        public int retreat = 30;
        /** 等级来源：scoreboard=读记分榜（默认）；xp=原版经验等级（旧行为） */
        public String source = "scoreboard";
        /** 记分榜目标（计分项）名，可自定义。玩家的分数就是他的"等级"，
         *  用 /scoreboard players add <玩家> <目标名> <分数> 就能给他升级 */
        public String scoreboardObjective = "commander_level";
        /** true=目标不存在时自动按 dummy 类型创建（默认）；false=目标不存在时一律按 0 分处理 */
        public boolean autoCreateObjective = true;

        public boolean useScoreboard() {
            String s = source == null ? "" : source.trim().toLowerCase(java.util.Locale.ROOT);
            return !s.equals("xp") && !s.equals("experience");
        }
    }

    // ===== 技能点（使用技能除了要够等级，还要消耗记分榜里的技能点） =====
    public SkillPointsCfg skillPoints = new SkillPointsCfg();
    public static class SkillPointsCfg {
        public boolean enabled = true;
        /** 各技能消耗的技能点数 */
        public int scan = 1;
        public int airdrop = 2;
        public int smoke = 2;
        public int artillery = 3;
        public int assault = 3;
        public int retreat = 2;
        /** 记分榜目标（计分项）名，可自定义。玩家的分数就是他的"技能点余额"，
         *  用 /scoreboard players add <玩家> <目标名> <分数> 就能给他充技能点 */
        public String scoreboardObjective = "commander_points";
        /** true=目标不存在时自动按 dummy 类型创建（默认）；false=目标不存在时一律按 0 点处理 */
        public boolean autoCreateObjective = true;

        public boolean enabledSafe() {
            return enabled;
        }
    }

    // ===== 连发惩罚（60 秒窗口内释放超过 N 个技能，从第 N+1 个起消耗加倍） =====
    public PenaltyCfg penalty = new PenaltyCfg();
    public static class PenaltyCfg {
        public boolean enabled = true;
        /** 统计窗口（秒）：在这个窗口内数玩家一共释放了几个技能 */
        public int windowSeconds = 60;
        /** 窗口内允许正常消耗的技能个数；超过它的那次起消耗按 multiplier 加倍（默认 2 = 第 3 个起加倍） */
        public int allowedCount = 2;
        /** 惩罚倍率：触发的技能点消耗 = 原消耗 × multiplier（2.0 = 加倍） */
        public double multiplier = 2.0;
    }

    // ===== 技能轮盘中心提示（全部可自定义；留空 = 用内置文案） =====
    public WheelCfg wheel = new WheelCfg();
    public static class WheelCfg {
        /** 悬停状态时轮盘中心的顶部标题 */
        public String centerTitle = "";
        /** 不悬停时中心盘的统计行，{ready}=就绪技能数，{total}=技能总数 */
        public String centerSummary = "";
        /** 不悬停时中心盘底部的操作提示 */
        public String centerHint = "";
        /** 悬停时中心盘的状态行：技能就绪 */
        public String statusReady = "";
        /** 悬停时中心盘的状态行：冷却中，{seconds}=剩余秒数 */
        public String statusCooldown = "";
        /** 悬停时中心盘的状态行：等级不足，{required}=需要等级，{current}=当前等级（记分榜模式下"级"就是分数，可自行改成"分"） */
        public String statusLevel = "";
        /** 悬停时中心盘的状态行：技能点不足，{cost}=需要技能点，{current}=当前技能点 */
        public String statusPoints = "";
        /** 悬停时中心盘的状态行：技能模块被关闭 */
        public String statusModuleOff = "";
        /** 悬停时中心盘的状态行：还不是指挥官（也显示在顶部横条） */
        public String statusNotCommander = "";
        /** 悬停时中心盘的状态行：连发惩罚生效中，{mult}=消耗倍率 */
        public String statusPenalty = "";
        /** 不悬停时中心盘显示的技能点余额行，{points}=当前技能点 */
        public String centerPoints = "";
        /** 悬停时中心盘的状态行：系统已关闭（也显示在顶部横条） */
        public String statusSystemOff = "";
        /** 六个技能在轮盘中心显示的名字/短名/说明，留空 = 用内置文案 */
        public SkillText scan = new SkillText();
        public SkillText airdrop = new SkillText();
        public SkillText smoke = new SkillText();
        public SkillText artillery = new SkillText();
        public SkillText assault = new SkillText();
        public SkillText retreat = new SkillText();
    }

    /** 轮盘上单个技能的可自定义文字：name=完整名（中心盘显示），shortName=短名（扇区上显示），desc=说明 */
    public static class SkillText {
        public String name = "";
        public String shortName = "";
        public String desc = "";
    }

    // ===== 冷却（秒） =====
    public CooldownsCfg cooldowns = new CooldownsCfg();
    public static class CooldownsCfg {
        /** 释放任意技能后，所有技能共同进入的公共冷却（tick，20 tick = 1 秒；默认 30 = 1.5 秒），0=关闭 */
        public int globalTicks = 30;
        public int scan = 30;
        public int airdrop = 120;
        public int smoke = 90;
        public int artillery = 120;
        public int assault = 180;
        public int retreat = 180;
        public int designator = 120; // 炮击坐标仪（工具包方案）
    }

    // ===== 侦察扫描 =====
    public ScanCfg scan = new ScanCfg();
    public static class ScanCfg {
        public double radius = 64.0;
        public int glowSeconds = 10;
        /** 谁能看见发光轮廓：team=仅指挥官与同队玩家（默认）；self=仅指挥官本人；all=全服可见（原版发光效果） */
        public String glowVisibility = "team";
        public String sound = "minecraft:block.note_block.pling";
        public String particle = "minecraft:end_rod";
    }

    // ===== 空投补给 =====
    public AirdropCfg airdrop = new AirdropCfg();
    public static class AirdropCfg {
        public int height = 24;            // 补给箱从落点上方多少格开始下落
        public int beamSeconds = 5;        // 信标光柱提示多久后开始空投
        public String sound = "minecraft:block.beacon.activate";
        public String particle = "minecraft:end_rod";
        /** 补给箱每 tick（1/20 秒）下落多少格，越小落得越慢越有仪式感 */
        public double fallSpeed = 0.35;
        /** 补给箱下落时的拖尾/降落伞粒子 id */
        public String trailParticle = "minecraft:cloud";
        /** 下落过程中每秒播放一次的风声音效 id，留空则不播 */
        public String fallSound = "minecraft:item.elytra.flying";
        /** 补给箱落地放置时播放的音效 id，留空则不播 */
        public String landSound = "minecraft:entity.generic.place";
        public List<LootEntry> loot = defaultLoot();
        /** 整箱附加的自定义 NBT（原样写入箱子的 BlockEntity 标签） */
        public String crateNbt = "";
        /** 落点光柱的颜色，6 位十六进制 RGB，例如 FF8800 橙色、00FF66 绿色，留空或不合法则为白色 */
        public String beamColor = "FFFFFF";
        /** 落地后放下的箱子多少秒后自动消失（里面的物品会掉在地上）；0=一直留着。只在 landAsItems=false 时生效 */
        public int chestSeconds = 120;
        /** true（默认）=落地后直接生成掉落物，不出现箱子；false=落地放一个装满的箱子（旧行为） */
        public boolean landAsItems = true;
        /**
         * 空投资源类型清单（轮盘里按空投键后弹出的 2 级菜单选项，按顺序显示）。
         * id：类型标识（菜单选择后随空投请求一起发给服务器）；
         * name：菜单上显示的名字（留空用 id）；desc：菜单上的一行说明；
         * entity：落地时生成的实体 id（支持其他模组，例如载具维修箱）。
         * entity 留空 = 走物资箱的现有逻辑（落地变掉落物/箱子）。
         */
        public List<SupplyTypeEntry> types = defaultSupplyTypes();
        /** 解析 beamColor 为 0xRRGGBB 整数，写错时回退到白色 */
        public int beamColorRgb() {
            try {
                String hex = beamColor == null ? "" : beamColor.trim().replace("#", "");
                if (hex.length() == 6) return Integer.parseInt(hex, 16) & 0xFFFFFF;
            } catch (NumberFormatException ignored) {
            }
            return 0xFFFFFF;
        }
    }

    /** 空投资源类型（2 级菜单的一个选项）：物资箱 = 现有逻辑；载具维修箱 = 在 entity 里填实体 id */
    public static class SupplyTypeEntry {
        public String id = "supply";
        /** 菜单上显示的名字，留空 = 用 id */
        public String name = "";
        /** 菜单上的一行说明 */
        public String desc = "";
        /** 落地时生成的实体 id（支持其他模组）。留空 = 按物资箱的现有逻辑处理 */
        public String entity = "";
        /** 生成 entity 时附带的自定义 NBT（SNBT 文本，如 {TankOwner:"abc",Fuel:500f}），仅在 entity 非空时生效 */
        public String nbt = "";
    }

    /**
     * 空投载具的出厂默认：卓越前线(superbwarfare) 的 sodayo_pick_up 载具。
     * NBT 就是 /data get 导出的原文，DogTagIcon 等全部原样保留
     * （已用游戏自己的 TagParser 实测通过）；唯一删掉的是 Rotation ——
     * 召唤时会按释放者视线自动补四方向朝向，写死反而锁死朝向。
     */
    public static final String DEFAULT_VEHICLE_ENTITY = "superbwarfare:sodayo_pick_up";
    public static final String DEFAULT_VEHICLE_NBT =
            "{TowingUUID: \"\", LeftWheelHealth: 50.0f, ChargeProgress: 0.0f, Invulnerable: 0b, MainEngineHealth: 50.0f, RightWheelDamaged: 0b, LastAttacker: \"undefined\", SelectedWeapon: [I; 0, 0, 0, 0, 0, 0, 0, 0], FallDistance: 0.0f, CanUpdate: 1b, TurretYRotLock: 0.0f, GearRot: 0.0f, HoverMode: 0b, ServerYaw: 0.0f, TowingUUIDs: [], TowedByUUID: \"\", DecoyReloadCoolDown: 500, Air: 300s, SubEngineDamaged: 0b, TurretBurned: 0b, RightWheelHealth: 50.0f, LoiterR: 400.0f, TurretDamaged: 0b, LoiterX: 0.0f, Inventory: {Size: 78, Items: [{Slot: 0, id: \"superbwarfare:medium_battery_pack\", Count: 1b, tag: {Energy: 5000000}}]}, LoiterZ: 0.0f, LoiterY: 318.0f, PropellerRot: 0.0f, ServerPitch: 0.0f, GunXRot: 0.0f, LastDriver: \"undefined\", IsWreck: 0b, PortalCooldown: 0, TurretHealth: 50.0f, GearUp: 0b, DogTagIcon: [[I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [I; -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]], MainEngineDamaged: 0b, Locked: 0b, Energy: 5000000, LoiterActive: 0b, TurretYRot: 0.0f, SubEngineHealth: 50.0f, Motion: [0.0d, 0.0d, 0.0d], Health: 175.0f, GunYRot: 0.0f, OnGround: 1b, DecoyCount: 0, TurretBurnTimer: 0, SympatheticDetonated: 0b, LeftWheelDamaged: 0b, Fire: -1s, Power: 0.0f, TurretXRot: 0.0f}";

    private static List<SupplyTypeEntry> defaultSupplyTypes() {
        SupplyTypeEntry supply = new SupplyTypeEntry();
        supply.id = "supply";
        supply.name = "物资箱";
        supply.desc = "常规补给：落地后变成掉落物";
        SupplyTypeEntry repair = new SupplyTypeEntry();
        repair.id = "repair";
        repair.name = "载具维修箱";
        repair.desc = "落地后生成 entity 里填写的实体（默认留空，等同物资箱）";
        SupplyTypeEntry vehicle = new SupplyTypeEntry();
        vehicle.id = "vehicle";
        vehicle.name = "空投载具";
        vehicle.desc = "落地生成 entity 里填写的载具实体，面向释放者视线方向（只认东南西北）";
        vehicle.entity = DEFAULT_VEHICLE_ENTITY;
        vehicle.nbt = DEFAULT_VEHICLE_NBT;
        return new ArrayList<>(List.of(supply, repair, vehicle));
    }

    /** 按 id 找空投资源类型；找不到返回 null */
    public SupplyTypeEntry supplyType(String id) {
        if (airdrop.types == null) return null;
        String want = id == null ? "" : id.trim();
        for (SupplyTypeEntry t : airdrop.types) {
            if (t != null && t.id != null && t.id.trim().equalsIgnoreCase(want)) return t;
        }
        return null;
    }

    // ===== 烟雾掩护 =====
    public SmokeCfg smoke = new SmokeCfg();
    public static class SmokeCfg {
        public double width = 6.0;
        public double height = 4.0;
        public int durationSeconds = 20;
        public double movePerTick = 0.06;  // 雾墙每 tick 前进距离
        public int speedAmplifier = 0;     // 同队玩家速度增益等级（0=速度I）
        public int jumpAmplifier = 0;      // 跳跃提升等级（0=跳跃I）
        public String particle = "minecraft:campfire_cosy_smoke";
        public String sound = "minecraft:item.elytra.flying";
        /**
         * 雾墙技能生成的自定义实体 id（例如 minecraft:area_effect_cloud 或其他模组的实体）。
         * 留空 = 不生成任何实体（默认就是这个状态，技能只有效果音）。
         * 设置后：使用技能时在准心位置生成该实体，先出中心一面，再向左右逐层展开，朝向跟随视线。
         */
        public String customEntity = "";
        /** 自定义实体附加的 NBT（原样写入实体标签，Position 和 UUID 除外，留空则不加） */
        public String customEntityNbt = "";
        /** 雾墙生成在准心指向的位置（方块/实体表面），这是探测的最远距离（格），探测不到就落在视线最远处 */
        public double spawnRange = 32.0;
        /** 准星指的是方块时，雾墙整体向上抬几格（默认 3，抬高一点别嵌进地面）；准星指实体/探测不到时不抬 */
        public double upOffset = 3.0;
        /**
         * 雾墙总面数（包含中间那一面）：写了它就严格按它来，比如 3=中间一面+左右各一面，5=中间+左右各两面；
         * 奇数时左右对称，偶数时右侧多一面。0=不手填，按下面的 width/spreadStep 自动算。
         */
        public int count = 0;
        /** 左右展开时相邻两面雾墙之间的间距（格） */
        public double spreadStep = 1.5;
        /** 左右展开的速度：每隔多少 tick（1/20 秒）向左右各多展开一层，0=不做过程、左右一次性全部出现 */
        public int spreadIntervalTicks = 4;
        /** 单侧最多展开多少层（只在 count=0 自动按宽度算时生效），防止一口气生成太多实体 */
        public int maxSpreadLayers = 6;
        /**
         * 不穿墙（默认开）：雾墙向左右展开时，中心与某一层之间隔着方块就停止该方向的展开
         * （墙被建筑挡住时不会穿到建筑里面去）；另一方向不受影响。关掉则照旧无视方块铺满。
         */
        public boolean blockWalls = true;
    }

    // ===== 炮击支援 =====
    public ArtilleryCfg artillery = new ArtilleryCfg();
    public static class ArtilleryCfg {
        /** direct=直接天降炮击；toolkit=发放炮击工具包 */
        public String mode = "direct";
        public int strikes = 5;
        public float radius = 3.0F;
        /** false=不破坏方块（默认）；true=会破坏方块。关闭时自动不点火：火方块会烧毁木板等方块，等于变相破坏 */
        public boolean destroyBlocks = false;
        public boolean fire = false;
        public int intervalTicks = 15;     // 每发间隔
        public double scatter = 3.0;       // 落点散布半径
        /** 落点方式：scatter=每发在散布半径内随机落点（默认）；same=全部打同一位置（准星正中心） */
        public String landing = "scatter";
        public String sound = "minecraft:entity.generic.explode";
        public String particle = "minecraft:explosion_emitter";
        public String smokeParticle = "minecraft:campfire_cosy_smoke";
        /** 每发炮弹落地前多少 tick（1/20 秒）开始显示下坠弹道，0=不显示；间隔再短也能看出是一发一发打的 */
        public int trailTicks = 10;
        /** 炮弹下坠弹道粒子 id */
        public String trailParticle = "minecraft:large_smoke";
        /** toolkit 模式：坐标仪附加的自定义 NBT，原样保留 */
        public String toolkitNbt = "";
        public int toolkitCount = 1;
        /** toolkit 模式：随坐标仪一起发放的额外物品（例如其他模组的火炮遥控器、炮弹） */
        public List<LootEntry> toolkitExtraItems = new ArrayList<>();
        /**
         * 每发炮弹的最大伤害（1 = 半颗心）：爆心处全额命中，随距离线性衰减到边缘的 30%。
         * 写 -1 = 完全按原版爆炸伤害计算（原版伤害由爆炸半径决定，没法单独控制）。
         */
        public float damage = 8.0F;
        /** 自定义伤害的作用半径（格）；<=0 时用爆炸半径 radius */
        public double damageRadius = 0.0;
        /** 自定义伤害附带击退的力度，0=不击退 */
        public double knockback = 0.5;
        /**
         * 炮击是否伤害载具等"非生物实体"（[SBW]卓越前线 的载具、原版的船/矿车/挂画等）。
         * 这类实体的血量记在实体自己身上，走实体自己的受伤判定；false 则炮击只打生物。
         */
        public boolean hitVehicles = true;
        /**
         * 炮击对"模组载具"（实体 id 命名空间不是 minecraft 的非生物实体，
         * [SBW]卓越前线 的坦克/步战车/无人机等都在其中）的伤害倍率。
         * 默认 3.0 = 300% 伤害；1.0 = 无加成；写 2.5 就是 250%，以此类推。
         * 原版的船/矿车/挂画等非生物实体不受这个加成，只吃基础伤害。
         */
        public double vehicleBonusMultiplier = 3.0;
        /**
         * 不穿墙（默认开）：一、每发炮弹垂直落下时，落点吸附到该列从上往下第一个方块的上表面——
         * 瞄点上方有屋顶时炮弹炸在屋顶上，不会穿进室内（随机散布的落点同样处理）；
         * 二、自定义伤害模式下，爆心与目标生物/载具之间隔着方块
         * （墙、掩体、地板）就不对该目标造成伤害——躲在屋里不会被隔着墙打死。
         * 关掉则恢复旧行为：落点就是瞄点高度，作用半径内不分遮挡一律结算。
         */
        public boolean blockWalls = true;
        /**
         * 炮弹来袭方向：
         *  · vertical（默认）= 从落点正上方垂直砸下来，就是原来的样子；
         *  · mortar = 像迫击炮那样从斜上方打过来：弹道起点在落点斜上方（高度仍是 20 格，
         *    水平距离按 mortarAngle 算出），炮弹沿这条斜线飞进来，同样不能穿墙——
         *    斜线上先撞到屋顶/墙就在撞击面上炸。
         */
        public String approach = "vertical";
        /** 迫击炮弹道的入射仰角（度）：45=斜着 45 度打来（最直观），越大越陡，接近 80 就几乎垂直；只在 approach=mortar 时生效 */
        public double mortarAngle = 45.0;
        /**
         * 迫击炮从哪个水平方向打来（只认四方向）：
         *  · look（默认）= 跟着释放者视线：你朝哪看，炮弹就从你**身后**越过头顶飞向落点
         *    （等于己方阵地在你背后，看着最自然）；
         *  · south / west / north / east = 固定从该方位打过来。
         * 只在 approach=mortar 时生效。
         */
        public String mortarBearing = "look";
        /**
         * 摄像机摇晃强度（爆炸特效）：1.0 = 爆心附近明显一晃，远处按距离平方衰减；0=完全不晃。
         * 只动画面（相机角度），不会推动玩家、不影响任何游戏数值。
         */
        public double shakeIntensity = 0.85;
        /** 摄像机摇晃的波及范围（格）：超出这个距离完全不晃 */
        public double shakeRange = 40.0;
        /** 摄像机摇晃持续多少 tick（20 tick = 1 秒）：前 35% 保持满幅，之后逐渐停住 */
        public int shakeTicks = 26;
        /** 隔着墙/屋顶时的震感系数（0.4 = 只震四成）：1=不衰减，0=隔墙完全不晃 */
        public double shakeWallMuffle = 0.4;
    }

    // ===== 提示文本（全部可改；{xxx} 是占位符，游戏会自动替换成实际数值） =====
    public MessagesCfg messages = new MessagesCfg();
    public static class MessagesCfg {
        /** 所有提示共用的开头，比如 §b[指挥官] ；不想要前缀就留空 */
        public String prefix = "§b[指挥官] ";
        public String help = """
                §b===== 指挥官系统 =====
                §e/commander vote start §7发起本队指挥官竞选投票（无需权限；仅本队可见可投；赞成超过反对即当选；每队同时只能有 1 名指挥官）
                §e/commander vote yes|no §7同队玩家投票（一人一票，可改票）
                §e/commander skill scan|airdrop|smoke|artillery|assault|retreat §7使用技能（需指挥官）
                §7  scan=侦察扫描 airdrop=空投补给 smoke=战术雾墙 artillery=炮击 assault=全军突击 retreat=战略撤退
                §7按 V 键（可在按键设置里改）打开技能轮盘（§e仅指挥官§7能打开），点击扇区或按 1-6 直接使用技能
                §a(管理员)§e /commander grant <玩家> / cancel / enable / disable / levellimit on|off / reload
                §7  reload=改完 config/commander_system.json 后热加载配置，不用重启
                §a(管理员)§e /commander checknbt <NBT文本> §7检验一段 NBT 写法对不对（聊天栏里双引号直接打，不用加反斜杠）
                §a(管理员)§e /commander artillery approach vertical §7切换炮弹来袭方向：vertical=垂直落下（默认）
                §a(管理员)§e /commander artillery approach mortar §7改成迫击炮斜着打过来（预览会画出斜向弹道）
                §a(管理员)§e /commander artillery angle <15-80> §7迫击炮入射仰角（越大越陡）；bearing look/south/west/north/east §7从哪边打来
                §a(管理员)§e /commander artillery shake <0-3> §7爆炸时的摄像机摇晃强度（off=完全不晃）
                §7这几条改完会自动写回配置文件，不用再手动编辑 JSON
                §7技能等级默认读记分榜 §fcommander_level§7（可在 levels.scoreboardObjective 改），
                §7用 §e/scoreboard players add <玩家> commander_level <分数> §7给玩家升级
                §7技能还会消耗技能点：读记分榜 §fcommander_points§7（可在 skillPoints.scoreboardObjective 改），
                §7用 §e/scoreboard players add <玩家> commander_points <分数> §7给玩家充技能点
                §7  炮击连发数、落点、伤害、来袭方向(artillery.approach=vertical垂直/mortar迫击炮斜打)、
                §7  爆炸摄像机摇晃(artillery.shakeIntensity/shakeRange)都在配置 artillery 一节里改，改完 /commander reload""";
        // ---- 通用 ----
        public String systemDisabled = "指挥官系统当前处于关闭状态。";
        public String moduleDisabled = "该技能模块已在配置中关闭。";
        public String cooldown = "技能冷却中，还需 {seconds} 秒。";
        /** 释放任意技能后所有技能共同进入的公共冷却（cooldowns.globalTicks）期间的提示 */
        public String globalCooldown = "全局冷却中，还需 {seconds} 秒。";
        /** 炮击/空投必须瞄准方块才能释放；准星指空气/实体时会提示这一句 */
        public String needBlock = "需要瞄准方块才能释放（准星指到方块后左键确认）。";
        /** 连发惩罚第一次触发时提示一次；{seconds}=窗口秒数，{count}=窗口内已释放数，{mult}=消耗倍率 */
        public String penaltyActive = "连发惩罚：{seconds} 秒内已释放 {count} 个技能，本次起技能点消耗×{mult}。";
        public String levelTooLow = "等级不足：该技能需要 {required} 级，你当前 {current} 级。";
        public String notEnoughPoints = "技能点不足：该技能需要 {cost} 点技能点，你当前 {current} 点。";
        /** 用技能成功后提示消耗了多少技能点；不想要这条提示就留空 */
        public String pointsSpent = "已消耗 {cost} 点技能点（剩余 {left} 点）。";
        public String unknownSkill = "未知技能：{skill}";
        public String notCommander = "只有指挥官才能使用技能和打开技能轮盘。可用 /commander vote start 在本队发起竞选投票。";
        // ---- 侦察扫描 ----
        public String scanDone = "§7侦察完成：半径 §f{radius} §7内标记了 §e{count} §7名敌方玩家（发光轮廓持续 {seconds} 秒，{visibility}）。";
        public String scanVisibilityTeam = "只有你和你的队友能看见";
        public String scanVisibilitySelf = "只有你能看见";
        public String scanVisibilityAll = "全服可见（原版效果）";
        public String scanList = "§7侦察名单：§f{names}";
        // ---- 空投补给 ----
        public String airdropCalledItems = "§a空投已呼叫「§e{type}§a」：光柱标记落点 {seconds} 秒后物资从天而降，落地即变成掉落物。";
        public String airdropCalledChest = "§a空投已呼叫「§e{type}§a」：光柱标记落点 {seconds} 秒后补给箱从天而降，落地即成箱子。";
        /** 该类型的 entity 非空时（如载具维修箱）：光柱结束后原地生成实体 */
        public String airdropCalledEntity = "§a空投已呼叫「§e{type}§a」：光柱标记落点 {seconds} 秒后从天而降，落地生成 §e{entity}§a。";
        /** 该类型要求生成实体但 entity 留空时的提示（会按物资箱逻辑处理） */
        public String airdropEntityEmpty = "§e「{type}」未设置落地实体 id（airdrop.types 里该类型的 entity 为空），本次按物资箱逻辑处理。";
        public String airdropChestDespawn = "§7箱子会在 {seconds} 秒后自动消失（物品掉在地上）。";
        // ---- 战术雾墙 ----
        public String smokeNoEntity = "§7战术雾墙未设置自定义实体（config 里 §esmoke.customEntity §7为空），因此没有生成任何实体。在 config/commander_system.json 里填入实体 id 后 /commander reload 即可生效。";
        public String smokeBadEntity = "§c雾墙自定义实体 id 无效：§e{entity}§c，没有生成任何实体。请检查 config 里 smoke.customEntity 的写法。";
        public String smokeSpawnFailed = "§c雾墙自定义实体无法生成：§e{entity}§c。";
        public String smokeBadNbt = "§c雾墙自定义实体 NBT 写错了，已忽略该 NBT：{error}";
        public String smokeDone = "§a战术雾墙已展开：共 §e{count} §a面自定义实体 §e{entity}§a 在准心位置生成，并向左右逐层铺开。";
        // ---- 炮击支援 ----
        public String artilleryCalled = "§a炮击已确认，§e{count} §a发炮弹将§e一发一发§a命中目标区域（{approach}，{landing}，每发间隔约 {interval} 秒，每发伤害 {damage}），请注意掩护！{extra}";
        public String artilleryLandingSame = "全部命中同一位置";
        public String artilleryLandingScatter = "随机散布落点";
        /** artilleryCalled 里 {approach} 的内容：垂直落下（默认） */
        public String artilleryApproachVertical = "垂直落下";
        /** artilleryCalled 里 {approach} 的内容：迫击炮斜向来袭 */
        public String artilleryApproachMortar = "迫击炮斜向来袭";
        public String artilleryNoBlockDamage = "（不会破坏方块）";
        public String artilleryDamageVanilla = "原版";
        public String artilleryModuleOff = "炮击模块已在配置中关闭。";
        /** 一轮炮击全部打完后发给指挥官的战果提示；{count}=命中目标数，{total}=造成伤害合计 */
        public String artilleryEnd = "本轮炮击结束：命中 §e{count} §7个目标，造成总计 §e{total} §7点伤害。";
        public String designatorCooldown = "炮击坐标仪冷却中，还需 {seconds} 秒。";
        public String toolkitGiven = "§a炮击工具包已下发：使用 §e炮击坐标仪§a 右键准星位置即可呼叫炮击。";
        // ---- 全军突击 / 战略撤退 ----
        public String assaultName = "全军突击";
        public String assaultEffects = "力量I、速度I、生命恢复I";
        public String retreatName = "战略撤退";
        public String retreatEffects = "速度II、抗性I、防火";
        public String buffApplied = "§a{name}已下达！全队获得 {effects} {seconds} 秒。{range}";
        public String buffNoTeam = "（你还没有队伍，暂时只对自己生效；可用 /team create 建队伍）";
        public String buffTeamRange = "（{count} 名队员）";
        // ---- 指令：开关 / 授权 / 撤销 ----
        public String reloadDone = "§a配置已热加载，模块开关/等级/冷却/音效粒子/NBT 等改动立即生效。";
        public String reloadFailed = "热加载失败：{error}。已保留当前生效的配置，请检查 config/commander_system.json 的写法。";
        public String systemEnabled = "§a指挥官系统已开启。";
        public String systemOff = "§c指挥官系统已关闭，所有技能与投票均暂停。";
        public String levelLimitOn = "§a技能等级限制已开启。";
        public String levelLimitOff = "§e技能等级限制已关闭，所有技能无视等级要求。";
        public String grantedYou = "§a你已被任命为指挥官！用 /commander skill 查看技能。";
        public String grantedCount = "§a已授予 {count} 名玩家指挥官身份。";
        /** 管理员授予时该队已有指挥官，跳过此人 */
        public String grantedTeamBusy = "§c{player} 所在的 §f[{team}] §c队伍已经有指挥官了（每队同时只能有一名），本次未授予。";
        /** 紧跟在 grantedCount 后面追加，{count}=因队伍已有指挥官而被跳过的人数 */
        public String grantedSkipped = "（另有 {count} 人因所在队伍已有指挥官被跳过）";
        public String revokedYou = "§c你的指挥官身份已被撤销。";
        public String revokedAll = "§c已撤销全部指挥官身份（原 {count} 名），并取消进行中的投票。";
        // ---- 投票 ----
        public String voteStarted = "§f[{team}] §f{player} §7发起队内投票：是否让TA成为本队指挥官？§e/commander vote yes §7赞成，§c/commander vote no §7反对，{seconds} 秒后结算。";
        public String voteAlreadyActive = "已经有一个投票在进行中（全服同时只能有一个），请等待它结束。";
        public String voteAlreadyCommander = "你已经是指挥官了，不需要发起投票。";
        public String voteNeedTeam = "你还没有加入任何队伍，无法发起或参与指挥官投票（管理员可用 §e/team join <队伍> <玩家> §7把人编进队伍）。";
        public String voteTeamHasCommander = "你的队伍已经有指挥官了，每个队伍同时只能有一名指挥官。";
        public String voteNoPlayers = "你的队伍里没有其他在线玩家，无法发起投票。";
        public String voteNoActive = "当前没有你所在队伍的投票，用 /commander vote start 发起。";
        public String voteSelf = "被提名人不能给自己投票。";
        public String voteCastYes = "§a你投了赞成票。";
        public String voteCastNo = "§c你投了反对票。";
        public String voteCancelled = "§c管理员取消了当前投票。";
        public String votePassed = "§a投票通过（§a{yes} §7:§c {no}§7）！§f[{team}] §f{player} §a现在是本队指挥官了。用 /commander skill 查看可用技能。";
        public String votePassedTeamBusy = "§e投票通过（§a{yes} §7:§c {no}§7），但 §f[{team}] §e队伍已有指挥官，不再重复任命 §f{player}§e。";
        public String voteFailed = "§7投票未通过（§a{yes} §7:§c {no}§7）：§f[{team}] §f{player}§7 未能当选指挥官。";
    }

    // ===== 全军突击 =====
    public BuffCfg assault = new BuffCfg();
    public static class BuffCfg {
        public int seconds = 20;
        public List<EffectEntry> effects = new ArrayList<>();
        public String particle = "minecraft:happy_villager";
        public String sound = "minecraft:event.raid.horn";
    }

    public static class LootEntry {
        public String item = "minecraft:cooked_beef";
        public int count = 1;
        /** 单个物品附加的自定义 NBT（原样保留，例如其他模组的物品标签） */
        public String nbt = "";
    }

    public static class EffectEntry {
        public String id = "minecraft:speed";
        public int amplifier = 0;
        /** 0 表示使用模块默认时长 */
        public int seconds = 0;
    }

    public CommanderConfig() {
        assault.seconds = 20;
        assault.effects.add(eff("minecraft:strength", 0, 0));
        assault.effects.add(eff("minecraft:speed", 0, 0));
        assault.effects.add(eff("minecraft:regeneration", 0, 0));
        retreat.seconds = 15;
        retreat.effects.add(eff("minecraft:speed", 1, 0));
        retreat.effects.add(eff("minecraft:resistance", 0, 0));
        retreat.effects.add(eff("minecraft:fire_resistance", 0, 0));
        retreat.particle = "minecraft:cloud";
        retreat.sound = "minecraft:block.beacon.deactivate";
    }

    private static EffectEntry eff(String id, int amp, int secs) {
        EffectEntry e = new EffectEntry();
        e.id = id;
        e.amplifier = amp;
        e.seconds = secs;
        return e;
    }

    private static List<LootEntry> defaultLoot() {
        List<LootEntry> list = new ArrayList<>();
        list.add(loot("minecraft:cooked_beef", 8));
        list.add(loot("minecraft:golden_apple", 2));
        list.add(loot("minecraft:arrow", 32));
        list.add(loot("minecraft:golden_carrot", 6));
        return list;
    }

    private static LootEntry loot(String item, int count) {
        LootEntry e = new LootEntry();
        e.item = item;
        e.count = count;
        return e;
    }

    // ==================== 读取 / 保存 / 热加载 ====================

    public static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve("commander_system.json");
    }

    /**
     * 重新读取配置文件（/commander reload 与启动加载共用）。
     * 返回 null 表示成功；否则返回给玩家看的错误信息，且当前配置原样保留、不覆盖用户文件。
     */
    public static String reload() {
        Path path = configPath();
        if (!Files.exists(path)) {
            INSTANCE = new CommanderConfig();
            save();
            return null;
        }
        try {
            String raw = Files.readString(path);
            CommanderConfig parsed = GSON.fromJson(stripComments(raw), CommanderConfig.class);
            if (parsed == null) throw new IllegalStateException("配置文件内容为空");
            INSTANCE = mergeDefaults(parsed);
            ensureVehicleType(INSTANCE);
            save(); // 把补全后的默认字段和中文注释写回文件
            // 粒子/音效的解析缓存按旧配置建的，热加载后清掉，新配置立刻生效
            cn.blockforge.generated.nbt6commandervotesta.entity.SmokeWallEntity.clearCaches();
            return null;
        } catch (Exception e) {
            String msg = e.getMessage();
            return msg == null ? e.toString() : msg; // 具体提示语在 messages.reloadFailed 里配置
        }
    }

    public static void load() {
        String err = reload();
        if (err != null) {
            // 启动时配置写坏了：先用默认值跑，但不覆盖用户文件，等他改好再 reload
            INSTANCE = new CommanderConfig();
        }
    }

    /**
     * 体检配置里所有 NBT 字段（空投各类型的 nbt、雾墙实体的 customEntityNbt）。
     * JSON 本身能解析、但里面那段 SNBT 写错时，要到技能真的释放才暴露，很难查；
     * 这里在 /commander reload 成功后就提前检查，返回 null=全部正常，
     * 否则返回多行问题描述（含"实际读到的内容"，方便发现双引号没转义被 JSON 吃掉的情况）。
     */
    public static String nbtFieldProblems() {
        StringBuilder bad = new StringBuilder();
        AirdropCfg ad = INSTANCE == null ? null : INSTANCE.airdrop;
        if (ad != null && ad.types != null) {
            for (SupplyTypeEntry t : ad.types) {
                if (t == null || t.nbt == null || t.nbt.isBlank()) continue;
                checkOneNbt(bad, "airdrop.types 里 id=" + t.id + " 的 nbt", t.nbt);
            }
        }
        SmokeCfg sm = INSTANCE == null ? null : INSTANCE.smoke;
        if (sm != null && sm.customEntityNbt != null && !sm.customEntityNbt.isBlank()) {
            checkOneNbt(bad, "smoke.customEntityNbt", sm.customEntityNbt);
        }
        return bad.length() == 0 ? null : bad.toString();
    }

    /**
     * 针对「列表里套整数数组」（/data get 导出的 DogTagIcon 这类 [[I;…],[I;…]）
     * 的解析失败提示：这种写法本身是能读回的，报错几乎都是复制/粘贴时
     * 某个内层数组的 ] 闭合括号丢了。命中时返回人话提示，否则返回空串。
     */
    public static String nestedArrayHint(String nbt) {
        if (nbt == null || !nbt.contains("[[I;")) return "";
        return "\n§7    特别提示：这段含 §f[[I;…],[I;…]§7（列表里套整数数组，常见于 /data get 导出的 DogTagIcon）。" +
                "§c这种写法游戏可以读回，报 §fCan't insert TAG_Int_Array§c 基本是粘贴时 §f]§c 闭合括号丢了——" +
                "数一下每个 §f[I;§c 后面是否都有配对的 §f]§c；" +
                "实在对不上就先把这一整项删掉试试（DogTagIcon 通常只是全 -1 的默认狗牌图标，删了不影响功能）";
    }

    private static void checkOneNbt(StringBuilder bad, String where, String nbt) {
        try {
            TagParser.parseTag(nbt.trim());
        } catch (Exception e) {
            bad.append("\n§7  · ").append(where).append("：§c").append(e.getMessage())
                    .append("\n§7    实际读到的内容是 §f").append(nbt)
                    .append(nestedArrayHint(nbt));
        }
    }

    /** 去掉 // 注释（不碰字符串里的 //），剩下纯 JSON 交给 Gson 解析 */
    static String stripComments(String raw) {
        StringBuilder sb = new StringBuilder();
        boolean inString = false;
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (inString) {
                sb.append(c);
                if (c == '\\' && i + 1 < raw.length()) {
                    sb.append(raw.charAt(++i));
                } else if (c == '"') {
                    inString = false;
                }
                continue;
            }
            if (c == '"') {
                inString = true;
                sb.append(c);
                continue;
            }
            if (c == '/' && i + 1 < raw.length() && raw.charAt(i + 1) == '/') {
                while (i < raw.length() && raw.charAt(i) != '\n') i++;
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    /**
     * 老配置升级：空投类型清单里没有 id=vehicle（空投载具）时自动补一条；
     * 已有该类型但 entity 留空（说明从没配置过载具）时，把出厂默认的
     * 载具实体 id 和 NBT 一并填进去（reload 后 save 会写回文件，玩家无需手改）。
     * entity 已经填了东西的类型一律不动，尊重玩家自己的配置。
     */
    static void ensureVehicleType(CommanderConfig cfg) {
        if (cfg.airdrop == null) return;
        if (cfg.airdrop.types == null) {
            cfg.airdrop.types = defaultSupplyTypes();
            return;
        }
        for (SupplyTypeEntry t : cfg.airdrop.types) {
            if (t != null && t.id != null && t.id.trim().equalsIgnoreCase("vehicle")) {
                // entity 还是空的 = 这台载具从没真正配置过（旧文件里残留的 nbt 也从没生效），
                // 直接补上出厂默认；entity 填了东西的一律不动，尊重玩家自己的配置
                if (t.entity == null || t.entity.isBlank()) {
                    t.entity = DEFAULT_VEHICLE_ENTITY;
                    t.nbt = DEFAULT_VEHICLE_NBT;
                }
                return;
            }
        }
        SupplyTypeEntry vehicle = new SupplyTypeEntry();
        vehicle.id = "vehicle";
        vehicle.name = "空投载具";
        vehicle.desc = "落地生成 entity 里填写的载具实体，面向释放者视线方向（只认东南西北）";
        vehicle.entity = DEFAULT_VEHICLE_ENTITY;
        vehicle.nbt = DEFAULT_VEHICLE_NBT;
        cfg.airdrop.types.add(vehicle);
    }

    /** 把用户配置里缺的字段用默认值递归补齐（老版本配置文件升级时不会出现 null 字段） */
    static CommanderConfig mergeDefaults(CommanderConfig parsed) {
        JsonObject defaults = GSON.toJsonTree(new CommanderConfig()).getAsJsonObject();
        JsonObject current = GSON.toJsonTree(parsed).getAsJsonObject();
        return GSON.fromJson(merge(defaults, current), CommanderConfig.class);
    }

    private static JsonObject merge(JsonObject def, JsonObject cur) {
        JsonObject out = new JsonObject();
        for (Map.Entry<String, JsonElement> e : def.entrySet()) {
            String key = e.getKey();
            JsonElement dv = e.getValue();
            JsonElement cv = cur.get(key);
            if (cv == null || cv.isJsonNull()) {
                out.add(key, dv);
            } else if (dv.isJsonObject() && cv.isJsonObject()) {
                out.add(key, merge(dv.getAsJsonObject(), cv.getAsJsonObject()));
            } else {
                out.add(key, cv);
            }
        }
        // 配置里多出来的键也原样保留
        for (Map.Entry<String, JsonElement> e : cur.entrySet()) {
            if (!out.has(e.getKey())) out.add(e.getKey(), e.getValue());
        }
        return out;
    }

    public static void save() {
        try {
            Files.createDirectories(configPath().getParent());
            Files.writeString(configPath(), annotate(GSON.toJson(INSTANCE)));
        } catch (IOException ignored) {
        }
    }

    // ==================== 生成带中文注释的配置文件 ====================

    private static final Pattern KEY = Pattern.compile("\"([^\"]+)\"\\s*:");

    private static final String HEADER = """
            // ============================================================
            //  指挥官系统 配置文件
            //  · 所有 // 开头的都是中文注释，删不删都不影响游戏读取
            //  · 改完保存，进游戏输入 /commander reload 立即生效（需要管理员权限）
            //  · 哪个字段不想要了直接删掉，reload 时会自动按默认值补回来
            //  · 音效/粒子写原版 id（minecraft:xxx），物品 id 支持其他模组
            // ============================================================
            """;

    /** 字段路径 → 中文说明。数组里的元素用 * 表示，如 airdrop.loot.*.item */
    private static Map<String, String> comments() {
        Map<String, String> m = new HashMap<>();
        // ---- 模块开关 ----
        m.put("moduleIdentity", "模块1：指挥官身份与投票管理（投票授予 + 管理员指令）");
        m.put("moduleLevelLimit", "模块2：技能等级与NBT配置中心（等级限制的总开关在 levels.enabled）");
        m.put("moduleScan", "模块3：侦察扫描（发光轮廓）");
        m.put("moduleAirdrop", "模块4：空投补给（信标光柱 + 补给箱）");
        m.put("moduleSmoke", "模块4：战术雾墙（挡视线 + 同队增益）");
        m.put("moduleArtillery", "模块5：炮击支援（直接天降或发放工具包）");
        m.put("moduleAssault", "模块6：全军突击（团队增益）");
        m.put("moduleRetreat", "模块6：战略撤退（团队增益）");
        // ---- 投票 ----
        m.put("vote", "投票设置");
        m.put("vote.durationSeconds", "投票持续多少秒，到点后赞成多于反对就自动授予指挥官");
        // ---- 等级限制 ----
        m.put("levels", "技能等级限制");
        m.put("levels.enabled", "是否启用等级限制（false=所有技能无视等级要求，也可用 /commander levellimit off 临时关）");
        m.put("levels.scan", "使用侦察扫描需要的最低等级");
        m.put("levels.airdrop", "使用空投补给需要的最低等级");
        m.put("levels.smoke", "使用战术雾墙需要的最低等级");
        m.put("levels.artillery", "使用炮击支援需要的最低等级");
        m.put("levels.assault", "使用全军突击需要的最低等级");
        m.put("levels.retreat", "使用战略撤退需要的最低等级（分数）");
        m.put("levels.source", "等级来源：scoreboard=读记分榜（默认，不用原版经验）；xp=原版经验等级（旧行为）");
        m.put("levels.scoreboardObjective", "记分榜目标（计分项）名，可自定义，玩家的分数就是他的等级；用 /scoreboard players add <玩家> <目标名> <分数> 即可给他升级");
        m.put("levels.autoCreateObjective", "true=记分榜目标不存在时自动按 dummy 类型创建（默认）；false=目标不存在时一律按 0 分处理");
        // ---- 技能点 ----
        m.put("skillPoints", "技能点：使用技能除了等级达标，还要消耗记分榜里的技能点（记分榜目标可自定义）");
        m.put("skillPoints.enabled", "是否启用技能点消耗（false=技能只看等级，不扣点）");
        m.put("skillPoints.scan", "使用侦察扫描消耗的技能点");
        m.put("skillPoints.airdrop", "使用空投补给消耗的技能点");
        m.put("skillPoints.smoke", "使用战术雾墙消耗的技能点");
        m.put("skillPoints.artillery", "使用炮击支援消耗的技能点");
        m.put("skillPoints.assault", "使用全军突击消耗的技能点");
        m.put("skillPoints.retreat", "使用战略撤退消耗的技能点");
        m.put("skillPoints.scoreboardObjective", "技能点读的记分榜目标（计分项）名，可自定义，玩家的分数就是他的技能点余额；用 /scoreboard players add <玩家> <目标名> <分数> 给玩家充技能点");
        m.put("skillPoints.autoCreateObjective", "true=记分榜目标不存在时自动按 dummy 类型创建（默认）；false=目标不存在时一律按 0 点处理");
        // ---- 技能轮盘中心提示 ----
        m.put("wheel", "技能轮盘中心提示的文字（全部可自定义，留空 = 用内置文案；进游戏 /commander reload 生效）");
        m.put("wheel.centerTitle", "悬停技能时轮盘中心的顶部标题，留空=「指挥官技能轮盘」");
        m.put("wheel.centerSummary", "不悬停时中心盘的统计行，{ready}=就绪技能数，{total}=技能总数；留空=「就绪 {ready}/{total}」");
        m.put("wheel.centerHint", "不悬停时中心盘底部的操作提示，留空=「点击扇区或按 1-6 使用技能 · 再按 V 或 Esc 关闭」");
        m.put("wheel.statusReady", "悬停时中心盘的状态行：技能就绪，留空=「就绪！点击使用」");
        m.put("wheel.statusCooldown", "悬停时中心盘的状态行：冷却中，{seconds}=剩余秒数，留空=「冷却中 · 还剩 {seconds} 秒」");
        m.put("wheel.statusLevel", "悬停时中心盘的状态行：等级不足，{required}=需要等级，{current}=当前等级；记分榜模式下\"级\"就是分数，可自行改成\"分\"；留空=「需要 {required} 级 · 你当前 {current} 级」");
        m.put("wheel.statusPoints", "悬停时中心盘的状态行：技能点不足，{cost}=需要技能点，{current}=当前技能点；留空=「技能点不足 · 需要 {cost} 点 · 你有 {current} 点」");
        m.put("wheel.statusModuleOff", "悬停时中心盘的状态行：技能模块被关闭，留空=「该技能模块已在配置中关闭」");
        m.put("wheel.statusNotCommander", "还不是指挥官的提示（中心盘状态行 + 顶部横条），留空=「你还不是指挥官」");
        m.put("wheel.statusPenalty", "悬停时中心盘的状态行：连发惩罚生效中，{mult}=消耗倍率；留空=「连发惩罚中 · 消耗×{mult}」");
        m.put("wheel.centerPoints", "不悬停时中心盘显示的技能点余额行，{points}=当前技能点；留空=「技能点：{points}」");
        m.put("wheel.statusSystemOff", "系统已关闭的提示（中心盘状态行 + 顶部横条），留空=「指挥官系统已关闭」");
        m.put("wheel.scan", "侦察扫描在轮盘上的文字");
        m.put("wheel.airdrop", "空投补给在轮盘上的文字");
        m.put("wheel.smoke", "战术雾墙在轮盘上的文字");
        m.put("wheel.artillery", "炮击支援在轮盘上的文字");
        m.put("wheel.assault", "全军突击在轮盘上的文字");
        m.put("wheel.retreat", "战略撤退在轮盘上的文字");
        m.put("wheel.scan.name", "侦察扫描的完整名（悬停时显示在中心盘），留空=「侦察扫描」");
        m.put("wheel.scan.shortName", "侦察扫描的短名（显示在扇区上），留空=「侦察」");
        m.put("wheel.scan.desc", "侦察扫描的说明（悬停时显示在中心盘），留空=内置说明");
        m.put("wheel.airdrop.name", "空投补给的完整名，留空=「空投补给」");
        m.put("wheel.airdrop.shortName", "空投补给的短名，留空=「空投」");
        m.put("wheel.airdrop.desc", "空投补给的说明，留空=内置说明");
        m.put("wheel.smoke.name", "战术雾墙的完整名，留空=「战术雾墙」");
        m.put("wheel.smoke.shortName", "战术雾墙的短名，留空=「雾墙」");
        m.put("wheel.smoke.desc", "战术雾墙的说明，留空=内置说明");
        m.put("wheel.artillery.name", "炮击支援的完整名，留空=「炮击支援」");
        m.put("wheel.artillery.shortName", "炮击支援的短名，留空=「炮击」");
        m.put("wheel.artillery.desc", "炮击支援的说明，留空=内置说明");
        m.put("wheel.assault.name", "全军突击的完整名，留空=「全军突击」");
        m.put("wheel.assault.shortName", "全军突击的短名，留空=「突击」");
        m.put("wheel.assault.desc", "全军突击的说明，留空=内置说明");
        m.put("wheel.retreat.name", "战略撤退的完整名，留空=「战略撤退」");
        m.put("wheel.retreat.shortName", "战略撤退的短名，留空=「撤退」");
        m.put("wheel.retreat.desc", "战略撤退的说明，留空=内置说明");
        // ---- 冷却 ----
        m.put("cooldowns", "各技能的冷却时间（秒）");
        m.put("cooldowns.globalTicks", "全局冷却（tick，20 tick = 1 秒）：释放任意技能后所有技能共同进入的公共冷却，默认 30 = 1.5 秒；0=关闭");
        m.put("cooldowns.scan", "侦察扫描冷却（秒）");
        m.put("cooldowns.airdrop", "空投补给冷却（秒）");
        m.put("cooldowns.smoke", "战术雾墙冷却（秒）");
        m.put("cooldowns.artillery", "炮击支援冷却（秒）");
        m.put("cooldowns.assault", "全军突击冷却（秒）");
        m.put("cooldowns.retreat", "战略撤退冷却（秒）");
        m.put("cooldowns.designator", "炮击坐标仪（toolkit 工具包模式）冷却（秒）");
        // ---- 侦察扫描 ----
        m.put("scan", "侦察扫描");
        m.put("scan.radius", "扫描半径（格）");
        m.put("scan.glowSeconds", "发光轮廓持续多少秒");
        m.put("scan.glowVisibility", "谁能看见发光轮廓：team=指挥官与同队玩家（默认）；self=仅指挥官本人；all=全服可见（原版发光效果）");
        m.put("scan.sound", "扫描时播放的音效 id");
        m.put("scan.particle", "扫描声波粒子 id");
        // ---- 空投补给 ----
        m.put("airdrop", "空投补给");
        m.put("airdrop.height", "补给箱从落点上方多少格开始下落");
        m.put("airdrop.beamSeconds", "信标光柱提示多少秒后补给箱落下");
        m.put("airdrop.sound", "空投时播放的音效 id");
        m.put("airdrop.particle", "补给箱落地时的爆发粒子 id");
        m.put("airdrop.beamColor", "落点光柱颜色（6 位十六进制 RGB，例如 FF8800 橙色），留空或写错则为白色");
        m.put("airdrop.fallSpeed", "补给箱每 tick（1/20 秒）下落多少格，越小落得越慢，0.35 ≈ 每秒 7 格");
        m.put("airdrop.trailParticle", "补给箱下落时的拖尾/降落伞粒子 id");
        m.put("airdrop.fallSound", "下落过程中每秒播放一次的风声音效 id，留空则不播");
        m.put("airdrop.landSound", "补给箱落地放置时播放的音效 id，留空则不播");
        m.put("airdrop.loot", "空投箱里的物品清单（可以自由增删改，物品 id 支持其他模组）");
        m.put("airdrop.loot.*", "单件物品");
        m.put("airdrop.loot.*.item", "物品 id（例如 minecraft:golden_apple 或其他模组的 id）");
        m.put("airdrop.loot.*.count", "数量");
        m.put("airdrop.loot.*.nbt", "附加的自定义 NBT（原样保留，例如 {CustomModelData:1}），留空则不加");
        m.put("airdrop.crateNbt", "整个补给箱附加的自定义 NBT（原样写入箱子的方块实体标签），留空则不加。只在 landAsItems=false（放箱子）时生效");
        m.put("airdrop.chestSeconds", "落地后的箱子多少秒后自动消失（里面的物品会掉在地上，不会丢）；0=一直留着（旧行为）。只在 landAsItems=false 时生效");
        m.put("airdrop.landAsItems", "true=落地后直接生成掉落物，不出现箱子（默认）；false=落地放一个装满的箱子（旧行为）");
        m.put("airdrop.types", "空投资源类型清单（轮盘按空投键后弹出的 2 级菜单选项，按顺序显示，可自由增删改）");
        m.put("airdrop.types.*", "单个空投类型");
        m.put("airdrop.types.*.id", "类型标识（选择后随空投请求发给服务器，需要唯一）");
        m.put("airdrop.types.*.name", "菜单上显示的名字，留空=用 id");
        m.put("airdrop.types.*.desc", "菜单上的一行说明");
        m.put("airdrop.types.*.entity", "落地时生成的实体 id（支持其他模组，例如载具维修箱的实体）。留空=按物资箱的现有逻辑处理（掉落物/箱子）。★id=vehicle（空投载具）的出厂默认是 §esuperbwarfare:sodayo_pick_up§7（卓越前线载具），老配置里该项为空时 /commander reload 会自动补上");
        m.put("airdrop.types.*.nbt", "生成该实体时附带的自定义 NBT（SNBT 文本，例如 {TankOwner:\\\"abc\\\",Fuel:500f}），仅在 entity 非空时生效。★生成方式是§e直接按落点坐标造实体§7（不再走 /summon，所以不会出现载具跑到 0,0 原点的问题），UUID 和 Pos 两项不会覆盖实体自己的位置；NBT 里没写 Rotation 时自动补上释放者视线的四方向朝向。★配置文件本身是 JSON：NBT 里的每个双引号都必须写成 \\\" （反斜杠+引号），少一个反斜杠整个配置就加载失败；数字带类型要加后缀（500f 浮点、500d 双精度、1L 长整数），字符串才需要引号。拿不准就先在游戏里输入 /commander checknbt 空格，再把你想要的原文（这里的引号不用加反斜杠，直接打）粘进去回车，看语法对不对，改完再 /commander reload。★从 /data get 抄下来的 NBT 里，形如 [[I; ...], [I; ...]] 的「列表里套整数数组」（如 DogTagIcon）本身可以写回，但内容长、粘贴时最容易丢右括号 ]——报 Can't insert TAG_Int_Array 就是这种情况，逐项检查 [I; 与 ] 配对即可。载具的 NBT 建议删掉 Rotation 项，让朝向跟随释放者视线自动补");
        // ---- 战术雾墙 ----
        m.put("smoke", "战术雾墙");
        m.put("smoke.width", "雾墙宽度（格）");
        m.put("smoke.height", "雾墙高度（格）");
        m.put("smoke.durationSeconds", "雾墙持续多少秒后消散");
        m.put("smoke.movePerTick", "雾墙每 tick（1/20秒）前进的距离，0=原地不动");
        m.put("smoke.speedAmplifier", "同队玩家获得的速度等级（0=速度I，-1=不给速度）");
        m.put("smoke.jumpAmplifier", "同队玩家获得的跳跃提升等级（0=跳跃I，-1=不给跳跃）");
        m.put("smoke.particle", "雾墙粒子 id");
        m.put("smoke.sound", "雾墙音效 id");
        m.put("smoke.customEntity", "技能生成的自定义实体 id（支持其他模组，例如 minecraft:area_effect_cloud）。留空=不生成任何实体（默认）。生成位置=准心位置，先出中心一面再向左右逐层展开");
        m.put("smoke.customEntityNbt", "自定义实体附加的 NBT（原样写入实体标签，UUID 和 Pos 除外），留空则不加。★配置文件是 JSON：NBT 里的双引号要写成 \\\" （反斜杠+引号）；可先进游戏用 /commander checknbt <文本> 检验语法");
        m.put("smoke.spawnRange", "雾墙生成在准心指向的位置（方块/实体表面），这是探测的最远距离（格），探测不到就落在视线最远处");
        m.put("smoke.upOffset", "准星指的是方块时，雾墙整体向上抬几格（默认 3，避免嵌进地面）；准星指实体或探测不到时不抬");
        m.put("smoke.count", "雾墙总面数（包含中间那一面）：写了它就严格按它来，3=中间一面+左右各一面，5=中间+左右各两面；偶数时右侧多一面；0=不手填、按 smoke.width/spreadStep 自动算");
        m.put("smoke.spreadStep", "左右展开时相邻两面雾墙之间的间距（格）；count=0 自动模式时展开的总宽度约等于 smoke.width");
        m.put("smoke.spreadIntervalTicks", "左右展开的速度：每隔多少 tick 向左右各多展开一层（一层=左右各一面），0=不做过程、左右一次性全部出现");
        m.put("smoke.maxSpreadLayers", "单侧最多展开多少层（只在 count=0 自动模式时生效），防止把宽度/间距设得太大时一口气生成太多实体");
        m.put("smoke.blockWalls", "不穿墙开关（默认开）：雾墙左右展开时，中心到某一层之间隔着方块就停止这个方向的展开，不会穿墙铺到建筑里；关掉则无视方块照铺");
        // ---- 连发惩罚 ----
        m.put("penalty", "连发惩罚：统计窗口内释放超过 allowedCount 个技能后，从下一个起技能点消耗按 multiplier 加倍（防无脑甩技能）");
        m.put("penalty.enabled", "是否启用连发惩罚（默认 true）");
        m.put("penalty.windowSeconds", "统计窗口（秒）：在这个窗口内数玩家一共释放了几个技能，默认 60");
        m.put("penalty.allowedCount", "窗口内允许正常消耗的技能个数，默认 2 = 第 3 个起加倍");
        m.put("penalty.multiplier", "惩罚倍率：触发后消耗 = 原消耗 × 这个数，默认 2.0 = 加倍");
        // ---- 炮击支援 ----
        m.put("artillery", "炮击支援");
        m.put("artillery.mode", "direct=直接天降炮击（不发放物品）；toolkit=发放炮击工具包（坐标仪等，由玩家自己触发）");
        m.put("artillery.strikes", "一轮炮击打几发");
        m.put("artillery.radius", "每发爆炸的半径（越大范围越大）");
        m.put("artillery.destroyBlocks", "是否破坏方块：false=绝不破坏方块（默认），且绝不点火；true=按真实爆炸破坏");
        m.put("artillery.fire", "是否点火：只在 destroyBlocks=true 时生效（false 时不残留火方块）");
        m.put("artillery.intervalTicks", "每发之间的间隔（tick，20 tick = 1 秒）");
        m.put("artillery.landing", "落点方式：scatter=每发随机散布（默认，配合下面的 scatter 用）；same=全部打同一位置（准星正中心）");
        m.put("artillery.scatter", "随机落点的散布范围（格）：每发在瞄准点 ±这个距离 的**方形区域**内随机取点（瞄准时地上画的那个方格就是它），只在 landing=scatter 时生效");
        m.put("artillery.sound", "爆炸音效 id");
        m.put("artillery.particle", "爆炸粒子 id");
        m.put("artillery.smokeParticle", "爆炸后烟雾粒子 id");
        m.put("artillery.trailTicks", "每发炮弹落地前多少 tick（1/20 秒）开始显示下坠弹道，0=不显示；间隔再短也能看出是一发一发打的");
        m.put("artillery.trailParticle", "炮弹下坠弹道粒子 id");
        m.put("artillery.toolkitNbt", "toolkit 模式：坐标仪附加的自定义 NBT（原样保留），留空则不加");
        m.put("artillery.toolkitCount", "toolkit 模式：发放坐标仪的数量");
        m.put("artillery.toolkitExtraItems", "toolkit 模式：随坐标仪一起发放的额外物品（例如其他模组的火炮遥控器、炮弹）");
        m.put("artillery.toolkitExtraItems.*", "单件物品");
        m.put("artillery.toolkitExtraItems.*.item", "物品 id（支持其他模组）");
        m.put("artillery.toolkitExtraItems.*.count", "数量");
        m.put("artillery.toolkitExtraItems.*.nbt", "附加的自定义 NBT（原样保留），留空则不加");
        m.put("artillery.damage", "每发炮弹的最大伤害（1 = 半颗心）：爆心处全额，随距离线性衰减到边缘的 30%；写 -1 = 完全按原版爆炸伤害计算（伤害由爆炸半径决定，不可控）");
        m.put("artillery.damageRadius", "自定义伤害的作用半径（格）；<=0 时用爆炸半径 artillery.radius");
        m.put("artillery.knockback", "自定义伤害附带击退的力度，0=不击退");
        m.put("artillery.hitVehicles", "炮击是否伤害载具等非生物实体（[SBW]卓越前线 的载具、原版的船/矿车/挂画等）；这类实体的血量记在实体自己身上，走它自己的受伤判定；false 则炮击只打生物");
        m.put("artillery.vehicleBonusMultiplier", "炮击对模组载具（[SBW]卓越前线 的坦克/步战车/无人机等，非生物实体且 id 不是 minecraft: 开头）的伤害倍率：3.0=300%（默认），1.0=无加成；原版的船/矿车等不吃这个加成");
        m.put("artillery.blockWalls", "不穿墙开关（默认开）：一、垂直弹时落点吸附到该列最高方块的顶面，瞄点上方有屋顶就炸在屋顶上，不会穿进室内；迫击炮弹（approach=mortar）则沿斜着飞来的那条线找第一个撞击面，撞到屋顶/墙就在上面炸；二、自定义伤害模式下，爆心与目标之间隔着方块不再造成伤害，躲在墙后不会被打到（这条只在 damage 不是 -1 时参与结算）");
        m.put("artillery.approach", "炮弹来袭方向：vertical=从落点正上方垂直砸下来（默认，原来的样子）；mortar=像迫击炮那样从斜上方打过来，配合下面两项控制斜得有多厉害、从哪边打过来");
        m.put("artillery.mortarAngle", "迫击炮入射仰角（度）：45=斜着 45 度打过来（最直观），数值越大越陡、越接近垂直，越小越平（低于 15 会被抬到 15）；水平拉得越远的同时弹道也越长。只在 approach=mortar 时生效");
        m.put("artillery.mortarBearing", "迫击炮从哪个水平方向打来（只认四方向）：look=跟着释放者视线（你朝哪看，炮弹就从你身后越过头顶飞向落点，默认）；south/west/north/east=固定从该方位打过来；只在 approach=mortar 时生效");
        m.put("artillery.shakeIntensity", "爆炸时摄像机摇晃的强度：1.0=爆心附近明显一晃（远处按距离平方衰减），0=完全不晃；只动画面，不会推动玩家、不影响任何数值");
        m.put("artillery.shakeRange", "摄像机摇晃的波及范围（格）：离爆心超过这个距离就完全不晃");
        m.put("artillery.shakeTicks", "摄像机摇晃持续多少 tick（20 tick = 1 秒）：前 35% 保持满幅，之后平滑衰减到 0");
        m.put("artillery.shakeWallMuffle", "隔着墙/屋顶时的震感系数：0.4=只震四成（默认，屋里的人震得轻），1=不衰减，0=隔墙完全不晃");
        // ---- 全军突击 / 战略撤退 ----
        m.put("assault", "全军突击（团队增益）");
        m.put("assault.seconds", "默认增益持续秒数（效果里 seconds 填 0 时用它）");
        m.put("assault.effects", "给指挥官所在队伍全部玩家上的药水效果（可自由增删改）");
        m.put("assault.effects.*", "单个药水效果");
        m.put("assault.effects.*.id", "效果 id（例如 minecraft:strength 力量、minecraft:speed 速度）");
        m.put("assault.effects.*.amplifier", "效果等级（0=I级，1=II级，以此类推）");
        m.put("assault.effects.*.seconds", "该效果持续秒数，0=使用上面的 assault.seconds");
        m.put("assault.particle", "施放时的粒子 id");
        m.put("assault.sound", "施放时的音效 id");
        m.put("retreat", "战略撤退（团队增益）");
        m.put("retreat.seconds", "默认增益持续秒数（效果里 seconds 填 0 时用它）");
        m.put("retreat.effects", "给指挥官所在队伍全部玩家上的药水效果（可自由增删改）");
        m.put("retreat.effects.*", "单个药水效果");
        m.put("retreat.effects.*.id", "效果 id（例如 minecraft:speed 速度、minecraft:fire_resistance 防火）");
        m.put("retreat.effects.*.amplifier", "效果等级（0=I级，1=II级，以此类推）");
        m.put("retreat.effects.*.seconds", "该效果持续秒数，0=使用上面的 retreat.seconds");
        m.put("retreat.particle", "施放时的粒子 id");
        m.put("retreat.sound", "施放时的音效 id");
        // ---- 提示文本 ----
        m.put("messages", "全部提示文本（进游戏 /commander reload 立即生效），{xxx} 是占位符，会被替换成实际数值；不想要的段落可以删掉或留空");
        m.put("messages.prefix", "所有提示共用的开头；不想要前缀就留空");
        m.put("messages.help", "/commander help 显示的帮助全文，\\n 表示换行");
        m.put("messages.systemDisabled", "系统关闭时使用技能的提示");
        m.put("messages.moduleDisabled", "技能模块被关闭时的提示");
        m.put("messages.cooldown", "技能冷却中的提示，{seconds}=剩余秒数");
        m.put("messages.globalCooldown", "全局冷却中的提示（释放任意技能后所有技能共用的 1.5 秒公共冷却，时长在 cooldowns.globalTicks），{seconds}=剩余秒数");
        m.put("messages.needBlock", "炮击/空投要求准星指到方块才能释放；指到空气或实体时会提示这一句");
        m.put("messages.penaltyActive", "连发惩罚第一次触发时的提示，{seconds}=窗口秒数，{count}=窗口内已释放技能数，{mult}=消耗倍率");
        m.put("messages.levelTooLow", "等级不足的提示，{required}=需要等级，{current}=当前等级");
        m.put("messages.notEnoughPoints", "技能点不足的提示，{cost}=需要技能点，{current}=当前技能点");
        m.put("messages.pointsSpent", "技能使用成功后提示消耗了多少技能点，{cost}=消耗点数，{left}=剩余点数；不想要这条提示就留空");
        m.put("messages.unknownSkill", "未知技能的提示，{skill}=技能名");
        m.put("messages.notCommander", "非指挥官使用技能的提示");
        m.put("messages.scanDone", "侦察完成的提示，{radius}=半径，{count}=标记人数，{seconds}=持续秒数，{visibility}=谁能看见");
        m.put("messages.scanVisibilityTeam", "scanDone 里 {visibility} 的内容：队伍可见");
        m.put("messages.scanVisibilitySelf", "scanDone 里 {visibility} 的内容：仅自己可见");
        m.put("messages.scanVisibilityAll", "scanDone 里 {visibility} 的内容：全服可见");
        m.put("messages.scanList", "侦察名单的提示，{names}=玩家名列表");
        m.put("messages.airdropCalledItems", "呼叫空投（落地变掉落物）的提示，{type}=所选物资类型名，{seconds}=光柱秒数");
        m.put("messages.airdropCalledChest", "呼叫空投（落地放箱子）的提示，{type}=所选物资类型名，{seconds}=光柱秒数");
        m.put("messages.airdropCalledEntity", "呼叫需要生成实体的空投（如载具维修箱）的提示，{type}=类型名，{seconds}=光柱秒数，{entity}=实体 id");
        m.put("messages.airdropEntityEmpty", "所选空投类型要求生成实体但 entity 留空时的提示，{type}=类型名");
        m.put("messages.airdropChestDespawn", "空投箱子自动消失的提示，{seconds}=秒数（仅箱子模式）");
        m.put("messages.smokeNoEntity", "雾墙没配置自定义实体的提示");
        m.put("messages.smokeBadEntity", "雾墙实体 id 无效的提示，{entity}=实体 id");
        m.put("messages.smokeSpawnFailed", "雾墙实体无法生成的提示，{entity}=实体 id");
        m.put("messages.smokeBadNbt", "雾墙实体 NBT 写错的提示，{error}=错误信息");
        m.put("messages.smokeDone", "雾墙展开成功的提示，{count}=雾墙总面数，{entity}=实体 id");
        m.put("messages.artilleryCalled", "炮击确认的提示，{count}=发数，{approach}=来袭方向（垂直/迫击炮），{landing}=落点方式，{interval}=每发间隔秒数，{damage}=每发伤害，{extra}=附加说明");
        m.put("messages.artilleryLandingSame", "artilleryCalled 里 {landing} 的内容：同一位置");
        m.put("messages.artilleryLandingScatter", "artilleryCalled 里 {landing} 的内容：随机散布");
        m.put("messages.artilleryApproachVertical", "artilleryCalled 里 {approach} 的内容：垂直落下（默认）");
        m.put("messages.artilleryApproachMortar", "artilleryCalled 里 {approach} 的内容：迫击炮斜向来袭");
        m.put("messages.artilleryNoBlockDamage", "artilleryCalled 里 {extra} 的内容：不破坏方块");
        m.put("messages.artilleryDamageVanilla", "artilleryCalled 里 {damage} 的内容：damage=-1（原版伤害）时显示");
        m.put("messages.artilleryModuleOff", "炮击模块关闭时使用坐标仪的提示");
        m.put("messages.artilleryEnd", "一轮炮击全部打完后的战果提示，{count}=命中目标数，{total}=造成伤害合计（取整）");
        m.put("messages.designatorCooldown", "炮击坐标仪冷却中的提示，{seconds}=剩余秒数");
        m.put("messages.toolkitGiven", "炮击工具包下发的提示");
        m.put("messages.assaultName", "全军突击的技能名（用在 buffApplied 的 {name} 里）");
        m.put("messages.assaultEffects", "全军突击的效果说明（用在 buffApplied 的 {effects} 里）");
        m.put("messages.retreatName", "战略撤退的技能名（用在 buffApplied 的 {name} 里）");
        m.put("messages.retreatEffects", "战略撤退的效果说明（用在 buffApplied 的 {effects} 里）");
        m.put("messages.buffApplied", "团队增益下达成功的提示，{name}=技能名，{effects}=效果说明，{seconds}=秒数，{range}=范围说明");
        m.put("messages.buffNoTeam", "buffApplied 里 {range} 的内容：没有队伍时");
        m.put("messages.buffTeamRange", "buffApplied 里 {range} 的内容：有队伍时，{count}=队员数");
        m.put("messages.reloadDone", "/commander reload 成功的提示");
        m.put("messages.reloadFailed", "/commander reload 失败的提示，{error}=错误信息");
        m.put("messages.systemEnabled", "/commander enable 的提示");
        m.put("messages.systemOff", "/commander disable 的提示");
        m.put("messages.levelLimitOn", "/commander levellimit on 的提示");
        m.put("messages.levelLimitOff", "/commander levellimit off 的提示");
        m.put("messages.grantedYou", "被任命为指挥官的提示");
        m.put("messages.grantedCount", "授予指挥官成功的提示，{count}=人数");
        m.put("messages.grantedTeamBusy", "管理员授予时该队已有指挥官被跳过的提示，{player}=玩家，{team}=队伍名");
        m.put("messages.grantedSkipped", "授予结果里追加的跳过人数说明，{count}=被跳过人数");
        m.put("messages.revokedYou", "指挥官身份被撤销的提示");
        m.put("messages.revokedAll", "全部撤销成功的提示，{count}=原人数");
        m.put("messages.voteStarted", "发起投票时发给同队玩家的广播，{player}=发起人，{team}=队伍名，{seconds}=持续秒数");
        m.put("messages.voteAlreadyActive", "已有投票进行中的提示（全服同时只允许一个投票）");
        m.put("messages.voteAlreadyCommander", "已是指挥官还发起投票的提示");
        m.put("messages.voteNeedTeam", "没加入任何队伍时发起/参与投票的提示");
        m.put("messages.voteTeamHasCommander", "自己队伍已有指挥官还发起投票的提示");
        m.put("messages.voteNoPlayers", "自己队伍没其他在线玩家无法投票的提示");
        m.put("messages.voteNoActive", "没有（本队的）投票时投票的提示");
        m.put("messages.voteSelf", "被提名人给自己投票的提示");
        m.put("messages.voteCastYes", "投赞成票的回执");
        m.put("messages.voteCastNo", "投反对票的回执");
        m.put("messages.voteCancelled", "管理员取消投票的广播");
        m.put("messages.votePassed", "投票通过的全服广播，{yes}=赞成数，{no}=反对数，{player}=当选人，{team}=队伍名");
        m.put("messages.votePassedTeamBusy", "票数通过但该队已有指挥官的广播，{yes}/{no}/{player}/{team}");
        m.put("messages.voteFailed", "投票未通过的全服广播，{yes}=赞成数，{no}=反对数，{player}=被提名人，{team}=队伍名");
        return m;
    }

    /**
     * 把 Gson 序列化出的纯 JSON 按字段路径插入中文注释行，
     * 生成玩家能直接看懂的配置文件。值永远来自当前配置，注释永远自动跟最新字段对齐。
     */
    static String annotate(String json) {
        Map<String, String> cm = comments();
        StringBuilder out = new StringBuilder(HEADER);
        Deque<String> path = new ArrayDeque<>();
        for (String line : json.split("\n", -1)) {
            String trimmed = line.strip();
            String indent = line.substring(0, line.length() - line.stripLeading().length());
            // 对象/数组收尾：弹出当前层级
            if (trimmed.startsWith("}") || trimmed.startsWith("]")) {
                if (!path.isEmpty()) path.pollLast();
                out.append(line).append('\n');
                continue;
            }
            // 数组里的元素对象（如 loot 的每一件物品）
            if (trimmed.equals("{") && !path.isEmpty()) {
                path.addLast("*");
                String c = cm.get(String.join(".", path));
                if (c != null) out.append(indent).append("// ").append(c).append('\n');
                out.append(line).append('\n');
                continue;
            }
            Matcher m = KEY.matcher(trimmed);
            if (m.lookingAt()) {
                String key = m.group(1);
                String full = String.join(".", path) + (path.isEmpty() ? "" : ".") + key;
                String c = cm.get(full);
                if (c != null) out.append(indent).append("// ").append(c).append('\n');
                out.append(line).append('\n');
                String rest = trimmed.substring(m.end()).strip();
                if (rest.equals("{") || rest.equals("[")) path.addLast(key);
            } else {
                out.append(line).append('\n');
            }
        }
        return out.toString();
    }

    // ==================== 工具方法 ====================

    /** 把提示文本里的 {key} 占位符替换成实际值；keyValues 依次是 key1, value1, key2, value2… */
    public static String fmt(String template, String... keyValues) {
        String out = template == null ? "" : template;
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            out = out.replace("{" + keyValues[i] + "}", keyValues[i + 1] == null ? "" : keyValues[i + 1]);
        }
        return out;
    }

    /** 带前缀的完整提示（前缀在 messages.prefix 里配置） */
    public static Component line(String body) {
        return Component.literal(INSTANCE.messages.prefix + body);
    }

    public int requiredLevel(String skill) {
        return switch (skill) {
            case "scan" -> levels.scan;
            case "airdrop" -> levels.airdrop;
            case "smoke" -> levels.smoke;
            case "artillery" -> levels.artillery;
            case "assault" -> levels.assault;
            case "retreat" -> levels.retreat;
            default -> 0;
        };
    }

    /** 使用该技能要消耗多少技能点（skillPoints.enabled=false 时返回 0） */
    public int requiredPoints(String skill) {
        if (skillPoints == null || !skillPoints.enabledSafe()) return 0;
        return switch (skill) {
            case "scan" -> Math.max(0, skillPoints.scan);
            case "airdrop" -> Math.max(0, skillPoints.airdrop);
            case "smoke" -> Math.max(0, skillPoints.smoke);
            case "artillery" -> Math.max(0, skillPoints.artillery);
            case "assault" -> Math.max(0, skillPoints.assault);
            case "retreat" -> Math.max(0, skillPoints.retreat);
            default -> 0;
        };
    }

    public int cooldownSeconds(String skill) {
        return switch (skill) {
            case "scan" -> cooldowns.scan;
            case "airdrop" -> cooldowns.airdrop;
            case "smoke" -> cooldowns.smoke;
            case "artillery" -> cooldowns.artillery;
            case "designator" -> cooldowns.designator;
            case "assault" -> cooldowns.assault;
            case "retreat" -> cooldowns.retreat;
            default -> 0;
        };
    }

    public boolean moduleEnabled(String skill) {
        return switch (skill) {
            case "scan" -> moduleScan;
            case "airdrop" -> moduleAirdrop;
            case "smoke" -> moduleSmoke;
            case "artillery", "designator" -> moduleArtillery;
            case "assault" -> moduleAssault;
            case "retreat" -> moduleRetreat;
            default -> false;
        };
    }

    /** 把配置里的自定义 NBT 原样合并到 ItemStack 上（不覆盖已有关键标签以外的新增键） */
    public static void applyNbt(ItemStack stack, String nbt) {
        if (nbt == null || nbt.isBlank()) return;
        try {
            CompoundTag extra = TagParser.parseTag(nbt);
            CompoundTag tag = stack.getOrCreateTag();
            for (String key : extra.getAllKeys()) {
                tag.put(key, extra.get(key).copy());
            }
        } catch (Exception ignored) {
        }
    }

    /** 解析物品 id，找不到时返回 null */
    public static Item itemOf(String id) {
        try {
            return ForgeRegistries.ITEMS.getValue(new net.minecraft.resources.ResourceLocation(id));
        } catch (Exception e) {
            return null;
        }
    }

    public static ItemStack buildStack(LootEntry entry) {
        Item item = itemOf(entry.item);
        if (item == null) return ItemStack.EMPTY;
        ItemStack stack = new ItemStack(item, Math.max(1, entry.count));
        applyNbt(stack, entry.nbt);
        return stack;
    }
}