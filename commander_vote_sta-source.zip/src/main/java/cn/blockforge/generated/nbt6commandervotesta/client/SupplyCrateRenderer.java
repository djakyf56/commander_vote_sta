package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.entity.SupplyCrateEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;

/**
 * 空投补给箱的渲染器：借用原版箱子的方块实体渲染器画出箱子模型，
 * 下落时保持端正（不旋转），像一箱货物被直直送下来。
 */
public class SupplyCrateRenderer extends EntityRenderer<SupplyCrateEntity> {
    /** 不属于任何世界的"模板箱子"，仅供渲染模型用（和原版物品栏里的箱子图一样） */
    private static final ChestBlockEntity MODEL_CHEST =
            new ChestBlockEntity(BlockPos.ZERO, Blocks.CHEST.defaultBlockState());

    public SupplyCrateRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.7F;
    }

    @Override
    public void render(SupplyCrateEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        // 箱子模型画在 (0,0,0)~(1,1,1)，平移半格让它对准实体中心
        poseStack.translate(-0.5, 0.0, -0.5);
        Minecraft.getInstance().getBlockEntityRenderDispatcher()
                .renderItem(MODEL_CHEST, poseStack, buffer, packedLight, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(SupplyCrateEntity entity) {
        return ResourceLocation.withDefaultNamespace("textures/atlas/blocks.png");
    }
}