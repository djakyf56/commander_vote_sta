package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 游戏总线事件：加载配置、注册 /commander 指令。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonEvents {

    private CommonEvents() {
    }

    @SubscribeEvent
    public static void onServerAboutToStart(ServerAboutToStartEvent event) {
        CommanderConfig.load();
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(CommanderCommands.build());
    }

    /**
     * 炮击自定义伤害的配套机制：自定义伤害开启时，原版爆炸对实体的伤害/击退
     * 改由 SkillManager.applyCustomDamage 按配置结算，这里把原版的结算列表清空，
     * 避免两套伤害叠加。爆炸的特效与拆方块不受影响。
     */
    @SubscribeEvent
    public static void onExplosionDetonate(net.minecraftforge.event.level.ExplosionEvent.Detonate event) {
        if (SkillManager.suppressVanillaExplosionDamage) {
            event.getAffectedEntities().clear();
        }
    }
}