package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 仅客户端：炮击落地时的摄像机摇晃。
 * 服务端每发炮弹爆炸时按"离爆心多远"发一个强度过来（S2CCameraShake），
 * 这里把强度存成一次抖动任务，在 ViewportEvent.ComputeCameraAngles 里
 * 按时间衰减叠加到相机的 yaw/pitch/roll 上——只动画面，不动玩家位置与速度。
 * 连续爆炸时取"更强的一次"覆盖，所以一轮炮击会是一段持续的晃动而不是各晃各的。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CameraShakeClient {

    /** 本次抖动的起始强度（0~1），<=0 表示没有抖动 */
    private static volatile float amp = 0.0F;
    /** 本次抖动的总时长（tick），用于按时间衰减 */
    private static volatile int duration = 0;
    /** 本次抖动开始时的游戏刻（用于算当前处于衰减曲线的哪个位置） */
    private static volatile long startTick = 0L;

    /** 强度 1.0 时的最大偏角（度）：yaw/pitch 用这个值，roll 取一半 */
    private static final float MAX_YAW = 2.6F;
    private static final float MAX_PITCH = 2.2F;
    private static final float MAX_ROLL = 1.4F;

    private CameraShakeClient() {
    }

    /**
     * 服务端收到一发炮弹的摇晃请求。强度已经按距离衰减过；
     * 这里只保留"更强的一次"：更大的强度直接覆盖，更小的强度在现有衰减上补一点。
     */
    public static void apply(float strength, int ticks) {
        Minecraft mc = Minecraft.getInstance();
        long now = mc.level == null ? 0L : mc.level.getGameTime();
        float remaining = currentAmp(now);
        if (strength >= remaining) {
            amp = Math.min(1.0F, strength);
            duration = Math.max(1, ticks);
            startTick = now;
        } else {
            // 已经有一轮更强的抖动在跑：把剩余强度叠加一点，让连发听起来/看起来是"一直在晃"
            amp = Math.min(1.0F, remaining + strength * 0.5F);
            duration = Math.max(1, Math.max(duration, ticks));
            startTick = now;
        }
    }

    /** 当前时刻的衰减系数：前 35% 时间保持满幅（爆炸刚来的那一下最猛），之后二次曲线衰减到 0 */
    private static float currentAmp(long now) {
        float a = amp;
        if (a <= 0.0F) return 0.0F;
        int d = Math.max(1, duration);
        float t = (now - startTick) / (float) d;
        if (t < 0.0F) t = 0.0F;
        if (t >= 1.0F) {
            amp = 0.0F;
            return 0.0F;
        }
        if (t < 0.35F) return a;
        float k = (t - 0.35F) / 0.65F;
        return a * (1.0F - k * k);
    }

    /**
     * 相机角度合成：两个不同频率的正弦叠加，避免看得出是"来回摇"的规律摆动；
     * roll 用更低频率，看起来像被冲击波带得歪了一下。
     * partialTick 让画面每帧平滑插值，不会一顿一顿的。
     */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        float a = currentAmp(now);
        if (a <= 0.001F) {
            if (amp != 0.0F) amp = 0.0F;
            return;
        }
        double t = now + event.getPartialTick(); // 单位：tick（20 tick = 1 秒）
        // 每 tick 前进 1，所以乘数是"每刻弧度"：1.4 ≈ 4.5Hz、3.3 ≈ 10.5Hz
        // —— 主频慢、次频快，叠出来是震动而不是慢悠悠地摇脑袋
        double w1 = t * 1.4;
        double w2 = t * 3.3;
        double mix = Math.sin(w1) * 0.62 + Math.sin(w2) * 0.38;
        double mix2 = Math.sin(w1 * 1.13 + 1.7) * 0.55 + Math.sin(w2 * 0.91 + 0.6) * 0.45;
        double mix3 = Math.sin(w1 * 0.71 + 3.1) * 0.7 + Math.sin(w2 * 1.21 + 2.2) * 0.3;
        event.setYaw(event.getYaw() + (float) (mix * MAX_YAW * a));
        event.setPitch(event.getPitch() + (float) (mix2 * MAX_PITCH * a));
        event.setRoll(event.getRoll() + (float) (mix3 * MAX_ROLL * a));
    }
}
