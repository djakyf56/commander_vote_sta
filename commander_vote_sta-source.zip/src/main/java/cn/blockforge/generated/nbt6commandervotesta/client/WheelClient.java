package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.core.ModNetwork;
import cn.blockforge.generated.nbt6commandervotesta.core.S2CWheelData;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 仅客户端：轮盘状态缓存 + 按键打开轮盘 + 发包。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class WheelClient {

    /** 服务端发来的最近一次状态；null 表示还没同步到 */
    private static volatile S2CWheelData state;
    /**
     * 按键已按下、正在等服务端回答"你是不是指挥官"：
     * 只有确认是指挥官的回应包到达后才真正打开轮盘，非指挥官按 V 什么也不会弹开
     * （服务端会同时发一条"只有指挥官才能……"的聊天提示）。
     */
    private static boolean pendingOpen;
    /** 等待回应的客户端 tick 计数：回应迟迟不到就自动放弃，避免"下一次回应突然弹窗" */
    private static int pendingOpenTicks;

    private WheelClient() {
    }

    /** 由网络包处理线程（主线程）调用 */
    public static void onWheelData(S2CWheelData msg) {
        state = msg;
        Minecraft mc = Minecraft.getInstance();
        if (pendingOpen) {
            pendingOpen = false;
            pendingOpenTicks = 0;
            if (msg.isCommander() && mc.screen == null && mc.player != null) {
                mc.setScreen(new SkillWheelScreen());
            }
        } else if (mc.screen instanceof SkillWheelScreen && !msg.isCommander()) {
            // 轮盘开着时被撤销指挥官资格：下一次每秒刷新回来就自动关掉
            mc.setScreen(null);
        }
    }

    public static S2CWheelData state() {
        return state;
    }

    public static void sendOpen() {
        ModNetwork.CHANNEL.sendToServer(new cn.blockforge.generated.nbt6commandervotesta.core.C2SWheelAction(
                cn.blockforge.generated.nbt6commandervotesta.core.C2SWheelAction.MODE_OPEN, "", ""));
    }

    public static void sendUse(String skill) {
        sendUse(skill, "");
    }

    /** 使用技能；data 为随技能附带的数据（空投 = 2 级菜单里选的物资类型 id） */
    public static void sendUse(String skill, String data) {
        ModNetwork.CHANNEL.sendToServer(new cn.blockforge.generated.nbt6commandervotesta.core.C2SWheelAction(
                cn.blockforge.generated.nbt6commandervotesta.core.C2SWheelAction.MODE_USE, skill, data));
    }

    /** 每个客户端 tick 检查一次按键：按下轮盘键（默认 V）时，轮盘没开就向服务端申请打开，已开就关闭 */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (pendingOpen && ++pendingOpenTicks > 40) {
            // 2 秒都没等到回应（服务端异常等）：放弃这次打开申请
            pendingOpen = false;
            pendingOpenTicks = 0;
        }
        while (ClientSetup.WHEEL_KEY.consumeClick()) {
            if (mc.screen instanceof SkillWheelScreen) {
                // 再按一次打开键 = 关闭轮盘
                mc.setScreen(null);
                pendingOpen = false;
                pendingOpenTicks = 0;
            } else if (mc.screen == null && mc.player != null) {
                // 先问服务端"他是不是指挥官"，回应确认后才开轮盘（见 onWheelData）
                pendingOpen = true;
                pendingOpenTicks = 0;
                sendOpen();
            }
        }
    }
}