package cn.blockforge.generated.nbt6commandervotesta.entity;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import cn.blockforge.generated.nbt6commandervotesta.core.TickHandler;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * 战术雾墙：一面缓慢向前推进的烟雾实体。
 * 本体不渲染（NoopRenderer），视觉完全由服务端粒子构成，因此敌方和队友看到同一面墙；
 * 只有指挥官同队的玩家会获得速度与跳跃增益。
 */
public class SmokeWallEntity extends Entity {
    private UUID ownerId;
    private Vec3 moveDir = new Vec3(0, 0, 1);
    private int age;
    private int duration = 400;

    public SmokeWallEntity(EntityType<? extends SmokeWallEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public SmokeWallEntity(Level level, Vec3 pos, Vec3 moveDir, UUID ownerId) {
        this(GeneratedMod.SMOKE_WALL.get(), level);
        this.moveDir = moveDir;
        this.ownerId = ownerId;
        CommanderConfig.SmokeCfg cfg = CommanderConfig.INSTANCE.smoke;
        this.duration = cfg.durationSeconds * 20;
        this.setPos(pos.x, pos.y, pos.z);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        age++;
        if (age > duration) {
            this.discard();
            return;
        }
        if (!(level() instanceof ServerLevel serverLevel)) return;

        CommanderConfig.SmokeCfg cfg = CommanderConfig.INSTANCE.smoke;
        // 前进
        Vec3 pos = position().add(moveDir.scale(cfg.movePerTick));
        this.setPos(pos.x, pos.y, pos.z);

        ParticleOptions particle = parseParticle(cfg.particle);
        // 雾墙平面：垂直于推进方向、横向铺开、纵向升高。
        // 隔一个 tick 才发一轮粒子：粒子本身能飘一小会儿，减半发包量肉眼几乎看不出差别。
        // 每一"列"只发一个数据包（粒子在整列高度内随机分布）：以前逐格发，
        // 一面 12x8 的墙每 2 tick 要打 96 个包，合并后只有 12 个，服务器和网络都轻松一大截
        if (age % 2 == 0) {
            Vec3 side = new Vec3(-moveDir.z, 0, moveDir.x).normalize();
            int columns = Math.max(3, (int) Math.round(cfg.width * 2));
            int perColumn = Math.max(4, (int) Math.round(cfg.height * 2) * 2);
            double halfH = Math.max(0.5, cfg.height / 2.0);
            for (int c = 0; c < columns; c++) {
                double off = (c - columns / 2.0) / 2.0;
                Vec3 p = pos.add(side.scale(off));
                serverLevel.sendParticles(particle, p.x, p.y + halfH, p.z,
                        perColumn, 0.25, halfH, 0.25, 0.005);
            }
        }

        // 每秒一次：风声音效 + 同队增益
        if (age % 20 == 0) {
            SoundEvent sound = parseSound(cfg.sound);
            if (sound != null) {
                serverLevel.playSound(null, getX(), getY(), getZ(), sound, SoundSource.PLAYERS, 0.6F, 1.0F);
            }
        }
        if (age % 10 == 0) {
            for (ServerPlayer p : serverLevel.getEntitiesOfClass(ServerPlayer.class,
                    getBoundingBox().inflate(cfg.width * 0.6, cfg.height, cfg.width * 0.6))) {
                if (isAlly(p)) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, cfg.speedAmplifier, true, false));
                    p.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, cfg.jumpAmplifier, true, false));
                }
            }
        }
    }

    private boolean isAlly(Player other) {
        if (ownerId != null && other.getUUID().equals(ownerId)) return true;
        return getTeam() != null && getTeam().isAlliedTo(other.getTeam());
    }

    /**
     * 粒子/音效解析结果缓存：按配置里的 id 字符串缓存，不再每次调用都查注册表。
     * 每个雾墙实体每 tick 都要用，缓存能省掉一大笔重复查询。
     */
    private static final java.util.Map<String, ParticleOptions> PARTICLE_CACHE =
            new java.util.concurrent.ConcurrentHashMap<>();
    // 音效 id 可能指向不存在的音效（注册表会返回 null），而 ConcurrentHashMap 不允许 null 值，
    // 所以这里用 Optional 包装缓存：查不到的结果也缓存下来，又不会因为 null 崩服。
    private static final java.util.Map<String, java.util.Optional<SoundEvent>> SOUND_CACHE =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** 配置热加载后调用：清掉缓存，让新配置立刻生效 */
    public static void clearCaches() {
        PARTICLE_CACHE.clear();
        SOUND_CACHE.clear();
    }

    public static ParticleOptions parseParticle(String id) {
        if (id == null || id.isBlank()) return ParticleTypes.CLOUD;
        return PARTICLE_CACHE.computeIfAbsent(id, SmokeWallEntity::doParseParticle);
    }

    private static ParticleOptions doParseParticle(String id) {
        try {
            var type = BuiltInRegistries.PARTICLE_TYPE.get(new ResourceLocation(id));
            if (type instanceof SimpleParticleType simple) return simple;
        } catch (Exception ignored) {
        }
        return ParticleTypes.CLOUD;
    }

    public static SoundEvent parseSound(String id) {
        if (id == null || id.isBlank()) return null;
        return SOUND_CACHE.computeIfAbsent(id, SmokeWallEntity::doParseSound).orElse(null);
    }

    private static java.util.Optional<SoundEvent> doParseSound(String id) {
        try {
            return java.util.Optional.ofNullable(
                    net.minecraftforge.registries.ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(id)));
        } catch (Exception e) {
            return java.util.Optional.empty();
        }
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.age = tag.getInt("Age");
        this.duration = tag.getInt("Duration");
        if (tag.hasUUID("Owner")) this.ownerId = tag.getUUID("Owner");
        if (tag.contains("MoveDirX")) {
            this.moveDir = new Vec3(tag.getDouble("MoveDirX"), tag.getDouble("MoveDirY"), tag.getDouble("MoveDirZ"));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Age", age);
        tag.putInt("Duration", duration);
        if (ownerId != null) tag.putUUID("Owner", ownerId);
        tag.putDouble("MoveDirX", moveDir.x);
        tag.putDouble("MoveDirY", moveDir.y);
        tag.putDouble("MoveDirZ", moveDir.z);
    }
}