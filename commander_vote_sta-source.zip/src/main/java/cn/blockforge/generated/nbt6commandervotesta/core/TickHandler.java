package cn.blockforge.generated.nbt6commandervotesta.core;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;

/** 服务端 tick 调度：延时任务（空投、炮击）+ 技能冷却 + 投票倒计时。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TickHandler {

    /** 延时任务 */
    public record PendingTask(long dueTick, Runnable task) {
    }

    private static final List<PendingTask> TASKS = new ArrayList<>();
    /** 技能冷却：玩家 -> 技能名 -> 冷却结束的游戏刻 */
    private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();
    /** 连发惩罚：玩家 -> 最近每次成功释放技能的游戏刻（队列，头部最老） */
    private static final Map<UUID, Deque<Long>> CASTS = new HashMap<>();
    /** 连发惩罚提醒过一次的玩家（惩罚结束后自动移出，下次再触发再提醒一次） */
    private static final java.util.Set<UUID> PENALTY_NOTIFIED = new java.util.HashSet<>();

    private TickHandler() {
    }

    /** 在 server 当前游戏刻 + delay 后执行 task */
    public static void schedule(MinecraftServer server, int delay, Runnable task) {
        synchronized (TASKS) {
            TASKS.add(new PendingTask(server.getTickCount() + Math.max(1, delay), task));
        }
    }

    public static void setCooldown(UUID player, String skill, int cooldownTicks) {
        synchronized (COOLDOWNS) {
            COOLDOWNS.computeIfAbsent(player, k -> new HashMap<>()).put(skill,
                    getServerTickBase(player) + cooldownTicks);
        }
    }

    private static long getServerTickBase(UUID player) {
        // 冷却以任务调度器的 tick 基准记录，实际由 server tick 递减时使用 server.getTickCount()
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return server != null ? server.getTickCount() : 0L;
    }

    /** 返回剩余冷却刻数，0 表示可用 */
    public static int cooldownRemaining(ServerPlayer player, String skill) {
        synchronized (COOLDOWNS) {
            Map<String, Long> map = COOLDOWNS.get(player.getUUID());
            if (map == null) return 0;
            Long until = map.get(skill);
            MinecraftServer server = player.server;
            if (until == null) return 0;
            long remain = until - server.getTickCount();
            return remain > 0 ? (int) remain : 0;
        }
    }

    public static void clearCooldowns(UUID player) {
        synchronized (COOLDOWNS) {
            COOLDOWNS.remove(player);
        }
        synchronized (CASTS) {
            CASTS.remove(player);
            PENALTY_NOTIFIED.remove(player);
        }
    }

    // ==================== 连发惩罚 ====================

    /**
     * 统计窗口内（windowTicks 游戏刻）玩家一共释放了几个技能，顺便清掉过期的记录。
     * 全局公共冷却同样记在 COOLDOWNS 里，键固定为 "global"。
     */
    public static int penaltyCastCount(MinecraftServer server, UUID player, int windowTicks) {
        synchronized (CASTS) {
            Deque<Long> q = CASTS.get(player);
            if (q == null) return 0;
            long cutoff = server.getTickCount() - windowTicks;
            while (!q.isEmpty() && q.peekFirst() <= cutoff) q.pollFirst();
            if (q.isEmpty()) CASTS.remove(player);
            return q.size();
        }
    }

    /** 记录一次成功的技能释放 */
    public static void recordCast(MinecraftServer server, UUID player) {
        synchronized (CASTS) {
            CASTS.computeIfAbsent(player, k -> new ArrayDeque<>()).addLast((long) server.getTickCount());
        }
    }

    /** 标记"已就连发惩罚提醒过一次"；返回 true 表示这是第一次（该提醒了） */
    public static boolean markPenaltyNotified(UUID player) {
        synchronized (CASTS) {
            return PENALTY_NOTIFIED.add(player);
        }
    }

    /** 惩罚过期（窗口内没有释放记录）时撤掉提醒标记，下次再触发还能再提醒一次 */
    public static void clearPenaltyNotifyIfExpired(MinecraftServer server, UUID player, int windowTicks) {
        synchronized (CASTS) {
            Deque<Long> q = CASTS.get(player);
            boolean empty = q == null || q.isEmpty()
                    || q.peekFirst() <= server.getTickCount() - windowTicks;
            if (empty) PENALTY_NOTIFIED.remove(player);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = event.getServer();
        long tick = server.getTickCount();

        // 平时没有任务时什么都不分配，避免每 tick 白白产生对象
        if (!TASKS.isEmpty()) {
            List<PendingTask> toRun = null;
            synchronized (TASKS) {
                Iterator<PendingTask> it = TASKS.iterator();
                while (it.hasNext()) {
                    PendingTask t = it.next();
                    if (t.dueTick() <= tick) {
                        it.remove();
                        if (toRun == null) toRun = new ArrayList<>();
                        toRun.add(t);
                    }
                }
            }
            if (toRun != null) {
                for (PendingTask t : toRun) {
                    try {
                        t.task().run();
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        // 两边自己都会在"没事可做"时立刻返回，不产生开销
        VoteManager.tick(server, tick);
        GlowMark.tick(server, tick);

        // 每 10 秒清理一次过期的冷却/连发记录：
        // 以前这些表只增不减，玩家越多、离线不掉的记录攒得越多（轻微内存泄漏）。
        // 清理后表里只剩"还没转完的冷却"和"还在惩罚窗口内的释放记录"，开销可以忽略。
        if (tick % 200 == 0) {
            synchronized (COOLDOWNS) {
                for (Map<String, Long> map : COOLDOWNS.values()) {
                    map.values().removeIf(until -> until <= tick);
                }
                COOLDOWNS.entrySet().removeIf(e -> e.getValue().isEmpty());
            }
            synchronized (CASTS) {
                long cutoff = tick - penaltyPurgeTicks();
                for (Deque<Long> q : CASTS.values()) {
                    while (!q.isEmpty() && q.peekFirst() <= cutoff) q.pollFirst();
                }
                CASTS.entrySet().removeIf(e -> e.getValue().isEmpty());
                PENALTY_NOTIFIED.removeIf(id -> !CASTS.containsKey(id));
            }
        }
    }

    /** 连发记录保留窗口：配置的窗口秒数，再加 10 秒余量（最少 60 秒） */
    private static long penaltyPurgeTicks() {
        int windowSeconds = 60;
        cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig cfg =
                cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.INSTANCE;
        if (cfg != null && cfg.penalty != null) windowSeconds = Math.max(1, cfg.penalty.windowSeconds);
        return Math.max(1200L, windowSeconds * 20L + 200L);
    }
}