package cn.blockforge.generated.nbt6commandervotesta.core;

import net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 私密发光轮廓：原版的服务端只把实体数据广播给所有跟踪者，所有人都能看到发光。
 * 这里换成「定向发包」：只向指定玩家发送一份带发光标志位的实体数据包，
 * 其他玩家的客户端根本收不到，因此完全看不到轮廓；被标记的玩家自己也不会亮。
 *
 * 服务端实体本身不发光，所以需要定期重发（原版标志位一变，客户端的数据会被覆盖）。
 */
public final class GlowMark {

    /** 原版实体数据里第 0 号是「共享标志字节」，发光是其中第 6 位（0x40），与原版一致 */
    private static final EntityDataAccessor<Byte> SHARED_FLAGS =
            new EntityDataAccessor<>(0, EntityDataSerializers.BYTE);
    private static final byte FLAG_GLOWING = 0x40;
    /** 每 10 tick 重发一次，防止原版标志位更新（起火、冲刺等）把发光覆盖掉 */
    private static final int RESEND_INTERVAL_TICKS = 10;

    /** 一个被标记的实体：目标 + 能看见的玩家 + 剩余时间 */
    private static final class Mark {
        final UUID targetId;
        final Set<UUID> viewerIds = new HashSet<>();
        int remainTicks;

        Mark(UUID targetId, Collection<UUID> viewers, int durationTicks) {
            this.targetId = targetId;
            this.viewerIds.addAll(viewers);
            this.remainTicks = durationTicks;
        }
    }

    private static final Map<UUID, Mark> MARKS = new HashMap<>();

    private GlowMark() {
    }

    /** 给目标加上私密发光，只有 viewers 里的玩家能看见。重复调用会刷新时长与可见名单。 */
    public static void mark(ServerPlayer target, Collection<ServerPlayer> viewers, int durationTicks) {
        Set<UUID> ids = new HashSet<>();
        for (ServerPlayer p : viewers) ids.add(p.getUUID());
        MARKS.put(target.getUUID(), new Mark(target.getUUID(), ids, Math.max(1, durationTicks)));
        sendGlow(target, viewers, true);
    }

    /** 每 tick 由 TickHandler 调用：定期重发 + 到期摘除。
     *  只在"重发 tick / 到期 tick"才解析观众名单并构造数据包，普通 tick 只减一个计数 */
    public static void tick(MinecraftServer server, long tickCount) {
        if (MARKS.isEmpty()) return;
        boolean sendTick = tickCount % RESEND_INTERVAL_TICKS == 0;
        List<UUID> finished = null;
        for (Map.Entry<UUID, Mark> entry : MARKS.entrySet()) {
            Mark mark = entry.getValue();
            ServerPlayer target = server.getPlayerList().getPlayer(mark.targetId);
            if (target == null) {
                // 目标下线/换实体，直接放弃
                if (finished == null) finished = new ArrayList<>();
                finished.add(entry.getKey());
                continue;
            }
            mark.remainTicks--;
            boolean expired = mark.remainTicks <= 0;
            if (sendTick || expired) {
                List<ServerPlayer> viewers = resolveViewers(server, mark.viewerIds);
                sendGlow(target, viewers, !expired);
            }
            if (expired) {
                if (finished == null) finished = new ArrayList<>();
                finished.add(entry.getKey());
            }
        }
        if (finished != null) {
            for (UUID id : finished) MARKS.remove(id);
        }
    }

    private static List<ServerPlayer> resolveViewers(MinecraftServer server, Set<UUID> viewerIds) {
        List<ServerPlayer> out = new ArrayList<>();
        for (UUID id : viewerIds) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) out.add(p);
        }
        return out;
    }

    /** 向每个可见者发送一份只含标志字节的实体数据包（客户端按 id 合并，不会覆盖其他数据） */
    private static void sendGlow(ServerPlayer target, Collection<ServerPlayer> viewers, boolean glow) {
        List<SynchedEntityData.DataValue<?>> values = List.of(flagsValue(target, glow));
        ClientboundSetEntityDataPacket packet = new ClientboundSetEntityDataPacket(target.getId(), values);
        for (ServerPlayer viewer : viewers) {
            try {
                viewer.connection.send(packet);
            } catch (Exception ignored) {
            }
        }
    }

    /** 根据实体当前状态拼出标志字节；glow 只写进这份包，不写入服务端实体 */
    private static SynchedEntityData.DataValue<?> flagsValue(Entity entity, boolean glow) {
        int flags = 0;
        if (entity.isOnFire()) flags |= 0x01;
        if (entity.isCrouching()) flags |= 0x02;
        if (entity.isPassenger()) flags |= 0x04;
        if (entity.isSprinting()) flags |= 0x08;
        if (entity.isSwimming()) flags |= 0x10;
        if (entity.isInvisible()) flags |= 0x20;
        if (glow) flags |= FLAG_GLOWING;
        // 滑翔标志位在 LivingEntity 上；目标是玩家，一定是 LivingEntity
        if (entity instanceof LivingEntity living && living.isFallFlying()) flags |= 0x80;
        return SynchedEntityData.DataValue.create(SHARED_FLAGS, (byte) flags);
    }
}
