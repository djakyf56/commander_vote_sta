package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import cn.blockforge.generated.nbt6commandervotesta.entity.AirdropBeamEntity;
import cn.blockforge.generated.nbt6commandervotesta.entity.SmokeWallEntity;
import cn.blockforge.generated.nbt6commandervotesta.entity.SupplyCrateEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Team;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

import java.util.ArrayList;
import java.util.List;

/** 六个技能的实现，以及炮击支援的两套方案（直接天降炮击 / 炮击工具包）。 */
public final class SkillManager {

    private SkillManager() {
    }

    /** 炮弹下坠弹道的起始高度（落点上方多少格） */
    private static final double TRAIL_TOP = 20.0;

    // ==================== 入口 ====================

    /** 技能统一入口。返回错误消息，null 表示成功。data 为空投等技能附带的数据（如空投类型 id）。 */
    public static String useSkill(ServerPlayer commander, String skill, String data) {
        CommanderSavedData data0 = CommanderSavedData.get(commander.server);
        CommanderConfig cfg = CommanderConfig.INSTANCE;
        if (!data0.isEnabled()) return cfg.messages.systemDisabled;
        if (!cfg.moduleEnabled(skill)) return cfg.messages.moduleDisabled;

        // 全局公共冷却：释放任意技能后所有技能一起进入 1.5 秒冷却（可配置）
        int globalRemain = TickHandler.cooldownRemaining(commander, "global");
        if (globalRemain > 0) return CommanderConfig.fmt(cfg.messages.globalCooldown,
                "seconds", String.valueOf((globalRemain + 19) / 20));

        int remain = TickHandler.cooldownRemaining(commander, skill);
        if (remain > 0) return CommanderConfig.fmt(cfg.messages.cooldown,
                "seconds", String.valueOf((remain + 19) / 20));

        if (cfg.levels.enabled && data0.isLevelLimitEnabled()) {
            int need = cfg.requiredLevel(skill);
            int current = currentLevel(commander);
            if (current < need) {
                return CommanderConfig.fmt(cfg.messages.levelTooLow,
                        "required", String.valueOf(need),
                        "current", String.valueOf(current));
            }
        }

        // 技能点检查：除了等级达标，还要有足够的技能点（记分榜，可自定义目标名）。
        // 连发惩罚：60 秒内释放超过 allowedCount 个技能，本次起消耗按倍率加倍（可配置）。
        int pointCost = effectivePoints(commander, skill);
        boolean penalized = pointCost > 0 && isPenalized(commander);
        int windowTicks = Math.max(1, cfg.penalty.windowSeconds) * 20;
        if (pointCost > 0) {
            int points = currentPoints(commander);
            if (points < pointCost) {
                return CommanderConfig.fmt(cfg.messages.notEnoughPoints,
                        "cost", String.valueOf(pointCost),
                        "current", String.valueOf(points));
            }
        }

        switch (skill) {
            case "scan" -> scan(commander);
            // 空投与直接炮击：准星必须指到方块才能释放（与客户端瞄准预览的判定一致）
            case "airdrop" -> {
                if (!isAimingAtBlock(commander, 64.0)) return cfg.messages.needBlock;
                airdrop(commander, data);
            }
            case "smoke" -> smoke(commander);
            case "artillery" -> {
                if ("toolkit".equalsIgnoreCase(cfg.artillery.mode)) {
                    grantToolkit(commander);
                } else {
                    if (!isAimingAtBlock(commander, 128.0)) return cfg.messages.needBlock;
                    artilleryStrike(commander);
                }
            }
            case "assault" -> assault(commander);
            case "retreat" -> retreat(commander);
            default -> {
                return CommanderConfig.fmt(cfg.messages.unknownSkill, "skill", skill);
            }
        }
        int cd = cfg.cooldownSeconds(skill);
        if (cd > 0) TickHandler.setCooldown(commander.getUUID(), skill, cd * 20);
        // 全局公共冷却：成功释放任何技能后给所有技能上同一把锁
        if (cfg.cooldowns.globalTicks > 0) {
            TickHandler.setCooldown(commander.getUUID(), "global", cfg.cooldowns.globalTicks);
        }
        // 连发惩罚：记录本次释放；触发惩罚时只提醒一次，过期后自动复位
        TickHandler.recordCast(commander.server, commander.getUUID());
        if (penalized) {
            if (TickHandler.markPenaltyNotified(commander.getUUID())) {
                commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(
                        cfg.messages.penaltyActive,
                        "seconds", String.valueOf(Math.max(1, cfg.penalty.windowSeconds)),
                        "count", String.valueOf(Math.max(0, cfg.penalty.allowedCount) + 1),
                        "mult", String.valueOf(fmtMult(cfg.penalty.multiplier)))));
            }
        } else {
            TickHandler.clearPenaltyNotifyIfExpired(commander.server, commander.getUUID(), windowTicks);
        }
        // 技能真正用出去后才扣点：等级/冷却/技能点检查都通过、技能执行成功才走到这里
        if (pointCost > 0) {
            int left = spendPoints(commander, pointCost);
            String spentMsg = cfg.messages.pointsSpent;
            if (spentMsg != null && !spentMsg.isBlank()) {
                commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(spentMsg,
                        "cost", String.valueOf(pointCost),
                        "left", String.valueOf(left))));
            }
        }
        return null;
    }

    /** 连发惩罚倍率的显示文本：整数就写整数（2），带小数照写（1.5） */
    private static String fmtMult(double mult) {
        return mult == Math.floor(mult) ? String.valueOf((long) mult) : String.valueOf(mult);
    }

    /** 炮击/空投的释放条件：准星必须指到方块（探测距离与服务端落点结算用的同一个数值） */
    private static boolean isAimingAtBlock(ServerPlayer player, double range) {
        HitResult hit = player.pick(range, 1.0F, false);
        return hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK;
    }

    /**
     * 两点之间是否被方块挡住（"不能穿墙"的通用判定）：
     * 从 from 向 to 发射一条碰撞射线，撞到任何方块就算挡住。
     * 只在技能结算的一瞬间各跑一条射线，不做逐 tick 检测，开销可以忽略。
     */
    static boolean blockedLine(Level level, Vec3 from, Vec3 to) {
        if (from.distanceToSqr(to) < 1.0E-6) return false;
        HitResult hit = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, null));
        return hit != null && hit.getType() != HitResult.Type.MISS;
    }

    /**
     * 炮弹垂直下落时的真实落点高度：从建筑上限沿 (x, z) 这一列向下打一条射线，
     * 返回第一个撞到的方块的上表面 Y（整列没有方块就照原样返回 aimY）。
     * 这样准星瞄在室内地板上时，炮弹会被屋顶挡在屋顶上炸，而不是穿进屋里。
     * 每发炮弹只在落点定死前跑一次射线，开销可以忽略。
     */
    private static double landingSurfaceY(ServerLevel level, double x, double z, double aimY) {
        double fromY = level.getMaxBuildHeight() + 2.0;
        double toY = level.getMinBuildHeight() - 2.0;
        if (fromY <= toY) return aimY;
        HitResult hit = level.clip(new ClipContext(new Vec3(x, fromY, z), new Vec3(x, toY, z),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, null));
        if (hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK) {
            // 垂直下落的炮弹先撞到的一定是这一列最高的方块的顶面：
            // 屋顶在瞄点上方就停在屋顶上炸（挡住），山坡在瞄点下方就落到坡面上炸
            return blockHit.getBlockPos().getY() + 1.0;
        }
        return aimY;
    }

    /**
     * 炮弹沿一条斜线飞来（迫击炮模式）时的真实撞击点：
     * 从 start 向 intended（准星落点）打一条射线，撞到任何方块就停在那一面上
     * （屋顶、墙、山坡都会挡住，炮弹不会穿过去）。没命中方块则仍用 intended。
     */
    private static Vec3 mortarImpact(ServerLevel level, Vec3 start, Vec3 intended) {
        if (start.distanceToSqr(intended) < 1.0E-6) return intended;
        HitResult hit = level.clip(new ClipContext(start, intended,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, null));
        if (hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK) {
            return hit.getLocation();
        }
        return intended;
    }

    /**
     * 迫击炮弹道的起点：落点斜上方 TRAIL_TOP 格，水平方向沿"来袭方位"反向拉开一段距离。
     * 仰角 45° 时水平距离 = 高度（20 格），仰角越大越陡、水平距离越短。
     * fromYaw：炮弹飞来的那一侧的 Minecraft 朝向角（0=南、90=西、180=北、-90=东）。
     */
    static Vec3 mortarStart(Vec3 land, double trailTop, double angleDeg, float fromYaw) {
        double rad = Math.toRadians(Math.max(15.0, Math.min(80.0, angleDeg)));
        double horiz = trailTop / Math.tan(rad);
        // Minecraft yaw 的朝向向量 = (-sin, cos)：0 度朝 +Z（南）
        double yawRad = Math.toRadians(fromYaw);
        return new Vec3(land.x - Math.sin(yawRad) * horiz, land.y + trailTop,
                land.z + Math.cos(yawRad) * horiz);
    }

    /**
     * 迫击炮的"来袭方位角"（指炮弹从哪一侧飞来）：
     *  · south/west/north/east=固定方位；
     *  · look（默认）= 跟着释放者视线：他朝哪看，炮弹就从他**身后**越过头顶飞向落点
     *    （等于己方阵地在释放者背后，看着最自然），所以要在视线折出的四方向上再加 180 度。
     */
    static float mortarBearing(ServerPlayer caller, String bearing) {
        String s = bearing == null ? "look" : bearing.trim().toLowerCase(java.util.Locale.ROOT);
        switch (s) {
            case "south":
            case "from_south":
            case "s":
                return 0.0F;
            case "west":
            case "from_west":
            case "w":
                return 90.0F;
            case "north":
            case "from_north":
            case "n":
                return 180.0F;
            case "east":
            case "from_east":
            case "e":
                return -90.0F;
            default:
                float y = cardinalYaw(caller.getLookAngle()) + 180.0F; // 从身后打来
                if (y > 180.0F) y -= 360.0F;
                return y;
        }
    }

    static boolean isMortarApproach(String approach) {
        if (approach == null) return false;
        String s = approach.trim().toLowerCase(java.util.Locale.ROOT);
        return s.equals("mortar") || s.equals("oblique") || s.equals("slant") || s.equals("tilt");
    }

    /**
     * 把视线方向折成"东南西北"四方向之一的实体朝向角（yaw）：
     * 0=南(+Z)、90=西(-X)、180=北(-Z)、-90=东(+X)。空投的载具/维修箱用这个，
     * 释放者看向哪个半轴，生成的实体就脸朝哪边，只认四方向。
     */
    static float cardinalYaw(Vec3 look) {
        if (Math.abs(look.z) >= Math.abs(look.x)) return look.z >= 0 ? 0.0F : 180.0F;
        return look.x >= 0 ? -90.0F : 90.0F;
    }

    /** 当前是否处于连发惩罚（60 秒窗口内已释放数达到上限） */
    public static boolean isPenalized(ServerPlayer player) {
        CommanderConfig cfg = CommanderConfig.INSTANCE;
        if (!cfg.penalty.enabled) return false;
        int windowTicks = Math.max(1, cfg.penalty.windowSeconds) * 20;
        int count = TickHandler.penaltyCastCount(player.server, player.getUUID(), windowTicks);
        return count >= Math.max(0, cfg.penalty.allowedCount);
    }

    /** 某个技能当前的实际技能点消耗：基础消耗 × 惩罚倍率（未触发惩罚时就是基础消耗） */
    public static int effectivePoints(ServerPlayer player, String skill) {
        int cost = CommanderConfig.INSTANCE.requiredPoints(skill);
        if (cost > 0 && isPenalized(player)) {
            cost = (int) Math.ceil(cost * Math.max(1.0, CommanderConfig.INSTANCE.penalty.multiplier));
        }
        return cost;
    }

    /** 炮击坐标仪（工具包方案）的使用逻辑。返回错误消息，null 表示成功。 */
    public static String useDesignator(ServerPlayer player, ItemStack stack) {
        CommanderConfig cfg = CommanderConfig.INSTANCE;
        if (!cfg.moduleArtillery) return cfg.messages.artilleryModuleOff;
        // 坐标仪也算一次技能释放：同样受全局公共冷却约束
        int globalRemain = TickHandler.cooldownRemaining(player, "global");
        if (globalRemain > 0) return CommanderConfig.fmt(cfg.messages.globalCooldown,
                "seconds", String.valueOf((globalRemain + 19) / 20));
        int remain = TickHandler.cooldownRemaining(player, "designator");
        if (remain > 0) return CommanderConfig.fmt(cfg.messages.designatorCooldown,
                "seconds", String.valueOf((remain + 19) / 20));
        artilleryStrikeAt(player, aimPoint(player.pick(128.0, 1.0F, false)));
        int cd = cfg.cooldownSeconds("designator");
        if (cd > 0) TickHandler.setCooldown(player.getUUID(), "designator", cd * 20);
        if (cfg.cooldowns.globalTicks > 0) {
            TickHandler.setCooldown(player.getUUID(), "global", cfg.cooldowns.globalTicks);
        }
        TickHandler.recordCast(player.server, player.getUUID());
        return null;
    }

    // ==================== 技能1：侦察扫描 ====================

    private static void scan(ServerPlayer commander) {
        ServerLevel level = commander.serverLevel();
        CommanderConfig.ScanCfg cfg = CommanderConfig.INSTANCE.scan;

        Vec3 center = commander.position();
        // 声波粒子：三圈扩散环
        ParticleOptions particle = SmokeWallEntity.parseParticle(cfg.particle);
        for (int ring = 1; ring <= 3; ring++) {
            double r = ring * 1.5;
            final double rr = r;
            TickHandler.schedule(commander.server, ring * 4, () -> {
                for (int i = 0; i < 24; i++) {
                    double a = Math.PI * 2 * i / 24;
                    level.sendParticles(particle,
                            center.x + Math.cos(a) * rr, center.y + 1.0, center.z + Math.sin(a) * rr,
                            1, 0.05, 0.05, 0.05, 0.0);
                }
            });
        }
        SoundEvent sound = SmokeWallEntity.parseSound(cfg.sound);
        if (sound != null) {
            level.playSound(null, commander.blockPosition(), sound, SoundSource.PLAYERS, 1.0F, 1.4F);
        }

        // 半径内非同队玩家获得发光轮廓；谁能看见由 glowVisibility 配置决定
        int marked = 0;
        List<ServerPlayer> enemies = level.getEntitiesOfClass(ServerPlayer.class,
                commander.getBoundingBox().inflate(cfg.radius),
                p -> p != commander && !isAlly(commander, p));
        String visibility = cfg.glowVisibility == null ? "team" : cfg.glowVisibility.trim().toLowerCase(java.util.Locale.ROOT);
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        String seenBy;
        if (visibility.equals("all")) {
            // 原版方式：真发光效果，全服可见（包括敌人自己）
            for (ServerPlayer enemy : enemies) {
                enemy.addEffect(new MobEffectInstance(MobEffects.GLOWING, cfg.glowSeconds * 20, 0));
                marked++;
            }
            seenBy = msgs.scanVisibilityAll;
        } else {
            // 私密发光：服务端实体不带发光标志，只向指定玩家发定向数据包
            List<ServerPlayer> viewers = visibility.equals("self")
                    ? List.of(commander)
                    : teamTargets(commander);
            for (ServerPlayer enemy : enemies) {
                GlowMark.mark(enemy, viewers, cfg.glowSeconds * 20);
                marked++;
            }
            seenBy = viewers.size() == 1 ? msgs.scanVisibilitySelf : msgs.scanVisibilityTeam;
        }
        commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.scanDone,
                "radius", String.valueOf((int) cfg.radius),
                "count", String.valueOf(marked),
                "seconds", String.valueOf(cfg.glowSeconds),
                "visibility", seenBy)));
        if (!enemies.isEmpty()) {
            // 只把被标记名单发给自己和同队玩家，敌方收不到
            StringBuilder sb = new StringBuilder();
            for (ServerPlayer e : enemies) sb.append(e.getGameProfile().getName()).append(" ");
            sendToTeam(commander, CommanderConfig.line(CommanderConfig.fmt(msgs.scanList,
                    "names", sb.toString().trim())));
        }
    }

    // ==================== 技能2：空投补给 ====================

    private static void airdrop(ServerPlayer commander, String typeId) {
        ServerLevel level = commander.serverLevel();
        CommanderConfig.AirdropCfg cfg = CommanderConfig.INSTANCE.airdrop;
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;

        HitResult hit = commander.pick(64.0, 1.0F, false);
        Vec3 target = hit.getLocation();
        BlockPos land = BlockPos.containing(target);

        // 资源类型：2 级菜单选的类型 id；没带或找不到就按物资箱（现有逻辑）处理
        CommanderConfig.SupplyTypeEntry type = CommanderConfig.INSTANCE.supplyType(typeId);
        String typeName = supplyTypeName(type);
        String entityId = type == null || type.entity == null ? "" : type.entity.trim();
        boolean spawnEntity = !entityId.isEmpty();

        // 信标光柱实体：落点插一根原版样式的光柱（颜色可配置），到点自动消失
        int beamTicks = cfg.beamSeconds * 20;
        level.addFreshEntity(new AirdropBeamEntity(level, land, commander.getUUID(), beamTicks));
        SoundEvent sound = SmokeWallEntity.parseSound(cfg.sound);
        if (sound != null) {
            level.playSound(null, land, sound, SoundSource.PLAYERS, 1.0F, 1.0F);
        }

        // 光柱结束后落地：
        //  · 类型配置了 entity（如载具维修箱）→ 原地生成该实体（默认留空不会走到这里）；
        //  · 否则按物资箱逻辑：补给箱实体从天而降，落地按 landAsItems 变掉落物（默认）或放箱子。
        final BlockPos dropPos = land;
        if (spawnEntity) {
            // 朝向：释放瞬间按指挥官的视线折成东南西北四方向（空投载具/维修箱都是方正摆放，
            // 斜着看也只认离视线最近的那一面），落地生成时沿用它
            final float facing = cardinalYaw(commander.getLookAngle());
            // 该类型配置的自定义 NBT（留空 = 不带）
            final String entityNbt = type.nbt == null ? "" : type.nbt.trim();
            TickHandler.schedule(commander.server, beamTicks, () -> {
                if (!level.isLoaded(dropPos)) return;
                Vec3 center = new Vec3(dropPos.getX() + 0.5, dropPos.getY() + 1.0, dropPos.getZ() + 0.5);
                // 强制走"直接生成"：在落点坐标上原地造出实体（不再用 /summon 命令，
                // 那条路有些载具会把位置吃成 0,0 世界原点）。实体 id / NBT 写错时
                // 照样不会生成空壳载具，原因会发到释放者聊天栏。
                spawnVehicleDirect(level, commander, center, facing, entityId, entityNbt);
            });
            commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.airdropCalledEntity,
                    "type", typeName, "seconds", String.valueOf(cfg.beamSeconds), "entity", entityId)));
            return;
        }
        if (type != null && !typeId.isBlank()) {
            // 明确选了某个类型但没配 entity：提醒一句，然后按物资箱逻辑继续
            commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.airdropEntityEmpty, "type", typeName)));
        }
        TickHandler.schedule(commander.server, beamTicks, () -> {
            int h = Math.max(4, cfg.height);
            BlockPos spawn = dropPos.above(h);
            while (!level.getBlockState(spawn).isAir() && h < 48) {
                h++;
                spawn = dropPos.above(h);
            }
            // 不穿墙：补给箱沿这一列直线下落（实体本身无碰撞），中途碰到任何方块
            // （屋顶、挑檐、有人在半空搭的方块）就停在该方块顶上落地，不再穿下去
            BlockPos crateLand = spawn;
            while (crateLand.getY() > dropPos.getY() && level.getBlockState(crateLand.below()).isAir()) {
                crateLand = crateLand.below();
            }
            level.addFreshEntity(new SupplyCrateEntity(level, spawn, crateLand, commander.getUUID()));
        });

        String body = cfg.landAsItems
                ? CommanderConfig.fmt(msgs.airdropCalledItems,
                        "type", typeName, "seconds", String.valueOf(cfg.beamSeconds))
                : CommanderConfig.fmt(msgs.airdropCalledChest,
                        "type", typeName, "seconds", String.valueOf(cfg.beamSeconds))
                        + (cfg.chestSeconds > 0 ? CommanderConfig.fmt(
                                msgs.airdropChestDespawn,
                                "seconds", String.valueOf(cfg.chestSeconds)) : "");
        commander.sendSystemMessage(CommanderConfig.line(body));
    }

    /** 空投类型在提示里显示的名字：配置了 name 用 name，否则用 id */
    private static String supplyTypeName(CommanderConfig.SupplyTypeEntry type) {
        if (type == null) return "物资箱";
        String name = type.name == null ? "" : type.name.trim();
        return name.isEmpty() ? String.valueOf(type.id) : name;
    }

    /**
     * 空投落地直接生成掉落物（不生成箱子）：
     * 按配置的 airdrop.loot 清单逐件撒在落点，带一点随机散开，看起来像物资砸下来散了一地。
     */
    public static void dropAirdropLoot(ServerLevel level, BlockPos pos) {
        CommanderConfig.AirdropCfg cfg = CommanderConfig.INSTANCE.airdrop;
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.5;
        double z = pos.getZ() + 0.5;
        for (CommanderConfig.LootEntry entry : cfg.loot) {
            ItemStack stack = CommanderConfig.buildStack(entry);
            if (stack.isEmpty()) continue;
            ItemEntity drop = new ItemEntity(level, x, y, z, stack);
            drop.setPickUpDelay(10);
            double a = level.random.nextDouble() * Math.PI * 2;
            double spd = 0.08 + level.random.nextDouble() * 0.12;
            drop.setDeltaMovement(Math.cos(a) * spd, 0.12 + level.random.nextDouble() * 0.08, Math.sin(a) * spd);
            level.addFreshEntity(drop);
        }
    }

    public static void fillCrate(ServerLevel level, BlockPos pos) {
        if (level.getBlockState(pos).getBlock() instanceof ChestBlock
                && level.getBlockEntity(pos) instanceof ChestBlockEntity chest) {
            CommanderConfig.AirdropCfg cfg = CommanderConfig.INSTANCE.airdrop;
            int slot = 0;
            for (CommanderConfig.LootEntry entry : cfg.loot) {
                ItemStack stack = CommanderConfig.buildStack(entry);
                if (stack.isEmpty() || slot >= chest.getContainerSize()) continue;
                chest.setItem(slot++, stack);
            }
            if (!cfg.crateNbt.isBlank()) {
                try {
                    CompoundTag extra = TagParser.parseTag(cfg.crateNbt);
                    CompoundTag merged = chest.saveWithFullMetadata();
                    merged.merge(extra);
                    chest.load(merged);
                } catch (Exception ignored) {
                }
            }
            chest.setChanged();
        }
    }

    // ==================== 技能3：烟雾掩护 ====================

    private static void smoke(ServerPlayer commander) {
        ServerLevel level = commander.serverLevel();
        CommanderConfig.SmokeCfg cfg = CommanderConfig.INSTANCE.smoke;

        // 自定义实体：配置 smoke.customEntity 留空时，默认不生成任何实体
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        String entityId = cfg.customEntity == null ? "" : cfg.customEntity.trim();
        if (entityId.isEmpty()) {
            commander.sendSystemMessage(CommanderConfig.line(msgs.smokeNoEntity));
            return;
        }
        net.minecraft.world.entity.EntityType<?> type =
                net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getValue(
                        new ResourceLocation(entityId));
        if (type == null) {
            commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.smokeBadEntity, "entity", entityId)));
            return;
        }

        // 生成位置改为准心位置：探测准星指向的方块/实体表面，探测不到就落在视线方向的最远处。
        // 准星指的是方块时整体向上抬 upOffset 格（默认 3），避免雾墙嵌进地面里。
        HitResult hit = commander.pick(Math.max(2.0, cfg.spawnRange), 1.0F, false);
        // 探测命中点（未抬高）：这是客户端预览线画在的位置。
        // "不穿墙"的遮挡检测必须沿这个高度打射线，才能和预览完全一致——
        // 之前用抬高 3 格后的位置检测，矮墙/屋顶会从射线上方"漏过去"，预览明明止步、实际却穿墙。
        Vec3 probeCenter = hit.getLocation();
        Vec3 center = probeCenter;
        if (hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK) {
            center = center.add(0, Math.max(0.0, cfg.upOffset), 0);
        }

        // 雾墙平面垂直于视线：墙面沿"侧向"（左右）铺开，推进方向仍是视线方向
        Vec3 dir = commander.getLookAngle().multiply(1, 0, 1);
        if (dir.lengthSqr() < 1.0E-4) dir = new Vec3(0, 0, 1);
        dir = dir.normalize();
        float yaw = (float) (Math.atan2(dir.z, dir.x) * (180.0 / Math.PI)) - 90.0F;
        Vec3 side = new Vec3(-dir.z, 0, dir.x).normalize();

        // 面数完全按配置来：
        //  · smoke.count > 0：总面数（含中间一面）严格等于 count，偶数时右侧多一面；
        //  · smoke.count = 0：老逻辑，按 smoke.width / smoke.spreadStep 自动算每侧层数，封顶 maxSpreadLayers。
        double step = Math.max(0.5, cfg.spreadStep);
        int leftLayers;
        int rightLayers;
        if (cfg.count > 0) {
            int extra = Math.min(cfg.count - 1, 32); // 硬性安全上限：算上中间一面最多 33 面
            leftLayers = Math.max(0, extra / 2);
            rightLayers = Math.max(0, (extra + 1) / 2);
        } else {
            int layers = (int) Math.floor(cfg.width / 2.0 / step + 1.0E-9);
            layers = Math.min(Math.max(layers, 0), Math.max(0, cfg.maxSpreadLayers));
            leftLayers = layers;
            rightLayers = layers;
        }

        if (!spawnSmokeEntity(level, entityId, center, yaw, cfg)) {
            commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.smokeSpawnFailed, "entity", entityId)));
            return;
        }
        int interval = Math.max(0, cfg.spreadIntervalTicks);
        spawnLayers(level, entityId, center, probeCenter, side, yaw, cfg, 1, rightLayers, step, interval, commander.server);
        spawnLayers(level, entityId, center, probeCenter, side, yaw, cfg, -1, leftLayers, step, interval, commander.server);

        SoundEvent sound = SmokeWallEntity.parseSound(cfg.sound);
        if (sound != null) {
            level.playSound(null, commander.blockPosition(), sound, SoundSource.PLAYERS, 0.8F, 1.0F);
        }
        commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.smokeDone,
                "count", String.valueOf(1 + leftLayers + rightLayers), "entity", entityId)));
    }

    /**
     * 从中心往 sign 方向（+1=右 / -1=左）铺 layers 层雾墙：
     * 每隔 spreadIntervalTicks 长出一层，interval=0 则一次性全部出现。
     * 不穿墙（smoke.blockWalls，默认开）：中心到某一层之间隔着方块时，
     * 这一层和它后面（更远）的层都不再生成——另一个方向的展开不受影响。
     * 遮挡检测沿 checkCenter（准星命中点、未抬高）打射线，与客户端预览线的止步规则一致；
     * 实体本身仍生成在抬高后的 center 高度上。
     */
    private static void spawnLayers(ServerLevel level, String entityId,
                                    Vec3 center, Vec3 checkCenter, Vec3 side, float yaw, CommanderConfig.SmokeCfg cfg,
                                    int sign, int layers, double step, int interval, net.minecraft.server.MinecraftServer server) {
        final boolean[] stopped = new boolean[1];
        for (int k = 1; k <= layers; k++) {
            final int kk = k;
            Runnable spawnOne = () -> {
                if (stopped[0]) return;
                Vec3 offset = side.scale(step * kk * sign);
                if (cfg.blockWalls && blockedLine(level, checkCenter, checkCenter.add(offset))) {
                    stopped[0] = true;
                    return;
                }
                spawnSmokeEntity(level, entityId, center.add(offset), yaw, cfg);
            };
            if (interval == 0) spawnOne.run();
            else TickHandler.schedule(server, k * interval, spawnOne);
        }
    }

    /**
     * 空投载具/维修箱专用：在落点坐标上**直接生成**实体（不走 /summon 命令）。
     * 之前那套"像玩家亲手敲命令一样执行 /summon <id>    <NBT>"的写法会把位置交给命令源，
     * 部分载具模组（如 [SBW]卓越前线）因此固定生成在世界的 0,0 原点——所以这里一律
     * 改成按坐标直接造实体：位置就是光柱落点，朝向按释放者视线折出的东南西北四方向。
     * 实体 id / NBT 本身写错时不生成"空壳载具"，原因直接发到释放者聊天栏。
     */
    private static void spawnVehicleDirect(ServerLevel level, ServerPlayer reporter, Vec3 pos,
                                           float yaw, String entityId, String nbt) {
        // 一、实体 id 写得对不对（缺冒号前缀、有非法字符等）
        ResourceLocation rid;
        try {
            rid = new ResourceLocation(entityId);
        } catch (Exception e) {
            reportVehicle(reporter, "§c空投载具实体 id 写法有误：§f" + entityId +
                    "§c（要带模组命名空间，如 §fsomemod:vehicle_tank§c）");
            return;
        }
        if (net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getValue(rid) == null) {
            reportVehicle(reporter, "§c空投载具实体 id 不存在：§f" + entityId +
                    "§c（游戏里没有这个实体，检查拼写和是否装了对应模组）");
            return;
        }
        // 二、NBT 语法先过一遍游戏自己的解析器，写错就只报错、不生成残缺载具
        if (nbt != null && !nbt.isBlank()) {
            try {
                TagParser.parseTag(nbt.trim());
            } catch (Exception e) {
                reportVehicle(reporter, "§c空投载具 NBT 语法错误：§f" + e.getMessage() +
                        "§c。配置里实际读到的内容是：§f" + nbt +
                        "§c（JSON 里 NBT 的双引号必须写成 \\\"，可先用 /commander checknbt <文本> 检验）" +
                        CommanderConfig.nestedArrayHint(nbt));
                return;
            }
        }
        // 三、按坐标直接生成（NBT 里没写 Rotation 时自动补上四方向朝向）
        if (!spawnCustomEntity(level, entityId, pos, yaw, nbt)) {
            reportVehicle(reporter, "§c空投载具无法生成：§f" + entityId +
                    "§c（这个实体可能不允许被直接创建，换一个实体 id 试试）");
            return;
        }
        if (reporter != null) {
            reporter.sendSystemMessage(CommanderConfig.line("§a空投载具已落地：§f" + entityId +
                    "§a（位置 §f" + String.format("%.1f, %.1f, %.1f", pos.x, pos.y, pos.z) +
                    "§a，朝向 §f" + facingName(yaw) + "§a）"));
        }
    }

    /** 四方向朝向的中文名（生成成功的回显用） */
    private static String facingName(float yaw) {
        if (yaw == 0.0F) return "南(+Z)";
        if (yaw == 180.0F || yaw == -180.0F) return "北(-Z)";
        return yaw > 0 ? "西(-X)" : "东(+X)";
    }

    /** 载具生成失败统一回显 */
    private static void reportVehicle(ServerPlayer reporter, String reason) {
        if (reporter == null) return;
        reporter.sendSystemMessage(CommanderConfig.line(reason));
    }

    /**
     * 在指定位置生成一个自定义实体（雾墙 / 空投的"载具维修箱"等物资类型共用）。
     * 朝向按传入的 yaw 设置，nbt 非空时原样合并进实体（UUID 和 Pos 不覆盖）。返回是否成功。
     */
    private static boolean spawnCustomEntity(ServerLevel level, String entityId, Vec3 spawn, float yaw, String nbt) {
        net.minecraft.world.entity.EntityType<?> type =
                net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getValue(
                        new ResourceLocation(entityId));
        if (type == null) return false;
        Entity spawned = type.create(level);
        if (spawned == null) return false;
        spawned.setPos(spawn.x, spawn.y, spawn.z);
        // 让实体的朝向跟着指挥官的视线方向（普通实体的 yaw：0 = +Z，向右为正）
        spawned.setYRot(yaw);
        spawned.setYHeadRot(yaw);
        if (nbt != null && !nbt.isBlank()) {
            try {
                CompoundTag extra = TagParser.parseTag(nbt);
                CompoundTag tag = new CompoundTag();
                spawned.save(tag);
                // 不覆盖 UUID 和坐标这两项，其余键全部原样合并进实体
                for (String key : extra.getAllKeys()) {
                    if (key.equals("UUID") || key.equals("Pos")) continue;
                    tag.put(key, extra.get(key).copy());
                }
                // 载具模组只认 NBT 里的 Rotation / ServerYaw，不看实体的 yRot：
                // 没写 Rotation 就按释放者视线折出的四方向补上（写了的就尊重玩家自己的配置）
                if (!extra.contains("Rotation")) {
                    ListTag rot = new ListTag();
                    rot.add(FloatTag.valueOf(yaw));
                    rot.add(FloatTag.valueOf(0.0F));
                    tag.put("Rotation", rot);
                    // [SBW]卓越前线 这类载具还用自己的 ServerYaw 记车身朝向：
                    // 玩家的 NBT 里有这一项就顺手同步成同一个方向，免得车身被锁死朝南
                    if (extra.contains("ServerYaw")) tag.putFloat("ServerYaw", yaw);
                }
                spawned.load(tag);
            } catch (Exception ignored) {
                // NBT 写错时按无 NBT 生成，保证雾墙本身还能展开
            }
        }
        // 再写一遍位置和朝向：部分载具模组 load 完 NBT 后会把坐标/朝向改回默认值
        spawned.setPos(spawn.x, spawn.y, spawn.z);
        spawned.setYRot(yaw);
        spawned.setYHeadRot(yaw);
        level.addFreshEntity(spawned);
        return true;
    }

    /** 雾墙的一面：实体 id、位置、朝向与自定义 NBT 都按烟雾配置来 */
    private static boolean spawnSmokeEntity(ServerLevel level, String entityId, Vec3 spawn, float yaw,
                                            CommanderConfig.SmokeCfg cfg) {
        return spawnCustomEntity(level, entityId, spawn, yaw, cfg.customEntityNbt);
    }

    // ==================== 技能4：炮击支援（直接天降炮击） ====================

    private static void artilleryStrike(ServerPlayer commander) {
        artilleryStrikeAt(commander, aimPoint(commander.pick(128.0, 1.0F, false)));
    }

    /**
     * 炮击落点结算：准星指到方块时统一用该方块的顶面中心——
     * 与客户端瞄准模式的预览圆圈是同一个点，预览在哪炮击就落在哪。
     */
    private static Vec3 aimPoint(HitResult hit) {
        if (hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK) {
            BlockPos bp = blockHit.getBlockPos();
            return new Vec3(bp.getX() + 0.5, bp.getY() + 1.0, bp.getZ() + 0.5);
        }
        return hit.getLocation();
    }

    /** 在指定位置召唤一轮炮击：N 发，逐发落下（绝不两发同时），间隔、落点方式（同一位置/随机散布）、半径、伤害、点火均可配置 */
    private static void artilleryStrikeAt(ServerPlayer caller, Vec3 target) {
        ServerLevel level = caller.serverLevel();
        CommanderConfig.ArtilleryCfg cfg = CommanderConfig.INSTANCE.artillery;
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;

        boolean destroyBlocks = cfg.destroyBlocks;
        String landing = cfg.landing == null ? "scatter" : cfg.landing.trim().toLowerCase(java.util.Locale.ROOT);
        boolean sameSpot = landing.equals("same");
        boolean mortar = isMortarApproach(cfg.approach);
        float mortarYaw = mortar ? mortarBearing(caller, cfg.mortarBearing) : 0.0F;
        double mortarAngle = cfg.mortarAngle;
        String landingText = sameSpot ? msgs.artilleryLandingSame : msgs.artilleryLandingScatter;
        String approachText = mortar ? msgs.artilleryApproachMortar : msgs.artilleryApproachVertical;
        // 每发之间的最小间隔强制 1 tick：保证绝不两发同时落地
        int interval = Math.max(1, cfg.intervalTicks);
        int trail = Math.max(0, cfg.trailTicks);
        String damageText = cfg.damage >= 0 ? String.valueOf(cfg.damage) : msgs.artilleryDamageVanilla;
        caller.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(msgs.artilleryCalled,
                "count", String.valueOf(cfg.strikes),
                "landing", landingText,
                "approach", approachText,
                "interval", String.format("%.2f", interval / 20.0),
                "damage", damageText,
                "extra", destroyBlocks ? "" : msgs.artilleryNoBlockDamage)));

        ParticleOptions trailSmoke = SmokeWallEntity.parseParticle(cfg.trailParticle);
        // 这些解析结果一次算好、整轮复用，不用每发炮弹都去查注册表
        ParticleOptions smoke = SmokeWallEntity.parseParticle(cfg.smokeParticle);
        ParticleOptions boom = SmokeWallEntity.parseParticle(cfg.particle);
        SoundEvent boomSound = SmokeWallEntity.parseSound(cfg.sound);
        // 战果统计：自定义伤害模式下数命中数与伤害合计，全部打完后给指挥官一条结束提示
        boolean customDamage = cfg.damage >= 0;
        final HitStats stats = customDamage ? new HitStats() : null;
        if (customDamage && cfg.strikes > 0) {
            int endDelay = (cfg.strikes - 1) * Math.max(1, cfg.intervalTicks) + Math.max(0, cfg.trailTicks) + 1;
            TickHandler.schedule(caller.server, endDelay, () -> {
                        if (stats.hits > 0 || stats.total > 0) {
                            caller.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(
                                    msgs.artilleryEnd,
                                    "count", String.valueOf(stats.hits),
                                    "total", String.format("%.0f", stats.total))));
                        }
                    });
        }
        for (int i = 0; i < cfg.strikes; i++) {
            // 这一发的落点在呼叫时就定死：后面的弹道特效与爆炸必然命中同一点
            double dx = sameSpot ? 0 : (level.random.nextDouble() * 2 - 1) * cfg.scatter;
            double dz = sameSpot ? 0 : (level.random.nextDouble() * 2 - 1) * cfg.scatter;
            double aimX = target.x + dx;
            double aimZ = target.z + dz;
            double aimY = target.y;
            Vec3 start;
            Vec3 land;
            if (mortar) {
                // 迫击炮：从斜上方飞来。先按"瞄准落点"算出弹道起点，再沿这条斜线打射线
                // 找真实撞击点——屋顶、墙都会挡住，炮弹不会穿过去。
                Vec3 intended = new Vec3(aimX, aimY, aimZ);
                start = mortarStart(intended, TRAIL_TOP, mortarAngle, mortarYaw);
                land = cfg.blockWalls ? mortarImpact(level, start, intended) : intended;
            } else {
                // 垂直落下：落点吸附到这一列从上往下第一个方块的上表面
                if (cfg.blockWalls) aimY = landingSurfaceY(level, aimX, aimZ, aimY);
                land = new Vec3(aimX, aimY, aimZ);
                start = new Vec3(aimX, aimY + TRAIL_TOP, aimZ);
            }
            final double x = land.x;
            final double y = land.y;
            final double z = land.z;
            final double sx = start.x;
            final double sy = start.y;
            final double sz = start.z;
            final int delay = i * interval;
            // 下坠弹道：爆炸前 trailTicks tick，粒子从起点沿直线一路飞到落点
            for (int t = 0; trail > 0 && t < trail; t++) {
                final int tt = t;
                TickHandler.schedule(caller.server, delay + tt, () -> {
                    if (!level.isLoaded(BlockPos.containing(x, y, z))) return;
                    double frac = trail <= 1 ? 0 : 1.0 - tt / (double) (trail - 1);
                    level.sendParticles(trailSmoke,
                            x + (sx - x) * frac,
                            y + (sy - y) * frac,
                            z + (sz - z) * frac,
                            3, 0.08, 0.08, 0.08, 0.0);
                });
            }
            // 爆炸：与弹道同一落点；每发单独调度，间隔再短也不会同时炸
            TickHandler.schedule(caller.server, delay + trail, () -> {
                if (!level.isLoaded(BlockPos.containing(x, y, z))) return;
                // 每发炮弹：先冒烟提示，再爆炸
                level.sendParticles(smoke, x, y + 1.0, z, 15, 0.5, 0.5, 0.5, 0.01);
                // destroyBlocks=false：爆炸不碰任何方块；此时也强制不点火（火方块会慢慢烧毁木板等）
                boolean fire = destroyBlocks && cfg.fire;
                if (cfg.damage >= 0) {
                    // 自定义伤害模式：屏蔽原版爆炸的实体伤害（只留特效与拆方块），伤害按配置自己算
                    suppressVanillaExplosionDamage = true;
                    try {
                        level.explode(null, x, y, z, cfg.radius, fire,
                                destroyBlocks ? Level.ExplosionInteraction.BLOCK : Level.ExplosionInteraction.NONE);
                    } finally {
                        suppressVanillaExplosionDamage = false;
                    }
                    applyCustomDamage(level, caller, x, y, z, cfg, stats);
                } else {
                    // 原版伤害模式（damage = -1）：完全按原版爆炸结算
                    level.explode(null, x, y, z, cfg.radius, fire,
                            destroyBlocks ? Level.ExplosionInteraction.BLOCK : Level.ExplosionInteraction.NONE);
                }
                level.sendParticles(boom, x, y + 0.5, z, 1, 0, 0, 0, 0);
                if (boomSound != null) {
                    level.playSound(null, x, y, z, boomSound, SoundSource.PLAYERS, 2.0F,
                            0.9F + level.random.nextFloat() * 0.2F);
                }
                // 摄像机摇晃：按距离衰减发给附近玩家（shakeIntensity=0 时整段跳过）
                sendCameraShake(level, x, y, z, cfg);
            });
        }
    }

    /**
     * 把这一发炮弹的摄像机摇晃发给附近玩家：强度按"距离衰减 + 隔墙再打折"计算，
     * 爆心处全额，到 artillery.shakeRange 格处衰减到 0；shakeIntensity=0 时整段跳过。
     * 只发渲染用的数据包（客户端改相机角度），不碰任何游戏数值。
     */
    private static void sendCameraShake(ServerLevel level, double x, double y, double z,
                                        CommanderConfig.ArtilleryCfg cfg) {
        double intensity = cfg.shakeIntensity;
        if (intensity <= 0.0) return;
        double range = Math.max(1.0, cfg.shakeRange);
        double rangeSqr = range * range;
        int ticks = Math.max(1, cfg.shakeTicks);
        Vec3 epicenter = new Vec3(x, y + 0.5, z);
        double muffle = Math.max(0.0, Math.min(1.0, cfg.shakeWallMuffle));
        for (ServerPlayer p : level.players()) {
            if (p.isSpectator()) continue; // 观战视角不晃
            double distSqr = p.distanceToSqr(epicenter);
            if (distSqr > rangeSqr) continue;
            double dist = Math.sqrt(distSqr);
            // 距离衰减用平方曲线：近处很晃、稍远就明显轻下来，比线性更像真实爆炸
            double att = 1.0 - dist / range;
            float amount = (float) (intensity * att * att);
            // 隔着墙/屋顶时按配置打折（shakeWallMuffle=0.4 = 只震四成）
            if (muffle < 1.0 && cfg.blockWalls
                    && blockedLine(level, epicenter, p.getEyePosition())) {
                amount *= (float) muffle;
            }
            if (amount < 0.05F) continue;
            ModNetwork.CHANNEL.send(
                    net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> p),
                    new S2CCameraShake(amount, ticks));
        }
    }

    /** 自定义伤害开启时，让原版爆炸跳过对实体的伤害与击退（由 applyCustomDamage 按配置接管） */
    static volatile boolean suppressVanillaExplosionDamage = false;

    /** 一轮炮击的战果统计：命中几个目标、造成多少伤害（自定义伤害模式下累计） */
    static final class HitStats {
        int hits;
        double total;
    }

    /**
     * 自定义伤害：对作用半径内的每个生物造成配置的伤害（爆心全额，随距离线性衰减到边缘 30%），
     * 并按配置力度击退。击退方向从爆心指向目标，带一点向上的分量，打起来更有"炮击"的感觉。
     *
     * <p>另外对作用半径内的"非生物实体"也打一轮：像 [SBW]卓越前线 这类模组的载具
     * 继承自 Entity 而不是 LivingEntity，血量记在实体自己的字段里，只有实体自己的
     * hurt() 才会扣血，所以光打生物是碰不到载具的。非生物实体只扣血不击退，
     * 载具大多有自家物理，被爆炸推走不符合直觉。船、矿车、挂画、盔甲架这类原版实体
     * 与原版爆炸的表现一致（原版爆炸本来也会砸坏它们）。
     */
    private static void applyCustomDamage(ServerLevel level, ServerPlayer caller,
                                          double x, double y, double z, CommanderConfig.ArtilleryCfg cfg,
                                          HitStats stats) {
        double r = cfg.damageRadius > 0 ? cfg.damageRadius : cfg.radius;
        if (cfg.damage <= 0 || r <= 0) return;
        // 用模组自建的伤害类型：死亡信息绑在它身上，且带原版 is_explosion 标签
        DamageSource source = CommanderDamageSources.artillery(level, caller);
        AABB box = new AABB(x - r, y - r, z - r, x + r, y + r, z + r);
        // 不穿墙（artillery.blockWalls，默认开）：爆心与目标之间隔着方块就不打
        boolean blockWalls = cfg.blockWalls;
        Vec3 epicenter = new Vec3(x, y + 0.1, z); // 抬 0.1 避免射线起点贴着方块顶面被判成挡住
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (e.ignoreExplosion()) continue;
            double dist = Math.sqrt(e.distanceToSqr(x, y, z));
            if (dist > r) continue;
            if (blockWalls && blockedLine(level, epicenter, e.getEyePosition())) continue;
            float frac = (float) (1.0 - 0.7 * dist / r); // 爆心 100% → 边缘 30%
            float dealt = cfg.damage * frac;
            if (e.hurt(source, dealt) && stats != null) {
                stats.hits++;
                stats.total += dealt;
            }
            if (cfg.knockback > 0) {
                Vec3 push = new Vec3(e.getX() - x, (e.getY() + e.getEyeHeight() * 0.5) - y, e.getZ() - z);
                double len = push.length();
                if (len > 1.0E-4) {
                    push = push.normalize().scale(cfg.knockback * frac);
                    e.setDeltaMovement(e.getDeltaMovement().add(push));
                    e.hurtMarked = true; // 立刻把速度同步给客户端，击退才看得见
                }
            }
        }
        // 载具等非生物实体（hitVehicles=false 时跳过这一轮）
        if (!cfg.hitVehicles) return;
        // 载具这一轮用原版爆炸伤害类型（minecraft:explosion）而不是自建的 commander_artillery：
        // 死亡信息定制只对生物有意义，而不少载具模组（如 [SBW]卓越前线）的受伤判定
        // 只认原版爆炸类型，自建类型会被它们整口吞掉——上一版"打不了载具"就是这个原因。
        DamageSource vehicleSource = level.damageSources().explosion(caller, caller);
        for (Entity e : level.getEntitiesOfClass(Entity.class, box)) {
            if (e instanceof LivingEntity) continue; // 生物已在上面处理
            // 掉落物、经验球、飞行中的投射物、闪电不打：原版爆炸也不把它们当目标
            if (e instanceof Player || e instanceof ItemEntity || e instanceof ExperienceOrb
                    || e instanceof Projectile || e instanceof LightningBolt) continue;
            if (e.ignoreExplosion()) continue;
            // 按碰撞箱（而不是实体原点）判定：坦克这类大载具的原点在贴地处、甚至嵌在
            // 地面方块里，用原点会漏掉"车头在爆心附近、车尾还没进圈"这类目标
            AABB eb = e.getBoundingBox();
            double dist = Math.sqrt(eb.distanceToSqr(new Vec3(x, y, z)));
            if (dist > r) continue;
            // 不穿墙判定打向碰撞箱中心（原点对地擦过去会把地面误判成墙）
            if (blockWalls && blockedLine(level, epicenter, eb.getCenter())) continue;
            float frac = (float) (1.0 - 0.7 * dist / r);
            // 模组载具（id 命名空间不是 minecraft，如 [SBW]卓越前线的坦克）吃配置的倍率加成；
            // 原版的船/矿车/挂画等只吃基础伤害，加成只针对模组载具
            float bonus = isModVehicle(e) ? (float) Math.max(0.0, cfg.vehicleBonusMultiplier) : 1.0F;
            float dealt = cfg.damage * frac * bonus;
            if (e.hurt(vehicleSource, dealt) && stats != null) {
                stats.hits++;
                stats.total += dealt;
            }
        }
    }

    /** 是否为"模组载具"：非生物实体且实体 id 不是 minecraft: 开头（卓越前线的载具就在其中） */
    private static boolean isModVehicle(Entity e) {
        return !EntityType.getKey(e.getType()).getNamespace().equals("minecraft");
    }

    /** 工具包方案：发放配置好的坐标仪与额外物品（保留自定义 NBT） */
    private static void grantToolkit(ServerPlayer commander) {
        CommanderConfig.ArtilleryCfg cfg = CommanderConfig.INSTANCE.artillery;
        ItemStack designator = new ItemStack(GeneratedMod.ARTILLERY_DESIGNATOR.get(),
                Math.max(1, cfg.toolkitCount));
        CommanderConfig.applyNbt(designator, cfg.toolkitNbt);
        if (!commander.getInventory().add(designator)) {
            commander.drop(designator, false);
        }
        for (CommanderConfig.LootEntry entry : cfg.toolkitExtraItems) {
            ItemStack extra = CommanderConfig.buildStack(entry);
            if (extra.isEmpty()) continue;
            if (!commander.getInventory().add(extra)) {
                commander.drop(extra, false);
            }
        }
        commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.INSTANCE.messages.toolkitGiven));
    }

    // ==================== 技能5：全军突击 ====================

    private static void assault(ServerPlayer commander) {
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        applyTeamBuff(commander, CommanderConfig.INSTANCE.assault, msgs.assaultName, msgs.assaultEffects);
    }

    private static void retreat(ServerPlayer commander) {
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        applyTeamBuff(commander, CommanderConfig.INSTANCE.retreat, msgs.retreatName, msgs.retreatEffects);
    }

    private static void applyTeamBuff(ServerPlayer commander, CommanderConfig.BuffCfg cfg, String name, String desc) {
        ServerLevel level = commander.serverLevel();
        List<ServerPlayer> targets = teamTargets(commander);
        int seconds = cfg.seconds;
        int applied = 0;
        for (ServerPlayer target : targets) {
            for (CommanderConfig.EffectEntry entry : cfg.effects) {
                MobEffect effect = effectOf(entry.id);
                if (effect == null) continue;
                int dur = (entry.seconds > 0 ? entry.seconds : seconds) * 20;
                target.addEffect(new MobEffectInstance(effect, dur, Math.max(0, entry.amplifier), false, true));
            }
            ParticleOptions particle = SmokeWallEntity.parseParticle(cfg.particle);
            level.sendParticles(particle, target.getX(), target.getY() + 1.0, target.getZ(),
                    6, 0.4, 0.6, 0.4, 0.01);
            applied++;
        }
        SoundEvent sound = SmokeWallEntity.parseSound(cfg.sound);
        if (sound != null) {
            level.playSound(null, commander.blockPosition(), sound, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
        String range = targets.size() == 1 && commander.getTeam() == null
                ? CommanderConfig.INSTANCE.messages.buffNoTeam
                : CommanderConfig.fmt(CommanderConfig.INSTANCE.messages.buffTeamRange,
                        "count", String.valueOf(applied));
        commander.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(
                CommanderConfig.INSTANCE.messages.buffApplied,
                "name", name,
                "effects", desc,
                "seconds", String.valueOf(seconds),
                "range", range)));
    }

    // ==================== 工具方法 ====================

    /**
     * 玩家当前的"等级"：等级来源由配置 levels.source 决定。
     * 默认 scoreboard = 读记分榜目标 levels.scoreboardObjective（默认 commander_level）的分数；
     * 目标不存在且 levels.autoCreateObjective=true 时会自动按 dummy 类型创建（分数从 0 起）。
     * 配成 xp 则回退为原版经验等级（旧行为）。
     */
    public static int currentLevel(ServerPlayer player) {
        CommanderConfig.LevelsCfg lv = CommanderConfig.INSTANCE.levels;
        String objName = lv.scoreboardObjective == null ? "" : lv.scoreboardObjective.trim();
        if (!lv.useScoreboard() || objName.isEmpty()) return player.experienceLevel;
        Scoreboard scoreboard = player.server.getScoreboard();
        Objective objective = scoreboard.getObjective(objName);
        if (objective == null) {
            if (!lv.autoCreateObjective) return 0;
            try {
                objective = scoreboard.addObjective(objName, ObjectiveCriteria.DUMMY,
                        Component.literal(objName), ObjectiveCriteria.RenderType.INTEGER);
            } catch (Exception e) {
                return 0; // 目标名不合法等异常时按 0 分处理，不让技能直接报错
            }
        }
        return scoreboard.getOrCreatePlayerScore(player.getScoreboardName(), objective).getScore();
    }

    /**
     * 玩家当前的"技能点"余额：读记分榜目标 skillPoints.scoreboardObjective（默认 commander_points）的分数。
     * 目标不存在且 autoCreateObjective=true 时自动按 dummy 类型创建；技能点功能关闭时返回 0（不会被检查到）。
     */
    public static int currentPoints(ServerPlayer player) {
        CommanderConfig.SkillPointsCfg sp = CommanderConfig.INSTANCE.skillPoints;
        if (sp == null || !sp.enabledSafe()) return 0;
        String objName = sp.scoreboardObjective == null ? "" : sp.scoreboardObjective.trim();
        if (objName.isEmpty()) return 0;
        Scoreboard scoreboard = player.server.getScoreboard();
        Objective objective = scoreboard.getObjective(objName);
        if (objective == null) {
            if (!sp.autoCreateObjective) return 0;
            try {
                objective = scoreboard.addObjective(objName, ObjectiveCriteria.DUMMY,
                        Component.literal(objName), ObjectiveCriteria.RenderType.INTEGER);
            } catch (Exception e) {
                return 0; // 目标名不合法等异常时按 0 点处理，不让技能直接报错
            }
        }
        return scoreboard.getOrCreatePlayerScore(player.getScoreboardName(), objective).getScore();
    }

    /**
     * 扣除技能点，返回扣完之后的余额。目标不存在（且不允许自动创建）时什么都不扣，返回 0。
     * 余额不足时也只扣到 0 为止——能走到这里说明检查时点数是够的，中间被改低就按剩余的扣。
     */
    public static int spendPoints(ServerPlayer player, int cost) {
        CommanderConfig.SkillPointsCfg sp = CommanderConfig.INSTANCE.skillPoints;
        if (sp == null || !sp.enabledSafe() || cost <= 0) return currentPoints(player);
        String objName = sp.scoreboardObjective == null ? "" : sp.scoreboardObjective.trim();
        if (objName.isEmpty()) return 0;
        Scoreboard scoreboard = player.server.getScoreboard();
        Objective objective = scoreboard.getObjective(objName);
        if (objective == null) {
            if (!sp.autoCreateObjective) return 0;
            try {
                objective = scoreboard.addObjective(objName, ObjectiveCriteria.DUMMY,
                        Component.literal(objName), ObjectiveCriteria.RenderType.INTEGER);
            } catch (Exception e) {
                return 0;
            }
        }
        int current = scoreboard.getOrCreatePlayerScore(player.getScoreboardName(), objective).getScore();
        int left = Math.max(0, current - cost);
        scoreboard.getOrCreatePlayerScore(player.getScoreboardName(), objective).setScore(left);
        return left;
    }

    public static boolean isAlly(ServerPlayer a, ServerPlayer b) {
        Team teamA = a.getTeam();
        Team teamB = b.getTeam();
        return teamA != null && teamB != null && teamA.isAlliedTo(teamB);
    }

    public static void sendToTeam(ServerPlayer commander, Component msg) {
        commander.sendSystemMessage(msg);
        for (ServerPlayer p : commander.server.getPlayerList().getPlayers()) {
            if (p != commander && isAlly(commander, p)) {
                p.sendSystemMessage(msg);
            }
        }
    }

    private static List<ServerPlayer> teamTargets(ServerPlayer commander) {
        List<ServerPlayer> out = new ArrayList<>();
        Team team = commander.getTeam();
        if (team == null) {
            out.add(commander);
            return out;
        }
        for (ServerPlayer p : commander.server.getPlayerList().getPlayers()) {
            if (p.getTeam() == null) continue;
            if (team.isAlliedTo(p.getTeam())) out.add(p);
        }
        return out;
    }

    public static MobEffect effectOf(String id) {
        try {
            return net.minecraftforge.registries.ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(id));
        } catch (Exception e) {
            return null;
        }
    }
}