package cn.blockforge.generated.nbt6commandervotesta.item;

import cn.blockforge.generated.nbt6commandervotesta.core.SkillManager;
import cn.blockforge.generated.nbt6commandervotesta.core.VoteManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * 炮击坐标仪：炮击工具包方案的核心物品。
 * 手持右键即可在准星位置呼叫一轮炮击（配置里可替换成其他模组的物品/NBT 方案）。
 */
public class ArtilleryDesignatorItem extends Item {

    public ArtilleryDesignatorItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        String error = SkillManager.useDesignator(sp, stack);
        if (error != null) {
            sp.sendSystemMessage(cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.line("§c" + error));
            return InteractionResultHolder.fail(stack);
        }
        return InteractionResultHolder.success(stack);
    }
}