package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

/** /commander 指令树：身份与投票管理 + 等级限制开关 + 六个技能。 */
public final class CommanderCommands {

    private CommanderCommands() {
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return literal("commander")
                // ===== 管理员：总开关 =====
                .then(literal("enable")
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> setEnabled(ctx.getSource(), true)))
                .then(literal("disable")
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> setEnabled(ctx.getSource(), false)))
                // ===== 管理员：热加载配置 =====
                .then(literal("reload")
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> reloadConfig(ctx.getSource())))
                // ===== 管理员：NBT 写法自检（不碰配置文件，先检验一段文本） =====
                .then(literal("checknbt")
                        .requires(s -> s.hasPermission(2))
                        .then(argument("text", StringArgumentType.greedyString())
                                .executes(CommanderCommands::checkNbt)))
                // ===== 管理员：等级限制开关 =====
                .then(literal("levellimit")
                        .requires(s -> s.hasPermission(2))
                        .then(literal("on").executes(ctx -> setLevelLimit(ctx.getSource(), true)))
                        .then(literal("off").executes(ctx -> setLevelLimit(ctx.getSource(), false))))
                // ===== 管理员：直接授予 / 取消 =====
                .then(literal("grant")
                        .requires(s -> s.hasPermission(2))
                        .then(argument("players", EntityArgument.players())
                                .executes(ctx -> grant(ctx.getSource(),
                                        EntityArgument.getPlayers(ctx, "players")))))
                .then(literal("cancel")
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> cancelAll(ctx.getSource())))
                // ===== 投票（无需权限即可发起；仅发起者同队队友能看见并投票；每队同时只能有 1 名指挥官） =====
                .then(literal("vote")
                        .then(literal("start").executes(CommanderCommands::voteStart))
                        .then(literal("yes").executes(ctx -> voteCast(ctx, true)))
                        .then(literal("no").executes(ctx -> voteCast(ctx, false))))
                // ===== 管理员：炮击快速切换（不用手改 JSON） =====
                .then(literal("artillery")
                        .requires(s -> s.hasPermission(2))
                        .then(literal("approach")
                                .then(literal("vertical").executes(ctx -> setApproach(ctx, "vertical")))
                                .then(literal("mortar").executes(ctx -> setApproach(ctx, "mortar"))))
                        .then(literal("angle")
                                .then(argument("degrees", IntegerArgumentType.integer(15, 80))
                                        .executes(CommanderCommands::setAngle)))
                        .then(literal("bearing")
                                .then(literal("look").executes(ctx -> setBearing(ctx, "look")))
                                .then(literal("south").executes(ctx -> setBearing(ctx, "south")))
                                .then(literal("west").executes(ctx -> setBearing(ctx, "west")))
                                .then(literal("north").executes(ctx -> setBearing(ctx, "north")))
                                .then(literal("east").executes(ctx -> setBearing(ctx, "east"))))
                        .then(literal("shake")
                                .then(literal("off").executes(ctx -> setShake(ctx, 0.0)))
                                .then(argument("intensity", DoubleArgumentType.doubleArg(0.0, 3.0))
                                        .executes(CommanderCommands::setShake))))
                // ===== 技能 =====
                .then(literal("skill")
                        .then(literal("scan").executes(ctx -> useSkill(ctx, "scan")))
                        .then(literal("airdrop").executes(ctx -> useSkill(ctx, "airdrop")))
                        .then(literal("smoke").executes(ctx -> useSkill(ctx, "smoke")))
                        .then(literal("artillery").executes(ctx -> useSkill(ctx, "artillery")))
                        .then(literal("assault").executes(ctx -> useSkill(ctx, "assault")))
                        .then(literal("retreat").executes(ctx -> useSkill(ctx, "retreat"))))
                // ===== 帮助 =====
                .then(literal("help").executes(CommanderCommands::help));
    }

    // ==================== 管理员操作 ====================

    /** 热加载配置：改完 config/commander_system.json 后无需重启服务器，立即生效 */
    private static int reloadConfig(CommandSourceStack source) {
        String err = CommanderConfig.reload();
        if (err != null) {
            source.sendFailure(CommanderConfig.line(CommanderConfig.fmt(
                    CommanderConfig.INSTANCE.messages.reloadFailed, "error", err)));
            // 整份 JSON 都没解析过去，十有八九是某段 NBT 的双引号没加反斜杠转义
            if (err.contains("nbt")) {
                source.sendFailure(CommanderConfig.line(
                        "§7提示：JSON 里 NBT 字符串中的双引号必须写成 \\\"（反斜杠+引号），"
                        + "可先在游戏里用 /commander checknbt <文本> 检验，再写进配置"));
            }
            return 0;
        }
        source.sendSuccess(() -> CommanderConfig.line(CommanderConfig.INSTANCE.messages.reloadDone), true);
        // 配置整体能读，但里面某段 NBT 可能写错：提前体检，别等技能释放才发现
        String nbtProblems = CommanderConfig.nbtFieldProblems();
        if (nbtProblems != null) {
            source.sendFailure(CommanderConfig.line("§c检测到 NBT 写法问题：" + nbtProblems
                    + "\n§7（对应技能用到这段配置时会召唤失败；改完再 /commander reload）"));
        }
        return Command.SINGLE_SUCCESS;
    }

    /**
     * NBT 语法自检：把一段 SNBT 原文（游戏里打，双引号直接打，不用反斜杠）交给解析器，
     * 正确就回显解析结果，错误就回显具体原因——避免在 JSON 配置文件里反复猜。
     */
    private static int checkNbt(CommandContext<CommandSourceStack> ctx) {
        String text = StringArgumentType.getString(ctx, "text").trim();
        CommandSourceStack source = ctx.getSource();
        try {
            net.minecraft.nbt.Tag parsed = net.minecraft.nbt.TagParser.parseTag(text);
            source.sendSuccess(() -> CommanderConfig.line(
                    "§aNBT 语法正确 ✓ §7解析为：§f" + parsed), true);
            source.sendSuccess(() -> CommanderConfig.line(
                    "§7写进 JSON 配置时，把里面每个双引号都改成 \\\" 再加到 nbt 字段的引号中间即可；改完 /commander reload"), true);
        } catch (Exception e) {
            source.sendFailure(CommanderConfig.line("§cNBT 语法错误：§f" + e.getMessage()
                    + CommanderConfig.nestedArrayHint(text)));
        }
        return Command.SINGLE_SUCCESS;
    }

    private static int setEnabled(CommandSourceStack source, boolean enabled) {
        CommanderSavedData data = CommanderSavedData.get(source.getServer());
        data.setEnabled(enabled);
        source.sendSuccess(() -> CommanderConfig.line(enabled
                ? CommanderConfig.INSTANCE.messages.systemEnabled
                : CommanderConfig.INSTANCE.messages.systemOff), true);
        if (!enabled) VoteManager.cancel(source.getServer());
        return Command.SINGLE_SUCCESS;
    }

    private static int setLevelLimit(CommandSourceStack source, boolean enabled) {
        CommanderSavedData data = CommanderSavedData.get(source.getServer());
        data.setLevelLimitEnabled(enabled);
        source.sendSuccess(() -> CommanderConfig.line(enabled
                ? CommanderConfig.INSTANCE.messages.levelLimitOn
                : CommanderConfig.INSTANCE.messages.levelLimitOff), true);
        return Command.SINGLE_SUCCESS;
    }

    // ==================== 炮击快速切换（管理员，不用手改 JSON） ====================

    /**
     * 改完立刻写回 config/commander_system.json（save 会顺带补全注释与缺字段），
     * 所以这条命令的效果和手改配置完全一样，下次 /commander reload 也不会丢。
     */
    private static void applyAndTell(CommandSourceStack source, String detail) {
        CommanderConfig.save();
        source.sendSuccess(() -> CommanderConfig.line("§a已改好并写回配置文件：" + detail), true);
    }

    /** /commander artillery approach vertical|mortar：炮弹垂直落下 / 像迫击炮那样斜着打过来 */
    private static int setApproach(CommandContext<CommandSourceStack> ctx, String approach) {
        CommanderConfig.INSTANCE.artillery.approach = approach;
        applyAndTell(ctx.getSource(), "§e炮击来袭方向 = "
                + ("mortar".equals(approach) ? "迫击炮斜向来袭§a（预览上会多一条斜着进来的弹道带）"
                                             : "垂直落下§a（原来的样子）"));
        return Command.SINGLE_SUCCESS;
    }

    /** /commander artillery angle <15-80>：迫击炮入射仰角，越大越陡 */
    private static int setAngle(CommandContext<CommandSourceStack> ctx) {
        int deg = IntegerArgumentType.getInteger(ctx, "degrees");
        CommanderConfig.INSTANCE.artillery.mortarAngle = deg;
        applyAndTell(ctx.getSource(), "§e迫击炮入射仰角 = " + deg + " 度§a（越大越接近垂直，越小越平）");
        return Command.SINGLE_SUCCESS;
    }

    /** /commander artillery bearing look|south|west|north|east：炮弹从哪边打来 */
    private static int setBearing(CommandContext<CommandSourceStack> ctx, String bearing) {
        CommanderConfig.INSTANCE.artillery.mortarBearing = bearing;
        String cn = switch (bearing) {
            case "south" -> "从南方打来";
            case "west" -> "从西方打来";
            case "north" -> "从北方打来";
            case "east" -> "从东方打来";
            default -> "跟着释放者视线（从你身后打来）";
        };
        applyAndTell(ctx.getSource(), "§e迫击炮来袭方位 = " + cn);
        return Command.SINGLE_SUCCESS;
    }

    /** /commander artillery shake <0-3> | off：爆炸时的摄像机摇晃强度（0=关） */
    private static int setShake(CommandContext<CommandSourceStack> ctx, double intensity) {
        CommanderConfig.INSTANCE.artillery.shakeIntensity = intensity;
        applyAndTell(ctx.getSource(), "§e摄像机摇晃强度 = "
                + (intensity <= 0 ? "0（不晃了）" : String.format(java.util.Locale.ROOT, "%.2f", intensity)
                        + "§a（1.0 = 爆心附近明显一晃）"));
        return Command.SINGLE_SUCCESS;
    }

    private static int setShake(CommandContext<CommandSourceStack> ctx) {
        return setShake(ctx, DoubleArgumentType.getDouble(ctx, "intensity"));
    }

    private static int grant(CommandSourceStack source, Collection<ServerPlayer> players) {
        CommanderSavedData data = CommanderSavedData.get(source.getServer());
        int granted = 0, skipped = 0;
        for (ServerPlayer p : players) {
            String teamId = p.getTeam() == null ? null : p.getTeam().getName();
            if (teamId != null && !data.isCommander(p.getUUID())
                    && data.hasCommanderInTeam(source.getServer(), teamId, p.getUUID())) {
                // 该队已有指挥官：跳过并说明，保持“每个队伍同时只能有一名”
                p.sendSystemMessage(CommanderConfig.line(CommanderConfig.fmt(
                        CommanderConfig.INSTANCE.messages.grantedTeamBusy,
                        "player", p.getGameProfile().getName(),
                        "team", VoteManager.teamTag(p.getTeam()))));
                skipped++;
                continue;
            }
            data.addCommander(p.getUUID(), p.getGameProfile().getName());
            p.sendSystemMessage(CommanderConfig.line(CommanderConfig.INSTANCE.messages.grantedYou));
            granted++;
        }
        final int g = granted, s = skipped;
        source.sendSuccess(() -> CommanderConfig.line(CommanderConfig.fmt(
                CommanderConfig.INSTANCE.messages.grantedCount, "count", String.valueOf(g))
                + (s > 0 ? CommanderConfig.fmt(CommanderConfig.INSTANCE.messages.grantedSkipped,
                        "count", String.valueOf(s)) : "")), true);
        return Command.SINGLE_SUCCESS;
    }

    private static int cancelAll(CommandSourceStack source) {
        CommanderSavedData data = CommanderSavedData.get(source.getServer());
        int count = data.commanders().size();
        for (java.util.UUID id : data.commanders()) {
            ServerPlayer p = source.getServer().getPlayerList().getPlayer(id);
            if (p != null) {
                p.sendSystemMessage(CommanderConfig.line(CommanderConfig.INSTANCE.messages.revokedYou));
            }
        }
        data.clearCommanders();
        VoteManager.cancel(source.getServer());
        source.sendSuccess(() -> CommanderConfig.line(CommanderConfig.fmt(
                CommanderConfig.INSTANCE.messages.revokedAll,
                "count", String.valueOf(count))), true);
        return Command.SINGLE_SUCCESS;
    }

    // ==================== 投票 ====================

    private static int voteStart(CommandContext<CommandSourceStack> ctx)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer starter = ctx.getSource().getPlayerOrException();
        String error = VoteManager.start(starter);
        if (error != null) {
            starter.sendSystemMessage(CommanderConfig.line("§c" + error));
            return 0;
        }
        return Command.SINGLE_SUCCESS;
    }

    private static int voteCast(CommandContext<CommandSourceStack> ctx, boolean yes)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer voter = ctx.getSource().getPlayerOrException();
        String error = VoteManager.cast(voter, yes);
        if (error != null) {
            voter.sendSystemMessage(CommanderConfig.line("§c" + error));
            return 0;
        }
        return Command.SINGLE_SUCCESS;
    }

    // ==================== 技能 ====================

    private static int useSkill(CommandContext<CommandSourceStack> ctx, String skill)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        CommanderSavedData data = CommanderSavedData.get(player.server);
        if (!data.isCommander(player.getUUID())) {
            player.sendSystemMessage(CommanderConfig.line("§c"
                    + CommanderConfig.INSTANCE.messages.notCommander));
            return 0;
        }
        String error = SkillManager.useSkill(player, skill, "");
        if (error != null) {
            player.sendSystemMessage(CommanderConfig.line("§c" + error));
            return 0;
        }
        return Command.SINGLE_SUCCESS;
    }

    // ==================== 帮助 ====================

    private static int help(CommandContext<CommandSourceStack> ctx) {
        ctx.getSource().sendSuccess(() -> Component.literal(CommanderConfig.INSTANCE.messages.help), false);
        return Command.SINGLE_SUCCESS;
    }
}