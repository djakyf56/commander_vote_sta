package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.client.WheelClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * 服务端 -> 客户端：技能轮盘的状态数据。
 * 打开轮盘时客户端先发 open 请求，服务端把每个技能的
 * 模块开关 / 等级要求 / 技能点消耗 / 剩余冷却 发回来，界面上就能实时显示。
 *
 * <p>本次还带了瞄准模式要用的参数（雾墙探测距离/抬高格数/预览半径、炮击的散布半径/发数/
 * 是否迫击炮斜向来袭及其入射角与方位）、
 * 连发惩罚状态（惩罚中的消耗倍率）、炮击是否为工具包模式，
 * 以及空投 2 级菜单的物资类型清单（id/名字/说明/是否生成实体）。
 *
 * <p>炮击预览参数：artilleryScatter=散布半径（画外圈用）、artillerySameSpot=落点方式、
 * artilleryStrikes=发数、artilleryMortar=是否迫击炮弹道、artilleryMortarAngle=入射仰角、
 * artilleryMortarYaw=固定来袭方位（配置写死东南西北时给具体角度；写"跟视线"时传 NaN，
 * 由客户端按自己当前的视线折算，这样预览和真正释放用的是同一个方向）。
 *
 * <p>text 字段是配置 wheel 一节里的自定义文案（中心标题/统计/操作提示/状态行/六个技能的名字短名说明），
 * 空字符串表示"没有自定义"，客户端回退用语言文件里的内置文案。
 */
public record S2CWheelData(boolean systemEnabled, boolean isCommander, boolean levelLimitActive,
                           int playerLevel, boolean pointsActive, int playerPoints,
                           boolean penaltyActive, int penaltyMult, boolean artilleryToolkit,
                           float smokeRange, float smokeUpOffset, float smokePreviewRadius,
                           boolean smokeBlockWalls,
                           float artilleryScatter, boolean artillerySameSpot, int artilleryStrikes,
                           boolean artilleryMortar, float artilleryMortarAngle, float artilleryMortarYaw,
                           List<Entry> entries, List<AirdropType> airdropTypes, WheelText text) {

    /** 单个技能在轮盘上要显示的状态（pointCost 已经是算上连发惩罚的实际消耗） */
    public record Entry(boolean moduleOn, int requiredLevel, int cooldownTicks, int pointCost) {
    }

    /** 空投 2 级菜单里的一个物资类型 */
    public record AirdropType(String id, String name, String desc, boolean hasEntity) {
    }

    /** 轮盘中心提示与各技能文字（全部来自配置 wheel 一节；空串=用内置文案） */
    public record WheelText(String centerTitle, String centerSummary, String centerHint,
                            String centerPoints, String statusReady, String statusCooldown,
                            String statusLevel, String statusPoints, String statusPenalty,
                            String statusModuleOff, String statusNotCommander, String statusSystemOff,
                            List<SkillText> skills) {

        /** 全空文案：客户端收到后一律回退到语言文件的内置文案 */
        public static final WheelText EMPTY = new WheelText(
                "", "", "", "", "", "", "", "", "", "", "", "", List.of());
    }

    /** 单个技能的自定义文字：name=完整名（中心盘），shortName=短名（扇区上），desc=说明 */
    public record SkillText(String name, String shortName, String desc) {
    }

    public S2CWheelData(FriendlyByteBuf buf) {
        this(buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readVarInt(),
                buf.readBoolean(), buf.readVarInt(),
                buf.readBoolean(), buf.readVarInt(), buf.readBoolean(),
                buf.readFloat(), buf.readFloat(), buf.readFloat(),
                buf.readBoolean(),
                buf.readFloat(), buf.readBoolean(), buf.readVarInt(),
                buf.readBoolean(), buf.readFloat(), buf.readFloat(),
                readEntries(buf), readTypes(buf), readText(buf));
    }

    private static List<Entry> readEntries(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<Entry> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            out.add(new Entry(buf.readBoolean(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));
        }
        return out;
    }

    private static List<AirdropType> readTypes(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<AirdropType> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            out.add(new AirdropType(buf.readUtf(64), buf.readUtf(128), buf.readUtf(128), buf.readBoolean()));
        }
        return out;
    }

    private static WheelText readText(FriendlyByteBuf buf) {
        String title = buf.readUtf();
        String summary = buf.readUtf();
        String hint = buf.readUtf();
        String points = buf.readUtf();
        String ready = buf.readUtf();
        String cooldown = buf.readUtf();
        String level = buf.readUtf();
        String pointStatus = buf.readUtf();
        String penalty = buf.readUtf();
        String moduleOff = buf.readUtf();
        String notCommander = buf.readUtf();
        String systemOff = buf.readUtf();
        int n = buf.readVarInt();
        List<SkillText> skills = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            skills.add(new SkillText(buf.readUtf(), buf.readUtf(), buf.readUtf()));
        }
        return new WheelText(title, summary, hint, points, ready, cooldown, level, pointStatus,
                penalty, moduleOff, notCommander, systemOff, skills);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(systemEnabled);
        buf.writeBoolean(isCommander);
        buf.writeBoolean(levelLimitActive);
        buf.writeVarInt(playerLevel);
        buf.writeBoolean(pointsActive);
        buf.writeVarInt(Math.max(0, playerPoints));
        buf.writeBoolean(penaltyActive);
        buf.writeVarInt(Math.max(1, penaltyMult));
        buf.writeBoolean(artilleryToolkit);
        buf.writeFloat(smokeRange);
        buf.writeFloat(smokeUpOffset);
        buf.writeFloat(smokePreviewRadius);
        buf.writeBoolean(smokeBlockWalls);
        buf.writeFloat(artilleryScatter);
        buf.writeBoolean(artillerySameSpot);
        buf.writeVarInt(Math.max(0, artilleryStrikes));
        buf.writeBoolean(artilleryMortar);
        buf.writeFloat(artilleryMortarAngle);
        buf.writeFloat(artilleryMortarYaw);
        buf.writeVarInt(entries.size());
        for (Entry e : entries) {
            buf.writeBoolean(e.moduleOn());
            buf.writeVarInt(e.requiredLevel());
            buf.writeVarInt(e.cooldownTicks());
            buf.writeVarInt(Math.max(0, e.pointCost()));
        }
        List<AirdropType> types = airdropTypes == null ? List.of() : airdropTypes;
        buf.writeVarInt(types.size());
        for (AirdropType t : types) {
            buf.writeUtf(orEmpty(t.id()), 64);
            buf.writeUtf(orEmpty(t.name()), 128);
            buf.writeUtf(orEmpty(t.desc()), 128);
            buf.writeBoolean(t.hasEntity());
        }
        WheelText t = text == null ? WheelText.EMPTY : text;
        buf.writeUtf(orEmpty(t.centerTitle()));
        buf.writeUtf(orEmpty(t.centerSummary()));
        buf.writeUtf(orEmpty(t.centerHint()));
        buf.writeUtf(orEmpty(t.centerPoints()));
        buf.writeUtf(orEmpty(t.statusReady()));
        buf.writeUtf(orEmpty(t.statusCooldown()));
        buf.writeUtf(orEmpty(t.statusLevel()));
        buf.writeUtf(orEmpty(t.statusPoints()));
        buf.writeUtf(orEmpty(t.statusPenalty()));
        buf.writeUtf(orEmpty(t.statusModuleOff()));
        buf.writeUtf(orEmpty(t.statusNotCommander()));
        buf.writeUtf(orEmpty(t.statusSystemOff()));
        List<SkillText> skills = t.skills() == null ? List.of() : t.skills();
        buf.writeVarInt(skills.size());
        for (SkillText s : skills) {
            buf.writeUtf(orEmpty(s.name()));
            buf.writeUtf(orEmpty(s.shortName()));
            buf.writeUtf(orEmpty(s.desc()));
        }
    }

    private static String orEmpty(String s) {
        return s == null ? "" : s;
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        // 只在客户端执行：把状态交给 WheelClient 缓存，轮盘界面每帧从这里读
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> WheelClient.onWheelData(this)));
        ctx.get().setPacketHandled(true);
    }
}
