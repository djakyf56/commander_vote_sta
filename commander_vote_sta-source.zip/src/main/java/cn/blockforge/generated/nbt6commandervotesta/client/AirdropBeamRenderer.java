package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.entity.AirdropBeamEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BeaconRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;

/**
 * 空投光柱的渲染器：直接借用原版信标光柱的绘制方法（BeaconRenderer.renderBeaconBeam），
 * 所以看上去和信标光柱一模一样，从落点一直插到世界顶；颜色来自实体同步数据。
 */
public class AirdropBeamRenderer extends EntityRenderer<AirdropBeamEntity> {

    public AirdropBeamRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(AirdropBeamEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        Level level = entity.level();
        int rgb = entity.beamColor();
        float[] color = {
                ((rgb >>> 16) & 0xFF) / 255.0F,
                ((rgb >>> 8) & 0xFF) / 255.0F,
                (rgb & 0xFF) / 255.0F
        };
        int base = Mth.floor(entity.getY());
        int height = Math.max(1, level.getMaxBuildHeight() - base);
        // 原版信标光柱：外层光柱 0.2 格宽、内层亮芯 0.25 格宽，纹理会缓慢流转
        BeaconRenderer.renderBeaconBeam(poseStack, buffer, BeaconRenderer.BEAM_LOCATION,
                partialTicks, 1.0F, level.getGameTime(), 0, height, color, 0.2F, 0.25F);
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(AirdropBeamEntity entity) {
        return BeaconRenderer.BEAM_LOCATION;
    }
}
