package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 客户端 -> 服务端：技能轮盘的操作。
 * mode=0：请求一份技能状态（打开轮盘时、以及轮盘打开期间每秒刷新一次）。
 * mode=1：请求使用某个技能（等价于 /commander skill <名字>，同样要过指挥官、
 *         冷却、等级、模块开关这些检查，服务端说了算）。
 * data：随技能附带的数据，例如空投 2 级菜单里选中的物资类型 id；其他技能传空串。
 * 瞄准模式（炮击/空投/雾墙）的确认左键也是发这个包——服务端按玩家当时的准星结算。
 */
public record C2SWheelAction(byte mode, String skill, String data) {

    public static final byte MODE_OPEN = 0;
    public static final byte MODE_USE = 1;

    public C2SWheelAction(FriendlyByteBuf buf) {
        this(buf.readByte(), buf.readUtf(64), buf.readUtf(128));
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeByte(mode);
        buf.writeUtf(skill, 64);
        buf.writeUtf(data == null ? "" : data, 128);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null) return;

        if (mode == MODE_OPEN) {
            // 打开轮盘的申请：非指挥官只回一句提示（客户端收到 isCommander=false 后不会弹轮盘），
            // 状态包照常回，让客户端缓存到最新身份，避免"刚被任命还要按第二次才打得开"
            CommanderSavedData openSaved = CommanderSavedData.get(player.server);
            if (!openSaved.isCommander(player.getUUID())) {
                player.sendSystemMessage(CommanderConfig.line("§c" + CommanderConfig.INSTANCE.messages.notCommander));
            }
            ModNetwork.replyWheelData(player, ctx);
            return;
        }

        // 使用技能：权限检查与 /commander skill 完全一致
        String error;
        CommanderSavedData saved = CommanderSavedData.get(player.server);
        if (!saved.isCommander(player.getUUID())) {
            error = CommanderConfig.INSTANCE.messages.notCommander;
        } else {
            error = SkillManager.useSkill(player, skill, data);
        }
        if (error != null) {
            player.sendSystemMessage(cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.line("§c" + error));
        }
        // 无论成败都回一份最新状态，轮盘上的冷却数字立即更新
        ModNetwork.replyWheelData(player, ctx);
    }
}
