package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.Team;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 投票管理：玩家发起 -> 仅同队队友可见并可投票 -> 票数达标自动授予本队指挥官。
 * 全服同时只允许一个投票进行；每个队伍同时只能有一名指挥官。
 */
public final class VoteManager {

    /** 当前进行中的投票（全服同时只会有一个） */
    private static VoteState active;

    public static class VoteState {
        public final UUID nominee;
        public final String nomineeName;
        /** 发起队伍 id（记分板队伍名，如 red / blue） */
        public final String teamId;
        /** 队伍的展示名（设置过 displayName 就用它，否则用队伍 id），带队伍颜色 */
        public final String teamTag;
        public final long endTick;
        public final Map<UUID, Boolean> votes = new HashMap<>();

        public VoteState(UUID nominee, String nomineeName, String teamId, String teamTag, long endTick) {
            this.nominee = nominee;
            this.nomineeName = nomineeName;
            this.teamId = teamId;
            this.teamTag = teamTag;
            this.endTick = endTick;
        }
    }

    private VoteManager() {
    }

    public static boolean hasActiveVote() {
        return active != null;
    }

    /** 发起投票：提名发起人自己成为本队指挥官。返回错误消息，null 表示成功。 */
    public static String start(ServerPlayer starter) {
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        if (active != null) return msgs.voteAlreadyActive;
        Team team = starter.getTeam();
        if (team == null) return msgs.voteNeedTeam;
        CommanderSavedData data = CommanderSavedData.get(starter.server);
        if (data.isCommander(starter.getUUID())) return msgs.voteAlreadyCommander;
        if (data.hasCommanderInTeam(starter.server, team.getName(), starter.getUUID()))
            return msgs.voteTeamHasCommander;
        List<ServerPlayer> teammates = teammates(starter.server, team.getName());
        teammates.removeIf(p -> p.getUUID().equals(starter.getUUID()));
        if (teammates.isEmpty()) return msgs.voteNoPlayers;
        int duration = CommanderConfig.INSTANCE.vote.durationSeconds;
        String tag = teamTag(team);
        active = new VoteState(starter.getUUID(), starter.getGameProfile().getName(),
                team.getName(), tag, starter.server.getTickCount() + duration * 20L);
        String body = CommanderConfig.fmt(msgs.voteStarted,
                "player", starter.getGameProfile().getName(),
                "team", tag,
                "seconds", String.valueOf(duration));
        Component msg = CommanderConfig.line(body);
        // 只有同队玩家能看见发起广播（别队完全不知情）
        starter.sendSystemMessage(msg);
        for (ServerPlayer p : teammates) {
            p.sendSystemMessage(msg);
        }
        return null;
    }

    /** 投票。返回错误消息，null 表示成功。 */
    public static String cast(ServerPlayer voter, boolean yes) {
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        if (active == null) return msgs.voteNoActive;
        // 不是发起队伍的成员：视同“没有进行中的投票”，不泄露别队投票的存在
        String voterTeam = voter.getTeam() == null ? null : voter.getTeam().getName();
        if (!active.teamId.equals(voterTeam)) return msgs.voteNoActive;
        if (voter.getUUID().equals(active.nominee)) return msgs.voteSelf;
        active.votes.put(voter.getUUID(), yes);
        voter.sendSystemMessage(CommanderConfig.line(yes ? msgs.voteCastYes : msgs.voteCastNo));
        maybeResolve(voter.server, true);
        return null;
    }

    public static void cancel(MinecraftServer server) {
        active = null;
        broadcast(server, CommanderConfig.line(CommanderConfig.INSTANCE.messages.voteCancelled));
    }

    private static void maybeResolve(MinecraftServer server, boolean checkAllVoted) {
        if (active == null) return;
        // 有资格投票的人数 = 同队在线玩家 - 被提名人
        List<ServerPlayer> voters = teammates(server, active.teamId);
        voters.removeIf(p -> p.getUUID().equals(active.nominee));
        if (checkAllVoted && active.votes.size() >= voters.size()) {
            resolve(server);
        }
    }

    /** 由 TickHandler 每秒检查：到时自动结算 */
    public static void tick(MinecraftServer server, long tick) {
        if (active != null && tick >= active.endTick) {
            resolve(server);
        }
    }

    private static void resolve(MinecraftServer server) {
        VoteState vote = active;
        active = null;
        if (vote == null) return;
        int yes = 0, no = 0;
        for (boolean v : vote.votes.values()) {
            if (v) yes++;
            else no++;
        }
        CommanderSavedData data = CommanderSavedData.get(server);
        CommanderConfig.MessagesCfg msgs = CommanderConfig.INSTANCE.messages;
        boolean teamBusy = data.hasCommanderInTeam(server, vote.teamId, vote.nominee);
        if (yes > no && data.isEnabled() && !teamBusy) {
            data.addCommander(vote.nominee, vote.nomineeName);
            broadcast(server, CommanderConfig.line(CommanderConfig.fmt(msgs.votePassed,
                    "yes", String.valueOf(yes), "no", String.valueOf(no),
                    "player", vote.nomineeName, "team", vote.teamTag)));
        } else if (yes > no && data.isEnabled()) {
            // 票数过了，但投票期间管理员已经任命了同队别人：不再重复授予
            broadcast(server, CommanderConfig.line(CommanderConfig.fmt(msgs.votePassedTeamBusy,
                    "yes", String.valueOf(yes), "no", String.valueOf(no),
                    "player", vote.nomineeName, "team", vote.teamTag)));
        } else {
            broadcast(server, CommanderConfig.line(CommanderConfig.fmt(msgs.voteFailed,
                    "yes", String.valueOf(yes), "no", String.valueOf(no),
                    "player", vote.nomineeName, "team", vote.teamTag)));
        }
    }

    /** 某记分板队伍当前在线的所有玩家 */
    private static List<ServerPlayer> teammates(MinecraftServer server, String teamId) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Team t = p.getTeam();
            if (t != null && teamId.equals(t.getName())) out.add(p);
        }
        return out;
    }

    /** 队伍展示名：创建队伍时设置过名字就用设置的，否则用队伍 id；带队伍颜色。 */
    public static String teamTag(Team team) {
        String name;
        if (team instanceof net.minecraft.world.scores.PlayerTeam pt) {
            String disp = pt.getDisplayName().getString().trim();
            name = disp.isEmpty() ? pt.getName() : disp;
        } else {
            name = team.getName();
        }
        ChatFormatting color = team.getColor();
        if (color == null || !color.isColor() || color == ChatFormatting.WHITE) return name;
        return "§" + color.getChar() + name + "§r";
    }

    public static void broadcast(MinecraftServer server, Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }
}
