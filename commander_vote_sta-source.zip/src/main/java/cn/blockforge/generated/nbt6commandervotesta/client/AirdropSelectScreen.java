package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.core.S2CWheelData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * 空投"物资选择"2 级菜单：轮盘（1 级）里选空投后弹出，选本次空投的物资类型。
 * 界面与 1 级技能轮盘完全同一套画法（纯代码圆形轮盘，扇区渐变 + 悬停弹出动画），
 * 只是扇区数量按服务端配置的物资类型数量来；选定后进入瞄准模式，
 * 左键确认才真正呼叫空投。Esc（或再按轮盘键）直接关闭，不呼叫。
 *
 * <p>性能：几何全部攒进整帧一个顶点批次（WheelShapes），文字内容在 init 时缓存，
 * 每帧只读缓存、不查语言表、不重新换行，也不向服务端发任何包。
 */
public final class AirdropSelectScreen extends Screen {

    private static final String KEY_BASE = "wheel.nbt_6_commander_vote_sta.";

    /** 扇区底色（ARGB）：与 1 级轮盘同一组配色，按类型数量循环取用 */
    private static final int[] BASE_COLORS = {
            0xFF2E9CC0, // 蓝
            0xFF3FA34D, // 绿
            0xFF5D6D7E, // 灰蓝
            0xFFC25A2B, // 橙红
            0xFFB98E1F, // 金
            0xFF2C8C8C, // 青
    };

    /** 扇区之间的缝隙角度 */
    private static final float GAP_DEG = 2.5F;

    private final List<S2CWheelData.AirdropType> types;
    private int count;

    private float cx;
    private float cy;
    private float innerR;
    private float outerR;
    private float labelR;
    private int hovered = -1;

    /** 悬停动画进度（0~1），每帧向目标值缓动 */
    private float[] hoverAnim = new float[1];
    /** 扇区中线方向的 cos/sin 查找表（init 时按类型数量重建） */
    private float[] sectorCos = {0.0F};
    private float[] sectorSin = {-1.0F};

    /** init 时缓存好的文字，渲染帧里只读不重建 */
    private Component title;
    private Component bottomHint;
    private final List<Component> names = new java.util.ArrayList<>();
    private final List<List<FormattedCharSequence>> descs = new java.util.ArrayList<>();
    private int hubW;

    public AirdropSelectScreen(List<S2CWheelData.AirdropType> types) {
        super(Component.translatable(KEY_BASE + "airdrop.title"));
        this.types = types == null ? List.of() : types;
        this.count = Math.max(1, this.types.size());
    }

    @Override
    protected void init() {
        cx = this.width / 2.0F;
        cy = this.height / 2.0F + 6.0F;
        float r = Math.min(this.width, this.height) * 0.32F;
        outerR = Math.max(68.0F, Math.min(96.0F, r));
        innerR = outerR * 0.46F;
        labelR = (innerR + outerR) / 2.0F;
        hubW = (int) (innerR * 2.0F - 16.0F);

        if (hoverAnim.length != count) hoverAnim = new float[count];
        sectorCos = new float[count];
        sectorSin = new float[count];
        for (int i = 0; i < count; i++) {
            double mid = Math.toRadians(-90.0 + i * (360.0 / count) + (180.0 / count));
            sectorCos[i] = (float) Math.cos(mid);
            sectorSin[i] = (float) Math.sin(mid);
        }

        // 文字缓存：只在 init（界面尺寸变化）时重建
        names.clear();
        descs.clear();
        title = Component.translatable(KEY_BASE + "airdrop.title");
        bottomHint = Component.translatable(KEY_BASE + "airdrop.hint");
        for (S2CWheelData.AirdropType type : types) {
            String name = type == null || type.name() == null || type.name().isBlank()
                    ? (type == null ? "" : type.id()) : type.name();
            names.add(Component.literal(name == null ? "" : name));
            String desc = type == null || type.desc() == null ? "" : type.desc();
            descs.add(this.font.split(Component.literal(desc), Math.max(1, hubW + 24)));
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        hovered = pickSector(mouseX, mouseY);
        int hubWUsed = hubW;

        // 悬停动画缓动
        for (int i = 0; i < count; i++) {
            float target = i == hovered ? 1.0F : 0.0F;
            hoverAnim[i] += (target - hoverAnim[i]) * 0.38F;
            if (Math.abs(target - hoverAnim[i]) < 0.004F) hoverAnim[i] = target;
        }

        float bandW = outerR - innerR;
        float nameR = innerR + bandW * 0.30F;
        float iconR = outerR - 9.0F;
        float outerSlotR = outerR + 12.0F;
        float nameMaxW = Math.max(12.0F, 2.0F * (iconR - nameR - 6.0F));
        float seg = 360.0F / count;

        // ===== 几何阶段：全部纯色图形攒进同一个批次，整帧只向显卡提交一次 =====
        WheelShapes.startBatch();

        for (int i = 0; i < count; i++) {
            float hot = hoverAnim[i];
            int base = BASE_COLORS[i % BASE_COLORS.length];
            float a0 = -90.0F + i * seg + GAP_DEG;
            float a1 = -90.0F + (i + 1) * seg - GAP_DEG;
            int inner = WheelShapes.shade(base, 0.70F + 0.10F * hot);
            int outer = WheelShapes.brighten(base, 0.06F + 0.34F * hot);
            float r1 = outerR + 4.0F * hot;
            WheelShapes.fillSectorGradient(g, cx, cy, innerR, r1, a0, a1, inner, outer);
            if (hot > 0.03F) {
                int edge = WheelShapes.withAlpha(hot * 0.85F) | 0x00FFFFFF;
                WheelShapes.fillSector(g, cx, cy, r1 - 1.4F, r1 + 0.4F, a0, a1, edge);
                WheelShapes.fillSector(g, cx, cy, innerR - 1.6F, innerR - 0.2F, a0, a1, edge);
            }
        }

        // 中心圆盘（三层描边 + 两层填充，与 1 级轮盘一致的内凹立体感）
        WheelShapes.fillCircle(g, cx, cy, innerR - 0.6F, 0xFF3A4A5A);
        WheelShapes.fillCircle(g, cx, cy, innerR - 1.8F, 0xF50D1116);
        WheelShapes.fillCircle(g, cx, cy, innerR - 3.2F, 0xF518202B);

        // 矢量图标：物资箱 = 箱子；配置了实体的类型（载具维修箱等）= 齿轮
        for (int i = 0; i < count; i++) {
            boolean hasEntity = i < types.size() && types.get(i) != null && types.get(i).hasEntity();
            int iconColor = i == hovered ? 0xFFFFFFFF : 0xFFDDE4EA;
            drawTypeIcon(g, i, cx + sectorCos[i] * iconR, cy + sectorSin[i] * iconR, iconColor, hasEntity);
        }

        // 底部提示栏底色
        WheelShapes.fillRect(g, 0, this.height - 20, this.width, this.height, 0x8C05080C);

        WheelShapes.endBatch();

        // ===== 文字阶段 =====
        for (int i = 0; i < Math.min(count, names.size()); i++) {
            float cos = sectorCos[i];
            float sin = sectorSin[i];
            boolean hot = i == hovered;
            int nameColor = hot ? 0xFFFFFF : 0xFFE2E6EA;
            drawScaledCentered(g, names.get(i), cx + cos * nameR, cy + sin * nameR - 4, nameMaxW, nameColor);
            g.drawCenteredString(this.font, String.valueOf(i + 1),
                    (int) (cx + cos * outerSlotR), (int) (cy + sin * outerSlotR) - 4,
                    hot ? 0xFFCFD6DC : 0xFF8A939B);
        }

        // 中心盘文字：标题 / 类型名 / 说明（整块抬高一个 z 层，压在扇区名字之上）
        g.pose().pushPose();
        g.pose().translate(0, 0, 250.0F);
        int cxI = (int) cx;
        int cyI = (int) cy;
        g.drawCenteredString(this.font, title, cxI, cyI - 30, 0xFF67D8EF);
        if (hovered >= 0 && hovered < Math.min(count, names.size())) {
            drawScaledCentered(g, names.get(hovered), cxI, cyI - 16, hubWUsed,
                    WheelShapes.brighten(BASE_COLORS[hovered % BASE_COLORS.length], 0.45F));
            int y = cyI - 2;
            for (FormattedCharSequence line : descs.get(hovered)) {
                g.drawCenteredString(this.font, line, cxI, y, 0xFFC8C8C8);
                y += 10;
            }
        } else {
            g.drawCenteredString(this.font, bottomHint, cxI, cyI - 14, 0xFF79828A);
        }
        g.pose().popPose();

        g.drawCenteredString(this.font, bottomHint, this.width / 2, this.height - 15, 0xFF9AA3AB);
    }

    /** 类型图标：物资箱（箱子轮廓 + 中缝）/ 配了实体的类型（齿轮 = 圆环 + 齿） */
    private void drawTypeIcon(GuiGraphics g, int i, float x, float y, int color, boolean hasEntity) {
        if (hasEntity) {
            WheelShapes.strokeCircle(g, x, y, 3.4F, color, 1.2F);
            WheelShapes.fillCircle(g, x, y, 1.1F, color);
            for (int k = 0; k < 6; k++) {
                double a = Math.PI * 2 * k / 6;
                WheelShapes.drawLine(g,
                        x + (float) Math.cos(a) * 3.4F, y + (float) Math.sin(a) * 3.4F,
                        x + (float) Math.cos(a) * 5.2F, y + (float) Math.sin(a) * 5.2F, 1.2F, color);
            }
        } else {
            // 箱子轮廓：四条边 + 中间一条盖缝
            WheelShapes.drawLine(g, x - 4.0F, y - 3.0F, x + 4.0F, y - 3.0F, 1.1F, color);
            WheelShapes.drawLine(g, x + 4.0F, y - 3.0F, x + 4.0F, y + 3.0F, 1.1F, color);
            WheelShapes.drawLine(g, x + 4.0F, y + 3.0F, x - 4.0F, y + 3.0F, 1.1F, color);
            WheelShapes.drawLine(g, x - 4.0F, y + 3.0F, x - 4.0F, y - 3.0F, 1.1F, color);
            WheelShapes.drawLine(g, x, y - 3.0F, x, y + 3.0F, 1.0F, color);
        }
    }

    /** 居中画一行字：太宽超过 maxW 时整体等比缩小（不换行） */
    private void drawScaledCentered(GuiGraphics g, Component text, float x, float y, float maxW, int color) {
        float w = this.font.width(text);
        if (w > maxW) {
            float s = maxW / w;
            g.pose().pushPose();
            g.pose().translate(x, y, 0);
            g.pose().scale(s, s, 1.0F);
            g.pose().translate(-x, -y, 0);
            g.drawCenteredString(this.font, text, (int) x, (int) y, color);
            g.pose().popPose();
        } else {
            g.drawCenteredString(this.font, text, (int) x, (int) y, color);
        }
    }

    private int pickSector(double mx, double my) {
        double dx = mx - cx;
        double dy = my - cy;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < innerR || dist > outerR + 16.0) return -1;
        double rel = Math.toDegrees(Math.atan2(dy, dx)) + 90.0; // 0 = 正上方
        if (rel < 0) rel += 360.0;
        return (int) (rel / (360.0 / count)) % count;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && hovered >= 0) {
            pick(hovered);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // 数字键 1..n 直接选择对应类型
        if (keyCode >= GLFW.GLFW_KEY_1 && keyCode <= GLFW.GLFW_KEY_9) {
            int index = keyCode - GLFW.GLFW_KEY_1;
            if (index < count) {
                pick(index);
                return true;
            }
        }
        // 再按轮盘键 = 关闭 2 级菜单（回到游戏 / 与 Esc 一致）
        if (ClientSetup.WHEEL_KEY.matches(keyCode, scanCode)) {
            Minecraft.getInstance().setScreen(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void pick(int index) {
        if (index < 0 || index >= types.size()) return;
        pick(types.get(index));
    }

    private void pick(S2CWheelData.AirdropType type) {
        this.minecraft.getSoundManager()
                .play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        // 选好类型 → 进入空投的瞄准模式（方块顶面圆圈预览），左键确认才真正呼叫
        S2CWheelData state = WheelClient.state();
        String name = type.name() == null || type.name().isBlank() ? type.id() : type.name();
        double range = state == null ? 32.0 : state.smokeRange();
        double up = state == null ? 3.0 : state.smokeUpOffset();
        AimClient.start("airdrop", name, type.id(), range, up, 0.0, false);
        this.minecraft.setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
