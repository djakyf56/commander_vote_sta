package cn.blockforge.generated.nbt6commandervotesta;

import cn.blockforge.generated.nbt6commandervotesta.entity.AirdropBeamEntity;
import cn.blockforge.generated.nbt6commandervotesta.entity.SmokeWallEntity;
import cn.blockforge.generated.nbt6commandervotesta.entity.SupplyCrateEntity;
import cn.blockforge.generated.nbt6commandervotesta.item.ArtilleryDesignatorItem;
import cn.blockforge.generated.nbt6commandervotesta.core.ModNetwork;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(GeneratedMod.MOD_ID)
public final class GeneratedMod {
    public static final String MOD_ID = "nbt_6_commander_vote_sta";
    /** 实体专用的注册命名空间：实体 id 显示为 commander:supply_crate 之类，不再带又长又乱的模组 id */
    public static final String ENTITY_NS = "commander";

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }

    /** 用实体命名空间拼一个实体 id，例如 commander:supply_crate */
    public static ResourceLocation entityId(String path) {
        return new ResourceLocation(ENTITY_NS, path);
    }

    // ===== 注册 =====
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ENTITY_NS);

    /** 炮击坐标仪：工具包方案的炮击触发物品 */
    public static final RegistryObject<Item> ARTILLERY_DESIGNATOR =
            ITEMS.register("artillery_designator",
                    () -> new ArtilleryDesignatorItem(new Item.Properties().stacksTo(1)));

    /** 战术雾墙：可移动实体，本体不可见，视觉由粒子构成 */
    public static final RegistryObject<EntityType<SmokeWallEntity>> SMOKE_WALL =
            ENTITY_TYPES.register("smoke_wall",
                    () -> EntityType.Builder.<SmokeWallEntity>of(SmokeWallEntity::new, MobCategory.MISC)
                            .sized(2.0F, 2.5F)
                            .clientTrackingRange(16)
                            .updateInterval(20)
                            .build("smoke_wall"));

    /** 空投补给箱：从天而降的箱子实体，落地变箱子后自己消失 */
    public static final RegistryObject<EntityType<SupplyCrateEntity>> SUPPLY_CRATE =
            ENTITY_TYPES.register("supply_crate",
                    () -> EntityType.Builder.<SupplyCrateEntity>of(SupplyCrateEntity::new, MobCategory.MISC)
                            .sized(0.98F, 0.98F)
                            .clientTrackingRange(12)
                            .updateInterval(1)
                            .build("supply_crate"));

    /** 空投光柱：标记落点用，到点自动消失，不会一直留在场上 */
    public static final RegistryObject<EntityType<AirdropBeamEntity>> AIRDROP_BEAM =
            ENTITY_TYPES.register("airdrop_beam",
                    () -> EntityType.Builder.<AirdropBeamEntity>of(AirdropBeamEntity::new, MobCategory.MISC)
                            .sized(0.5F, 2.0F)
                            .clientTrackingRange(64)
                            .updateInterval(100)
                            .build("airdrop_beam"));

    public GeneratedMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        ENTITY_TYPES.register(bus);
        ModNetwork.register();
        bus.addListener(this::onCreativeTab);
    }

    private void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ARTILLERY_DESIGNATOR);
        }
    }
}