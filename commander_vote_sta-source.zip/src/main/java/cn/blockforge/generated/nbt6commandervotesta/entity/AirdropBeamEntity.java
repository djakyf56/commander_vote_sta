package cn.blockforge.generated.nbt6commandervotesta.entity;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

import java.util.UUID;

/**
 * 空投光柱：呼叫空投时在落点生成一根原版信标样式的光柱实体，
 * 用来向全场玩家标记落点；到点后自动消失，补给箱正好从天上落下。
 * 光柱颜色从配置 airdrop.beamColor 读取，并通过实体数据同步给所有客户端
 * （即使多人服里客户端没装同款配置，看到的也是同一个颜色）。
 */
public class AirdropBeamEntity extends Entity {
    /** 同步给客户端的光柱颜色（0xRRGGBB） */
    private static final EntityDataAccessor<Integer> DATA_COLOR =
            SynchedEntityData.defineId(AirdropBeamEntity.class, EntityDataSerializers.INT);

    private UUID ownerId;
    private int age;
    private int lifetime = 100;

    public AirdropBeamEntity(EntityType<? extends AirdropBeamEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public AirdropBeamEntity(ServerLevel level, BlockPos landPos, UUID ownerId, int lifetime) {
        this(GeneratedMod.AIRDROP_BEAM.get(), level);
        this.ownerId = ownerId;
        this.lifetime = Math.max(1, lifetime);
        this.entityData.set(DATA_COLOR, CommanderConfig.INSTANCE.airdrop.beamColorRgb());
        this.setPos(landPos.getX() + 0.5, landPos.getY(), landPos.getZ() + 0.5);
    }

    public int beamColor() {
        return this.entityData.get(DATA_COLOR);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (++age >= lifetime) {
            this.discard();
        }
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_COLOR, 0xFFFFFF);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.age = tag.getInt("Age");
        this.lifetime = Math.max(1, tag.getInt("Lifetime"));
        if (tag.hasUUID("Owner")) this.ownerId = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Age", age);
        tag.putInt("Lifetime", lifetime);
        if (ownerId != null) tag.putUUID("Owner", ownerId);
    }
}
