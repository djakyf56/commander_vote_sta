package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.core.S2CWheelData;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.world.level.ClipContext;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/**
 * 瞄准模式（仅客户端）：炮击 / 空投 / 雾墙这三类"要选落点"的技能，
 * 在轮盘里选中后先不发送，而是进入瞄准模式——预览直接画在世界里
 * （RenderLevelStageEvent，客户端独占渲染，只有自己能看见，不发任何包）：
 *  · 炮击 / 空投：目标方块的顶面上画一个绿色圆圈（一圈轮廓 + 中心点）；
 *    准星没指到方块（指空气/实体）时圆圈变红，且不能确认释放；
 *    炮击用的是单独的一套"火炮标定准星"（AimClient.drawArtilleryReticle）：
 *    目标区方形填充 + 方形边框 + 四角括号 + 炮队镜刻度圆环 + 十字准线 + 中心一格落点环，
 *    方形大小直接就是实际散布范围（服务端在 ±scatter 的方形里随机取点），瞄一眼就知道
 *    这一轮会覆盖多大一片；整组图案随相机距离等比放大 + 缓慢呼吸亮度，瞄远处也看得清；
 *    配置成迫击炮（artillery.approach=mortar）时还会额外画一条从斜上方插到中心的来袭弹道带
 *    （带 4 段越来越小的横刻度），一眼看出炮弹从哪边打过来；
 *  · 雾墙：在准心命中的那一点上画一条线 + 半透明"幕布"立面 + 两端立柱，线宽和
 *    高度会按相机距离等比放大（瞄多远、瞄天空都看得清）；开了"不穿墙"配置时
 *    预览线遇到方块会像服务端一样在墙前止步；预览不抬高（服务端实际生成雾墙时才
 *    向上抬 upOffset 格，避免嵌进地面）；
 *    雾墙不要求准心指到方块——指空气时照常显示、照常释放，
 *    落点取视线方向的最远处（和服务端"探测不到就落在视线最远处"一致）。
 * 左键确认才把技能发出去（拦截原版攻击，不会真的挥拳/拆方块）；右键或 Esc 取消。
 * 确认时服务端按玩家当时的准星重新结算落点：炮击/空投仍校验"必须指到方块"，
 * 雾墙则不做此校验；炮击的服务端落点也统一用"命中方块的顶面中心"，和预览是同一个点。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class AimClient {

    /** 正在瞄准的技能名；空串 = 未在瞄准 */
    private static String skill = "";
    /** 随技能附带的数据（空投 = 2 级菜单选的物资类型 id） */
    private static String data = "";
    /** HUD 上显示的技能名 */
    private static String displayName = "";
    /** 探测距离 / 方块抬高格数（upOffset 只在服务端实际生成雾墙时生效，预览不再抬高） */
    private static double spawnRange = 32.0;
    @SuppressWarnings("unused")
    private static double upOffset = 3.0;
    /** 雾墙预览线的半长（= 配置的雾墙总宽的一半）；0 表示雾墙只铺中心一面，用最小预览线 */
    private static double previewHalf = 0.0;
    /** 雾墙是否"不穿墙"（服务端 smoke.blockWalls 下发）：预览线遇到方块也照样止步 */
    private static boolean smokeWalls = true;
    /** 炮击/空投的落点圆圈半径（方块顶面上的圈，视觉上标出一格落点） */
    private static final double CIRCLE_RADIUS = 0.55;
    /** 圆圈轮廓的粗细（世界单位）；中心点半径 */
    private static final double RING_THICKNESS = 0.05;
    private static final double DOT_RADIUS = 0.14;
    // ---- 炮击预览参数（进入瞄准时从轮盘状态下发，见 applyArtilleryParams） ----
    /** 散布半径（格）= 预览外圈圆盘的大小 */
    private static double artScatter = 3.0;
    /** landing=same（全部打同一位置）：外圈收小，只标一个精确定位点 */
    private static boolean artSameSpot = false;
    /** 一轮打几发（画在 HUD 提示里） */
    private static int artStrikes = 5;
    /** approach=mortar：斜着打过来（预览多一条来袭弹道带） */
    private static boolean artMortar = false;
    /** 迫击炮入射仰角（度） */
    private static double artMortarAngle = 45.0;
    /** 迫击炮来袭方位（度，NaN = 跟着自己视线走） */
    private static float artMortarYaw = Float.NaN;
    /** 雾墙预览线的粗细（外侧半透明带 / 内侧亮线的半宽，世界单位） */
    private static final double SMOKE_WIDE = 0.16;
    private static final double SMOKE_CORE = 0.05;
    private static final double POST_HEIGHT = 0.9;
    /** Esc 按下时先把"本次暂停界面"压掉：只取消瞄准，不弹单人暂停菜单 */
    private static boolean suppressPause = false;

    /** 每帧结算的结果：准星是否指到方块（炮击/空投的释放条件；雾墙不以此为准）与当前落点 */
    private static boolean blockValid;
    /** 底部操作提示：瞄准开始时构建一次缓存，渲染帧里只读（省掉每帧查语言表） */
    private static Component hintBase;
    private static Component needBlockHint;
    /** 炮击专用的那行"这一轮怎么打"说明（发数 / 散布 / 弹道方式），同样只构建一次 */
    private static Component artInfoHint;

    private AimClient() {
    }

    /** 是否正处于瞄准模式 */
    public static boolean active() {
        return !skill.isEmpty();
    }

    /** 当前预览是否允许释放：炮击/空投必须指到方块；雾墙无此限制（指空气也能释放） */
    public static boolean valid() {
        return requiresBlock() ? blockValid : true;
    }

    /** 该技能的释放是否要求准心指到方块：炮击/空投要求，雾墙不要求 */
    private static boolean requiresBlock() {
        return !"smoke".equals(skill);
    }

    /** 进入瞄准模式（由轮盘 / 空投选择菜单调用） */
    public static void start(String skillKey, String display, String dataStr,
                             double range, double up, double radius, boolean smokeWallClip) {
        skill = skillKey;
        data = dataStr == null ? "" : dataStr;
        displayName = display;
        spawnRange = range;
        upOffset = up;
        previewHalf = Math.max(0.0, radius);
        smokeWalls = smokeWallClip;
        suppressPause = false;
        blockValid = false;
        // 提示文字只在进入瞄准时构建一次，渲染帧里直接用缓存
        hintBase = Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.hint", display);
        needBlockHint = Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.needblock");
        artInfoHint = "artillery".equals(skillKey) ? applyArtilleryParams() : null;
    }

    /**
     * 炮击瞄准时从轮盘已同步的配置里取预览参数（散布半径 / 发数 / 垂直还是迫击炮），
     * 顺便构建 HUD 上那行"这一轮会怎么打"的说明。取不到状态就退回默认值。
     */
    private static Component applyArtilleryParams() {
        S2CWheelData st = WheelClient.state();
        artScatter = st == null ? 3.0 : Math.max(0.0, st.artilleryScatter());
        artSameSpot = st != null && st.artillerySameSpot();
        artStrikes = st == null ? 5 : Math.max(0, st.artilleryStrikes());
        artMortar = st != null && st.artilleryMortar();
        artMortarAngle = st == null ? 45.0 : Math.max(15.0, Math.min(80.0, st.artilleryMortarAngle()));
        artMortarYaw = st == null ? Float.NaN : st.artilleryMortarYaw(); // NaN = 跟着自己视线
        Component area = artSameSpot
                ? Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.samespot")
                : Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.scatter",
                        String.format(java.util.Locale.ROOT, "%.1f", artScatter));
        Component approach = artMortar
                ? Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.mortar",
                        (int) Math.round(artMortarAngle))
                : Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.vertical");
        return Component.translatable("wheel." + GeneratedMod.MOD_ID + ".aim.artinfo",
                artStrikes, area, approach);
    }

    public static void cancel() {
        skill = "";
        data = "";
        suppressPause = false;
        hintBase = null;
        needBlockHint = null;
        artInfoHint = null;
    }

    /** 左键确认：把技能（含附带数据）发给服务端，服务端按当前准星结算并再次校验。
     *  雾墙不做"必须指到方块"的校验——指空气也直接发出去。 */
    public static void confirm() {
        if (!active() || !valid()) return;
        WheelClient.sendUse(skill, data);
        cancel();
    }

    /** 按瞄准的技能决定探测距离：炮击 128 / 空投 64（与服务端一致）/ 雾墙用配置的 spawnRange */
    private static double probeRange() {
        return switch (skill) {
            case "artillery" -> 128.0;
            case "airdrop" -> 64.0;
            default -> Math.max(2.0, spawnRange);
        };
    }

    /** 每帧取准星落点；同时结算"是否指到方块"。雾墙预览就画在准心命中的那一点上
     *  （不再像服务端那样抬高 upOffset——用户要求"只有实际生成向上 3 格，预览贴着命中点"）；
     *  雾墙指不到方块时落点 = 视线方向的最远处（pick 对 MISS 返回射线终点），与服务端一致。 */
    public static Vec3 currentTarget(Minecraft mc) {
        if (mc.player == null) return null;
        HitResult hit = mc.player.pick(probeRange(), 1.0F, false);
        Vec3 pos = hit.getLocation();
        if (hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK) {
            blockValid = true;
            if (!"smoke".equals(skill)) {
                // 炮击/空投：圆圈画在这个方块的顶面上（与服务端炮击落点/空投落点同一格）
                BlockPos bp = blockHit.getBlockPos();
                pos = new Vec3(bp.getX() + 0.5, bp.getY() + 1.02, bp.getZ() + 0.5);
            }
            // 雾墙：预览线就贴着命中点画（pos 保持 hit.getLocation() 原样）
        } else {
            blockValid = false;
        }
        return pos;
    }

    // ==================== 事件 ====================

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.isDeadOrDying() || mc.level == null) {
            cancel();
            return;
        }
        if (mc.screen instanceof PauseScreen && suppressPause) {
            // Esc 只取消瞄准：把刚弹出的暂停菜单关掉，瞄准一并取消
            mc.setScreen(null);
            cancel();
            return;
        }
        if (mc.screen != null) {
            // 瞄准期间开了别的界面（背包 / 聊天等）就退出瞄准
            cancel();
        }
    }

    @SubscribeEvent
    public static void onKey(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (!active() || mc.screen != null) return;
        if (event.getKey() == GLFW.GLFW_KEY_ESCAPE
                && event.getAction() != GLFW.GLFW_RELEASE) {
            suppressPause = true; // 等 ClientTick 把暂停菜单压掉并取消瞄准
        }
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered event) {
        if (!active()) return;
        if (event.isAttack()) {
            // 左键 = 确认释放；取消原版攻击（不挥拳、不拆方块、不打怪）。
            // 准星没指到方块时（炮击/空投）这里直接不释放，HUD 上会有红色提示。
            event.setCanceled(true);
            event.setSwingHand(false);
            confirm();
        } else if (event.isUseItem()) {
            // 右键 = 取消瞄准；同时拦下原版"使用物品"，避免误放方块/误用道具
            event.setCanceled(true);
            event.setSwingHand(false);
            cancel();
        }
    }

    // ==================== 世界内预览（只有自己看得见） ====================

    /**
     * 世界渲染阶段画预览：PoseStack 此刻是"空的世界坐标"，手动平移到
     * （落点 - 相机）即可让顶点按真实世界位置出现在场景里，透视、遮挡
     * 都交给渲染管线本身，不再有任何屏幕投影误差。
     */
    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || !active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        Vec3 target = currentTarget(mc);
        if (target == null) return;
        Vec3 cam = event.getCamera().getPosition();

        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        pose.translate(target.x - cam.x, target.y - cam.y, target.z - cam.z);
        Matrix4f m = pose.last().pose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        if ("smoke".equals(skill)) {
            drawSmokeInWorld(m, mc, target, cam.distanceTo(target));
        } else if ("artillery".equals(skill)) {
            drawArtilleryReticle(m, mc, target, cam.distanceTo(target), cam);
        } else {
            drawCircleInWorld(m);
        }
        // 整帧只向显卡提交一次几何（和轮盘同一套做法）
        Tesselator.getInstance().end();

        RenderSystem.enableCull();
        pose.popPose();
    }

    /** 炮击 / 空投：目标方块顶面上的圆圈（一圈轮廓 + 中心点）；准星没指方块时整圈变红 */
    private static void drawCircleInWorld(Matrix4f m) {
        int ring = blockValid ? 0xC87EE87E : 0xC8E86A6A;
        int dot = blockValid ? 0xE0B8FFC4 : 0xE0FFB0B0;
        int seg = 28;
        double rIn = CIRCLE_RADIUS - RING_THICKNESS;
        double rOut = CIRCLE_RADIUS + RING_THICKNESS;
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2 * i / seg;
            double a1 = Math.PI * 2 * (i + 1) / seg;
            // 轮廓是一圈薄片，抬 0.02 避免和方块顶面深度打架
            v(m, Math.cos(a0) * rIn, 0.02, Math.sin(a0) * rIn, ring);
            v(m, Math.cos(a0) * rOut, 0.02, Math.sin(a0) * rOut, ring);
            v(m, Math.cos(a1) * rOut, 0.02, Math.sin(a1) * rOut, ring);
            v(m, Math.cos(a0) * rIn, 0.02, Math.sin(a0) * rIn, ring);
            v(m, Math.cos(a1) * rOut, 0.02, Math.sin(a1) * rOut, ring);
            v(m, Math.cos(a1) * rIn, 0.02, Math.sin(a1) * rIn, ring);
        }
        fillDot(m, DOT_RADIUS, 0.05, dot);
    }

    // ==================== 炮击预览：火炮标定准星 ====================

    /**
     * 炮击专用预览（比原来的单圈好看，也更"有用"）：
     *  · 半透明正方形 = 这一轮炮弹实际会覆盖的范围——服务端每发是在 ±scatter 的方形区域内
     *    随机取点，所以这里照实画成方格子（像地图上的目标区），边长 = 散布半径 ×2；
     *  · 区内一个"炮队镜"刻度圆环：12 个刻度、四个方位那两根更长更亮；
     *  · 十字准线（中间留空）+ 四角括号（取景框）+ 中心一格落点环 + 亮点：
     *    中心点仍然精确指着要打的那一格；
     *  · 整组图案随相机距离等比放大（瞄多远都看得清）并缓慢"呼吸"，瞄天上、瞄远处不再糊成一团；
     *  · artillery.approach=mortar 时额外画一条从斜上方插到中心的来袭弹道带
     *    （带 4 段越来越小的横刻度），一眼看出炮弹从哪个方向打过来；
     *  · 没指到方块时整组变红，和原来的"不可释放"提示一致。
     */
    private static void drawArtilleryReticle(Matrix4f m, Minecraft mc, Vec3 target, double dist, Vec3 cam) {
        double s = Math.min(6.0, Math.max(1.0, dist / 14.0)); // 距离补偿系数
        double pulse = 0.78 + 0.22 * Math.sin(gameSeconds(mc) * 0.9); // 缓慢呼吸
        int rgb = blockValid ? 0xFFA54F : 0xFF5A5A;           // 可用=琥珀橙，不可用=红
        int core = argb(0xE8, rgb);
        int mid = argb((int) (0xB4 * pulse), rgb);
        int soft = argb((int) (0x70 * pulse), rgb);
        int fill = argb((int) (0x2A * pulse), rgb);
        int white = argb(0xF0, blockValid ? 0xFFE3A8 : 0xFFC4C4);
        double y = 0.03;
        double thin = 0.022 * s + 0.012;
        double half = artSameSpot ? 0.6 : Math.max(0.8, artScatter); // 目标区半边长
        double dial = half * 0.62;                              // 刻度圆环半径

        // 来袭弹道带（先画，让它压在目标区下面）
        if (artMortar) drawIncomingBand(m, mc, s, cam.subtract(target), core, soft);

        // 1) 目标区填充 + 边框
        squareFill(m, half, y, fill);
        squareLine(m, half, y + 0.004, thin * 1.2, mid);
        // 2) 四角括号（边框四角往内折一小段，画得更粗）
        double bl = half * 0.26;
        int[] sx = {1, -1, -1, 1};
        int[] sz = {1, 1, -1, -1};
        for (int i = 0; i < 4; i++) {
            double cx = sx[i] * half, cz = sz[i] * half;
            lineXZ(m, cx, cz, cx - sx[i] * bl, cz, thin * 2.2, y + 0.006, core);
            lineXZ(m, cx, cz, cx, cz - sz[i] * bl, thin * 2.2, y + 0.006, core);
        }
        // 3) 刻度圆环 + 12 个刻度（四方位那两根更长更亮）
        ringXZ(m, dial - thin, dial + thin, y + 0.008, soft, 40);
        for (int i = 0; i < 12; i++) {
            double a = Math.PI * 2 * i / 12;
            boolean cardinal = i % 3 == 0;
            double len = cardinal ? 0.20 * s + 0.10 : 0.10 * s + 0.05;
            double wx = Math.cos(a), wz = Math.sin(a);
            lineXZ(m, wx * (dial - len), wz * (dial - len), wx * (dial + thin), wz * (dial + thin),
                    cardinal ? thin * 1.7 : thin, y + 0.010, cardinal ? core : soft);
        }
        // 4) 十字准线：四条从刻度环伸向边框的短杠，中间让给落点
        double cIn = dial + thin + 0.06, cOut = half - thin;
        if (cOut > cIn) {
            lineXZ(m, cIn, 0, cOut, 0, thin, y + 0.012, soft);
            lineXZ(m, -cIn, 0, -cOut, 0, thin, y + 0.012, soft);
            lineXZ(m, 0, cIn, 0, cOut, thin, y + 0.012, soft);
            lineXZ(m, 0, -cIn, 0, -cOut, thin, y + 0.012, soft);
        }
        // 5) 中心落点：一格环 + 亮点（炮击真正打在这一格中心）
        ringXZ(m, CIRCLE_RADIUS - RING_THICKNESS, CIRCLE_RADIUS + RING_THICKNESS, y + 0.014, core, 28);
        fillDot(m, Math.min(0.22, 0.06 * s + 0.05), y + 0.018, white);
    }

    /**
     * 迫击炮的"来袭弹道带"：从斜上方（服务端 mortarStart 的同一条线，按比例缩短到预览高度）
     * 插到中心落点。带子顶端宽而淡、落点端细而亮，再叠 4 段越来越小的横刻度，
     * 看着就是"炮弹正从那边砸进来"。方向：固定方位用配置值，look 则按自己视线折四方向。
     */
    private static void drawIncomingBand(Matrix4f m, Minecraft mc, double s, Vec3 camLocal, int core, int soft) {
        // 与服务端 SkillManager.mortarBearing 完全同一套换算：
        // 固定方位直接用配置值；look 时"从身后打来"= 自己视线折出的四方向 +180°
        float yaw = Float.isNaN(artMortarYaw)
                ? cardinalYawFromBehind(mc.player == null ? new Vec3(0, 0, 1)
                        : mc.player.getLookAngle().multiply(1, 0, 1))
                : artMortarYaw;
        double h = Math.min(14.0, 5.0 + 3.5 * s);
        double horiz = h / Math.tan(Math.toRadians(artMortarAngle));
        Vec3 back = new Vec3(-Math.sin(Math.toRadians(yaw)), 0, Math.cos(Math.toRadians(yaw)));
        Vec3 top = back.scale(horiz).add(0, h, 0);            // 弹道起点（本地坐标，中心=落点）
        Vec3 view = top.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, -1)
                : new Vec3(-camLocal.x, -camLocal.y, -camLocal.z).normalize(); // 相机指向落点
        Vec3 seg = top.scale(-1.0).normalize();               // 飞行方向（起点 → 落点）
        Vec3 side = seg.cross(view);
        if (side.lengthSqr() < 1.0E-6) side = new Vec3(1, 0, 0);
        side = side.normalize();
        // 主弹道带：顶端（远处）宽而淡，落点端细而亮
        ribbon(m, top.x, top.y, top.z, 0, 0.02, 0,
                0.16 * s + 0.05, 0.03 * s + 0.012, soft, core, view);
        // 4 段横刻度（越靠近落点越短，形成收敛的速度线）
        for (int k = 1; k <= 4; k++) {
            double t = k / 5.0;
            Vec3 p = top.scale(1.0 - t);
            double half = (0.16 * s + 0.06) * (0.45 + 0.85 * (1.0 - t));
            ribbon(m, p.x - side.x * half, p.y - side.y * half, p.z - side.z * half,
                    p.x + side.x * half, p.y + side.y * half, p.z + side.z * half,
                    0.012 * s + 0.006, 0.012 * s + 0.006, core, core, view);
        }
    }

    /** 与服务端 SkillManager.cardinalYaw 同一套换算：视线折成东南西北之一的 yaw */
    private static float cardinalYaw(Vec3 look) {
        if (Math.abs(look.z) >= Math.abs(look.x)) return look.z >= 0 ? 0.0F : 180.0F;
        return look.x >= 0 ? -90.0F : 90.0F;
    }

    /**
     * "跟视线"时的来袭方位：与服务端 SkillManager.mortarBearing 一致——
     * 你朝哪看，炮弹就从你**身后**越过头顶飞向落点（己方阵地在背后），所以取视线四方向再 +180°。
     */
    private static float cardinalYawFromBehind(Vec3 look) {
        float y = cardinalYaw(look) + 180.0F;
        if (y > 180.0F) y -= 360.0F;
        return y;
    }

    /** 平滑动画用的时间（秒）：游戏刻 + 帧内插值，避免抖 */
    private static double gameSeconds(Minecraft mc) {
        if (mc.level == null) return 0.0;
        return mc.level.getGameTime() / 20.0 + mc.getFrameTime() / 20.0;
    }

    /** ARGB 拼色：a=透明度 0~255，rgb=0xRRGGBB */
    private static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    /** 贴地实心正方形（-h..+h，两三角）：炮击目标区填充 */
    private static void squareFill(Matrix4f m, double h, double y, int argb) {
        v(m, -h, y, -h, argb);
        v(m, h, y, -h, argb);
        v(m, h, y, h, argb);
        v(m, -h, y, -h, argb);
        v(m, h, y, h, argb);
        v(m, -h, y, h, argb);
    }

    /** 贴地正方形边框（四条细线）：炮击目标区边框 */
    private static void squareLine(Matrix4f m, double h, double y, double w, int argb) {
        lineXZ(m, -h, -h, h, -h, w, y, argb);
        lineXZ(m, h, -h, h, h, w, y, argb);
        lineXZ(m, h, h, -h, h, w, y, argb);
        lineXZ(m, -h, h, -h, -h, w, y, argb);
    }

    /** 贴地圆环（rIn~rOut） */
    private static void ringXZ(Matrix4f m, double rIn, double rOut, double y, int argb, int seg) {
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2 * i / seg;
            double a1 = Math.PI * 2 * (i + 1) / seg;
            double c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            v(m, c0 * rIn, y, s0 * rIn, argb);
            v(m, c0 * rOut, y, s0 * rOut, argb);
            v(m, c1 * rOut, y, s1 * rOut, argb);
            v(m, c0 * rIn, y, s0 * rIn, argb);
            v(m, c1 * rOut, y, s1 * rOut, argb);
            v(m, c1 * rIn, y, s1 * rIn, argb);
        }
    }

    /** 贴地细线段（从 (x0,z0) 到 (x1,z1)，半宽 w）：刻度、准线、括号都靠它 */
    private static void lineXZ(Matrix4f m, double x0, double z0, double x1, double z1, double w, double y, int argb) {
        double dx = x1 - x0;
        double dz = z1 - z0;
        double len = Math.hypot(dx, dz);
        if (len < 1.0E-6) return;
        double px = -dz / len * w;
        double pz = dx / len * w;
        v(m, x0 + px, y, z0 + pz, argb);
        v(m, x0 - px, y, z0 - pz, argb);
        v(m, x1 - px, y, z1 - pz, argb);
        v(m, x0 + px, y, z0 + pz, argb);
        v(m, x1 - px, y, z1 - pz, argb);
        v(m, x1 + px, y, z1 + pz, argb);
    }

    /** 面向相机的锥形条带（本地坐标，两端半宽与颜色可不同）：来袭弹道带与横刻度用 */
    private static void ribbon(Matrix4f m, double ax, double ay, double az,
                               double bx, double by, double bz,
                               double wa, double wb, int colA, int colB, Vec3 view) {
        Vec3 a = new Vec3(ax, ay, az);
        Vec3 b = new Vec3(bx, by, bz);
        Vec3 seg = b.subtract(a);
        if (seg.lengthSqr() < 1.0E-8) return;
        Vec3 side = seg.cross(view);
        if (side.lengthSqr() < 1.0E-8) side = new Vec3(1, 0, 0);
        side = side.normalize();
        Vec3 a0 = a.subtract(side.scale(wa));
        Vec3 a1 = a.add(side.scale(wa));
        Vec3 b0 = b.subtract(side.scale(wb));
        Vec3 b1 = b.add(side.scale(wb));
        v(m, a0.x, a0.y, a0.z, colA);
        v(m, a1.x, a1.y, a1.z, colA);
        v(m, b1.x, b1.y, b1.z, colB);
        v(m, a0.x, a0.y, a0.z, colA);
        v(m, b1.x, b1.y, b1.z, colB);
        v(m, b0.x, b0.y, b0.z, colB);
    }

    /**
     * 雾墙预览：一条线 + 半透明"幕布"立面 + 两端立柱 + 中心点。
     * 所有粗细/高度都随"相机到预览点的距离"等比放大（封顶 6 倍），
     * 修掉"瞄远处/瞄天空时预览细得看不见"的问题：不管瞄多远，屏幕上看到的
     * 粗细基本一致；立面（幕布）保证从侧面、贴着地面看也能分辨墙的范围和高度。
     * 开了"不穿墙"（服务端 smoke.blockWalls）时，预览线左右各打一条射线，
     * 被方块挡住就在墙前止步——和服务端铺墙的规则一致。
     */
    private static void drawSmokeInWorld(Matrix4f m, Minecraft mc, Vec3 target, double dist) {
        // 侧向向量：玩家水平视线的垂直方向（与服务端铺雾墙用的同一个方向）
        Vec3 look = mc.player.getLookAngle().multiply(1, 0, 1);
        Vec3 side = look.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : new Vec3(-look.z, 0, look.x).normalize();
        double half = previewHalf > 0.0 ? previewHalf : 1.5;
        double halfR = smokeWalls ? clipSide(mc, target, side, half) : half;
        double halfL = smokeWalls ? clipSide(mc, target, side.scale(-1.0), half) : half;
        double s = Math.min(6.0, Math.max(1.0, dist / 16.0)); // 距离补偿系数（16 格内为 1，越远越粗，封顶 6）
        double wide = Math.min(0.6, SMOKE_WIDE * s);
        double core = Math.min(0.18, SMOKE_CORE * s * 1.6);
        double postH = Math.min(5.0, POST_HEIGHT * s);
        double curtainH = Math.min(4.0, Math.max(1.6, 1.4 * s));
        // 外层柔光带（贴地）
        strip(m, side, look, halfL + 0.1, halfR + 0.1, wide, 0.01, 0x387EE87E);
        // 半透明幕布立面 + 更亮的顶边：从落点向上表示墙的高度，对空瞄准时也看得见
        curtain(m, side, halfL, halfR, 0.01, curtainH, 0x3379E079);
        curtain(m, side, halfL, halfR, curtainH - Math.min(0.14, curtainH * 0.08), curtainH, 0xC8B8FFC4);
        // 内侧亮线（贴地主线）
        strip(m, side, look, halfL, halfR, core, 0.02, 0xE87EE87E);
        // 两端立柱（十字截面，高随距离放大）：标出雾墙的两个边缘
        post(m, side.scale(-halfL), side, look, postH);
        post(m, side.scale(halfR), side, look, postH);
        fillDot(m, Math.min(0.5, 0.10 * s), 0.03, 0xF0B8FFC4);
    }

    /** 预览线截断：从中心沿 dir 探 half 远，被方块挡住就返回"中心到挡点"的距离（每帧两条射线，仅瞄准时跑，开销可忽略） */
    private static double clipSide(Minecraft mc, Vec3 center, Vec3 dir, double half) {
        if (mc.level == null || half <= 0.0) return half;
        Vec3 to = center.add(dir.scale(half));
        HitResult hit = mc.level.clip(new ClipContext(center, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, null));
        if (hit == null || hit.getType() == HitResult.Type.MISS) return half;
        return Math.max(0.0, center.distanceTo(hit.getLocation()) - 0.35);
    }

    /** 竖直幕布面：沿 side 方向从 -halfL 到 +halfR、y0 到 y1 的矩形（双面，cull 已关） */
    private static void curtain(Matrix4f m, Vec3 side, double halfL, double halfR, double y0, double y1, int argb) {
        Vec3 a = side.scale(-halfL);
        Vec3 b = side.scale(halfR);
        v(m, a.x, y0, a.z, argb);
        v(m, b.x, y0, b.z, argb);
        v(m, b.x, y1, b.z, argb);
        v(m, a.x, y0, a.z, argb);
        v(m, b.x, y1, b.z, argb);
        v(m, a.x, y1, a.z, argb);
    }

    /** 贴地条带：沿 side 方向从 -halfL 铺到 +halfR，沿 look 方向铺 w*2 宽 */
    private static void strip(Matrix4f m, Vec3 side, Vec3 look, double halfL, double halfR, double w, double y, int argb) {
        Vec3 a = side.scale(-halfL).add(look.scale(-w));
        Vec3 b = side.scale(-halfL).add(look.scale(w));
        Vec3 c = side.scale(halfR).add(look.scale(w));
        Vec3 d = side.scale(halfR).add(look.scale(-w));
        v(m, a.x, y, a.z, argb);
        v(m, b.x, y, b.z, argb);
        v(m, c.x, y, c.z, argb);
        v(m, a.x, y, a.z, argb);
        v(m, c.x, y, c.z, argb);
        v(m, d.x, y, d.z, argb);
    }

    /** 小立柱：以 offset 为中心、高 h 的细十字（side 方向一面 + look 方向一面） */
    private static void post(Matrix4f m, Vec3 offset, Vec3 side, Vec3 look, double h) {
        double w = 0.05;
        // side 方向面
        v(m, offset.x - side.x * w, 0.0, offset.z - side.z * w, 0xC87EE87E);
        v(m, offset.x + side.x * w, 0.0, offset.z + side.z * w, 0xC87EE87E);
        v(m, offset.x + side.x * w, h, offset.z + side.z * w, 0xC87EE87E);
        v(m, offset.x - side.x * w, 0.0, offset.z - side.z * w, 0xC87EE87E);
        v(m, offset.x + side.x * w, h, offset.z + side.z * w, 0xC87EE87E);
        v(m, offset.x - side.x * w, h, offset.z - side.z * w, 0xC87EE87E);
        // look 方向面（正交的另一面，保证侧面视角也看得见）
        v(m, offset.x - look.x * w, 0.0, offset.z - look.z * w, 0xC87EE87E);
        v(m, offset.x + look.x * w, 0.0, offset.z + look.z * w, 0xC87EE87E);
        v(m, offset.x + look.x * w, h, offset.z + look.z * w, 0xC87EE87E);
        v(m, offset.x - look.x * w, 0.0, offset.z - look.z * w, 0xC87EE87E);
        v(m, offset.x + look.x * w, h, offset.z + look.z * w, 0xC87EE87E);
        v(m, offset.x - look.x * w, h, offset.z - look.z * w, 0xC87EE87E);
    }

    /** 贴地小圆点（三角扇）：圆心在原点上方 yOff */
    private static void fillDot(Matrix4f m, double r, double yOff, int argb) {
        int seg = 16;
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2 * i / seg;
            double a1 = Math.PI * 2 * (i + 1) / seg;
            v(m, 0, yOff, 0, argb);
            v(m, Math.cos(a0) * r, yOff, Math.sin(a0) * r, argb);
            v(m, Math.cos(a1) * r, yOff, Math.sin(a1) * r, argb);
        }
    }

    /** 世界顶点：本地坐标（相对落点），颜色 ARGB */
    private static void v(Matrix4f m, double x, double y, double z, int argb) {
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;
        Tesselator.getInstance().getBuilder()
                .vertex(m, (float) x, (float) y, (float) z)
                .color(r, g, b, a).endVertex();
    }

    // ==================== HUD 文字提示 ====================

    /** HUD 只负责文字：底部操作提示与"需要瞄准方块"的红色提醒（预览本体已改画在世界里） */
    public static void renderOverlay(GuiGraphics g, int width, int height) {
        if (!active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        // 底部操作提示（瞄准开始时缓存好的文字，不再每帧查语言表）
        g.drawCenteredString(mc.font, hintBase, width / 2, height - 46, 0xFF9FE89F);
        // 炮击：再补一行"这一轮怎么打"（发数 / 散布范围 / 垂直还是迫击炮），颜色跟着可用状态走
        if (artInfoHint != null) {
            g.drawCenteredString(mc.font, artInfoHint, width / 2, height - 62,
                    blockValid ? 0xFFFFC470 : 0xFFFF8080);
        }
        // 炮击/空投没指到方块：在提示上方补一行红色提醒
        if (!"smoke".equals(skill) && !blockValid) {
            g.drawCenteredString(mc.font, needBlockHint, width / 2, height - 76, 0xFFFF6A6A);
        }
    }
}
