package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.entity.AirdropBeamEntity;
import cn.blockforge.generated.nbt6commandervotesta.entity.SupplyCrateEntity;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** 仅客户端：实体渲染器注册 + 技能轮盘按键注册。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    private ClientSetup() {
    }

    /** 打开技能轮盘的按键，默认 V，可在"按键设置 -> 指挥官系统"里改 */
    public static final KeyMapping WHEEL_KEY = new KeyMapping(
            "key.nbt_6_commander_vote_sta.wheel", GLFW.GLFW_KEY_V,
            "key.categories.nbt_6_commander_vote_sta");

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(WHEEL_KEY);
    }

    /** 瞄准模式的落点指示器：画在所有原版 HUD 之上 */
    @SubscribeEvent
    public static void onRegisterGuiOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("aim_marker",
                (gui, graphics, partialTick, width, height) -> AimClient.renderOverlay(graphics, width, height));
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GeneratedMod.SMOKE_WALL.get(), NoopRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SUPPLY_CRATE.get(), SupplyCrateRenderer::new);
        event.registerEntityRenderer(GeneratedMod.AIRDROP_BEAM.get(), AirdropBeamRenderer::new);
    }
}