package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 炮击死亡消息"聊天框 ≠ 死亡界面"的客户端半边。
 *
 * <p>原版 1.20.1 里，聊天广播（给所有人）和死亡界面副标题（只给死者本人）
 * 用的是<b>同一条</b> Component（服务端 ServerPlayer#die 取一次、两处共用），
 * 单靠伤害类型没法让两者显示不同的文字。所以：
 * <ul>
 *   <li>服务端把死亡界面版（第二人称「你被…」，键 death.attack.commander_artillery.screen）
 *       同时发给聊天和死亡界面；</li>
 *   <li>客户端在收到<b>聊天</b>消息时认出这个键，把文字换成第三人称的聊天版
 *       （键 death.attack.commander_artillery.killer，「XX 被 YY 的炮击…」）；</li>
 *   <li>死亡界面的包不经过聊天事件，保持死亡界面版不变。</li>
 * </ul>
 * 两段文字都可以在语言文件里改（assets/…/lang/zh_cn.json）。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class DeathChatClient {

    /** 服务端发来的"死亡界面版"翻译键（聊天里认出来后要换成下面的聊天版） */
    private static final String SCREEN_KEY = "death.attack.commander_artillery.screen";
    /** 聊天框里显示的"第三人称版"翻译键 */
    private static final String CHAT_KEY = "death.attack.commander_artillery.killer";

    private DeathChatClient() {
    }

    @SubscribeEvent
    public static void onSystemChat(ClientChatReceivedEvent.System event) {
        Component msg = event.getMessage();
        if (msg.getContents() instanceof TranslatableContents tc && SCREEN_KEY.equals(tc.getKey())) {
            // 参数原样搬过去：args[0]=死者名，args[1]=指挥官名
            event.setMessage(Component.translatable(CHAT_KEY, tc.getArgs()));
        }
    }
}
