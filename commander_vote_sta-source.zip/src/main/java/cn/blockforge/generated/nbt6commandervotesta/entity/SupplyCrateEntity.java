package cn.blockforge.generated.nbt6commandervotesta.entity;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig;
import cn.blockforge.generated.nbt6commandervotesta.core.SkillManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;

import java.util.UUID;

/**
 * 空投补给箱实体：从高处缓缓下落，途中带拖尾粒子与"降落伞"粒子环，
 * 落地后按 airdrop.landAsItems 决定：直接把物资撒成掉落物（默认，不出现箱子），
 * 或放一个装好物资的箱子——无论哪种，实体自己都会消失，不会一直留在场上。
 * 下落速度、拖尾粒子、风声、落地音效都在配置 airdrop 一节里可调；
 * 箱子模式下放下的箱子还会按 airdrop.chestSeconds 自动消失（0=一直留着）。
 */
public class SupplyCrateEntity extends Entity {
    private UUID ownerId;
    private BlockPos landPos;
    private int age;

    public SupplyCrateEntity(EntityType<? extends SupplyCrateEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public SupplyCrateEntity(ServerLevel level, BlockPos spawnPos, BlockPos landPos, UUID ownerId) {
        this(GeneratedMod.SUPPLY_CRATE.get(), level);
        this.landPos = landPos;
        this.ownerId = ownerId;
        this.setPos(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (!(level() instanceof ServerLevel level)) return;
        CommanderConfig.AirdropCfg cfg = CommanderConfig.INSTANCE.airdrop;
        age++;
        if (landPos == null) {
            // 极端情况（存档损坏等）：直接把当前位置当落点
            landPos = BlockPos.containing(position());
        }
        double targetY = landPos.getY();
        if (getY() <= targetY + 0.01) {
            land(level, cfg);
            return;
        }
        // 缓缓下落
        double speed = Math.max(0.05, cfg.fallSpeed);
        this.setPos(getX(), Math.max(targetY, getY() - speed), getZ());

        // 下落特效：拖尾粒子 + 头顶"降落伞"粒子环
        ParticleOptions trail = SmokeWallEntity.parseParticle(cfg.trailParticle);
        if (age % 2 == 0) {
            level.sendParticles(trail, getX(), getY() + 1.6, getZ(), 2, 0.15, 0.05, 0.15, 0.0);
        }
        if (age % 5 == 0) {
            for (int i = 0; i < 8; i++) {
                double a = Math.PI * 2 * i / 8;
                level.sendParticles(trail,
                        getX() + Math.cos(a) * 1.2, getY() + 2.0, getZ() + Math.sin(a) * 1.2,
                        1, 0, 0, 0, 0);
            }
        }
        // 风声
        if (age % 20 == 0 && cfg.fallSound != null && !cfg.fallSound.isBlank()) {
            SoundEvent s = SmokeWallEntity.parseSound(cfg.fallSound);
            if (s != null) {
                level.playSound(null, getX(), getY(), getZ(), s, SoundSource.PLAYERS, 0.4F, 1.0F);
            }
        }
    }

    /** 落地：默认直接把物资撒成掉落物（landAsItems=true）；关掉时放一个装满物资的箱子。特效 + 音效后实体自己消失 */
    private void land(ServerLevel level, CommanderConfig.AirdropCfg cfg) {
        BlockPos pos = landPos;
        int tries = 0;
        while (!level.getBlockState(pos).isAir() && tries < 16) {
            pos = pos.above();
            tries++;
        }
        ParticleOptions burst = SmokeWallEntity.parseParticle(cfg.particle);
        level.sendParticles(burst, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                12, 0.4, 0.4, 0.4, 0.02);
        if (cfg.landSound != null && !cfg.landSound.isBlank()) {
            SoundEvent s = SmokeWallEntity.parseSound(cfg.landSound);
            if (s != null) {
                level.playSound(null, pos, s, SoundSource.PLAYERS, 1.0F, 0.9F);
            }
        }
        if (cfg.landAsItems) {
            // 一落地就直接生成掉落物：不留箱子，什么都不占地方
            SkillManager.dropAirdropLoot(level, pos);
            this.discard();
            return;
        }
        level.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);
        SkillManager.fillCrate(level, pos);
        this.discard();

        // 箱子不一直留在场上：到点自动消失（先把里面的物品全部掉在地上，不会丢东西）
        int chestSeconds = Math.max(0, cfg.chestSeconds);
        if (chestSeconds > 0) {
            final BlockPos chestPos = pos;
            cn.blockforge.generated.nbt6commandervotesta.core.TickHandler.schedule(
                    level.getServer(), chestSeconds * 20, () -> despawnChest(level, chestPos, burst));
        }
    }

    /** 箱子到点消失：先确认那格还是我们的箱子，再把物品掉在地上，最后变回空气 */
    private void despawnChest(ServerLevel level, BlockPos pos, ParticleOptions burst) {
        if (!(level.getBlockState(pos).getBlock() instanceof ChestBlock)
                || !(level.getBlockEntity(pos) instanceof ChestBlockEntity chest)) {
            return; // 已经被玩家拆掉或换成了别的方块，不动它
        }
        // 里面的物品全部掉在地上，不会丢东西
        net.minecraft.world.Containers.dropContents(level, pos, chest);
        level.removeBlockEntity(pos);
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        level.sendParticles(burst, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                8, 0.4, 0.4, 0.4, 0.01);
        level.levelEvent(2001, pos, 0); // 原版"方块破坏"的裂纹粒子效果
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.age = tag.getInt("Age");
        if (tag.contains("Land")) this.landPos = BlockPos.of(tag.getLong("Land"));
        if (tag.hasUUID("Owner")) this.ownerId = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Age", age);
        if (landPos != null) tag.putLong("Land", landPos.asLong());
        if (ownerId != null) tag.putUUID("Owner", ownerId);
    }
}