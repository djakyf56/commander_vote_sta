package cn.blockforge.generated.nbt6commandervotesta.client;

import cn.blockforge.generated.nbt6commandervotesta.core.S2CWheelData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * 技能轮盘：纯代码绘制的圆形技能界面，不使用任何图片贴图。
 * 六个扇区对应六个技能，鼠标悬停选中，点击或按 1-6 直接使用；
 * 中心圆盘显示选中技能的说明与实时状态（冷却/等级/模块开关），
 * 状态数据由服务端每秒推送一次。
 *
 * <p>UI 细节（全部顶点绘制，无贴图）：
 * 扇区由内到外颜色渐变，带一点立体感；悬停有平滑的"弹出"动画（放大 + 提亮 + 白色描边）；
 * 冷却中的技能覆盖一个逐渐收拢的暗色转盘（类似原版物品冷却），扇区上直接显示剩余秒数；
 * 每个技能配一个矢量小图标（雷达/降落伞/云朵/准星/箭头）；底部有半透明提示栏。
 */
public final class SkillWheelScreen extends Screen {

    private static final String KEY_BASE = "wheel.nbt_6_commander_vote_sta.";

    /** 六个技能的底色（ARGB），顺序与 ModNetwork.SKILLS 一致 */
    private static final int[] BASE_COLORS = {
            0xFF2E9CC0, // 侦察扫描：蓝
            0xFF3FA34D, // 空投补给：绿
            0xFF5D6D7E, // 战术雾墙：灰蓝
            0xFFC25A2B, // 炮击支援：橙红
            0xFFB98E1F, // 全军突击：金
            0xFF2C8C8C, // 战略撤退：青
    };

    /** 扇区之间的缝隙角度 */
    private static final float GAP_DEG = 2.5F;

    private float cx;
    private float cy;
    private float innerR;
    private float outerR;
    private float labelR;
    private int hovered = -1;
    private int refreshTimer;

    /** 悬停动画进度（0~1），每帧向目标值缓动，做出平滑弹出/收回的过渡 */
    private final float[] hoverAnim = new float[6];
    /** 打开期间见过的最大冷却 tick，用来把剩余冷却画成逐渐收拢的转盘（类似原版物品冷却） */
    private final int[] cdMax = new int[6];
    /** 中心盘文字宽度，init 时算好 */
    private int hubW;
    /** 扇区中线方向的 cos/sin 查找表：每帧直接查表，不再重复算三角函数 */
    private static final float[] SECTOR_COS = new float[6];
    private static final float[] SECTOR_SIN = new float[6];

    static {
        for (int i = 0; i < 6; i++) {
            double mid = Math.toRadians(-90.0 + i * 60.0 + 30.0);
            SECTOR_COS[i] = (float) Math.cos(mid);
            SECTOR_SIN[i] = (float) Math.sin(mid);
        }
    }

    // 文字缓存：Component / 换行结果只在收到新状态包（每秒一次）或中心盘尺寸变化时重建，
    // 渲染帧里只读缓存，不再反复 new Component、查语言表和重新换行。
    private S2CWheelData cacheState;
    private int cacheHubW = -1;
    private final Component[] cacheShort = new Component[6];
    private final Component[] cacheName = new Component[6];
    private final Component[] cacheStatus = new Component[6];
    private final Component[] cacheCdLabel = new Component[6];
    @SuppressWarnings("unchecked")
    private final List<FormattedCharSequence>[] cacheDesc = new List[6];
    private Component cacheTopText;
    private int cacheTopColor;
    private boolean cacheTopVisible;
    private Component cacheCenterTitle;
    private Component cacheCenterReady;
    private Component cacheCenterPoints;
    private List<FormattedCharSequence> cacheHintLines;
    private Component cacheBottomText;

    public SkillWheelScreen() {
        super(Component.translatable(KEY_BASE + "title"));
    }

    @Override
    protected void init() {
        cx = this.width / 2.0F;
        cy = this.height / 2.0F + 6.0F;
        float r = Math.min(this.width, this.height) * 0.32F;
        outerR = Math.max(68.0F, Math.min(96.0F, r));
        innerR = outerR * 0.46F;
        labelR = (innerR + outerR) / 2.0F;
        hubW = (int) (innerR * 2.0F - 16.0F);
    }

    @Override
    public void tick() {
        // 打开期间每秒向服务端要一次最新状态（冷却倒数、等级变化都会实时反映）
        if (++refreshTimer >= 20) {
            refreshTimer = 0;
            WheelClient.sendOpen();
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        hovered = pickSector(mouseX, mouseY);
        S2CWheelData state = WheelClient.state();
        refreshCaches(state);

        // 悬停动画缓动：本帧向目标（1=悬停 / 0=离开）靠拢一步
        for (int i = 0; i < 6; i++) {
            float target = i == hovered ? 1.0F : 0.0F;
            hoverAnim[i] += (target - hoverAnim[i]) * 0.38F;
            if (Math.abs(target - hoverAnim[i]) < 0.004F) hoverAnim[i] = target;
        }

        // 槽位布局：外圈=数字键/倒计时，环带内侧=技能名，外缘=矢量图标
        float bandW = outerR - innerR;
        float nameR = innerR + bandW * 0.30F; // 名字靠内，离中心盘留出空隙
        float iconR = outerR - 9.0F;          // 图标靠外缘，跟名字之间留出整段径向距离
        float outerSlotR = outerR + 12.0F;    // 数字键/倒计时在轮盘外面，永远不跟扇区内容打架
        float nameMaxW = Math.max(12.0F, 2.0F * (iconR - nameR - 6.0F));

        // ===== 几何阶段：全部纯色图形攒进同一个批次，整帧只向显卡提交一次 =====
        WheelShapes.startBatch();

        // 1. 六个扇区：内圈压暗、外圈提亮的渐变 + 悬停弹出
        for (int i = 0; i < 6; i++) {
            float hot = hoverAnim[i];
            boolean ok = usable(state, i);
            int base = ok ? BASE_COLORS[i] : 0xFF2B323A;
            float a0 = -90.0F + i * 60.0F + GAP_DEG;
            float a1 = -90.0F + (i + 1) * 60.0F - GAP_DEG;
            int inner = WheelShapes.shade(base, 0.70F + 0.10F * hot);
            int outer = WheelShapes.brighten(base, 0.06F + 0.34F * hot);
            float r1 = outerR + 4.0F * hot;
            WheelShapes.fillSectorGradient(g, cx, cy, innerR, r1, a0, a1, inner, outer);
            // 冷却转盘：剩余冷却占比越大，暗色扇形盖得越多，随时间逐渐"扫"开
            float cdFrac = cooldownFraction(state, i);
            if (cdFrac > 0.01F) {
                WheelShapes.fillSector(g, cx, cy, innerR, r1, a0, a0 + (a1 - a0) * cdFrac, 0xA0000000);
            }
            // 悬停描边：一圈白色亮边随动画淡入，选中感更清楚
            if (hot > 0.03F) {
                int edge = WheelShapes.withAlpha(hot * 0.85F) | 0x00FFFFFF;
                WheelShapes.fillSector(g, cx, cy, r1 - 1.4F, r1 + 0.4F, a0, a1, edge);
                WheelShapes.fillSector(g, cx, cy, innerR - 1.6F, innerR - 0.2F, a0, a1, edge);
            }
        }

        // 2. 中心圆盘（三层描边 + 两层填充，做出一点内凹立体感）
        WheelShapes.fillCircle(g, cx, cy, innerR - 0.6F, 0xFF3A4A5A);
        WheelShapes.fillCircle(g, cx, cy, innerR - 1.8F, 0xF50D1116);
        WheelShapes.fillCircle(g, cx, cy, innerR - 3.2F, 0xF518202B);

        // 3. 矢量图标（几何部分，攒进同一个批次）
        for (int i = 0; i < 6; i++) {
            boolean ok = usable(state, i);
            int iconColor = ok ? (i == hovered ? 0xFFFFFFFF : 0xFFDDE4EA) : 0xFF66707A;
            drawIcon(g, i, cx + SECTOR_COS[i] * iconR, cy + SECTOR_SIN[i] * iconR, iconColor);
        }

        // 4. 三块平色底：中心状态药丸 / 顶部提示条 / 底部提示栏。
        //    状态药丸整块抬高一个 z 层（z=200）：1.20 的 GUI 按深度分层渲染，
        //    文字统一在帧末才上屏，只靠绘制顺序的话，先画的底色块永远会被
        //    后上屏的技能名字盖住——这正是之前"中间提示被技能名挡住"的原因。
        drawBarShapes(g, state);

        WheelShapes.endBatch();

        // ===== 文字阶段（字体绘制走自己的缓冲，帧末统一上屏） =====
        for (int i = 0; i < 6; i++) {
            float cos = SECTOR_COS[i];
            float sin = SECTOR_SIN[i];
            boolean ok = usable(state, i);
            boolean hot = i == hovered;
            int nameColor = hot ? 0xFFFFFF : (ok ? 0xFFE2E6EA : 0xFF79828A);
            // 技能名：按"到图标之间的可用宽度"自动等比缩小，再长的名字也压不到图标和中心盘
            drawScaledCentered(g, cacheShort[i], cx + cos * nameR, cy + sin * nameR - 4, nameMaxW, nameColor);
            // 外圈槽位：就绪时是数字快捷键；冷却中换成金色倒计时，跟数字键共用一个槽位，绝不与名字重叠
            int cd = cooldownTicks(state, i);
            if (cd > 0) {
                drawScaledCentered(g, cacheCdLabel[i],
                        cx + cos * outerSlotR, cy + sin * outerSlotR - 4, 44.0F, 0xFFE8C86A);
            } else {
                g.drawCenteredString(this.font, String.valueOf(i + 1),
                        (int) (cx + cos * outerSlotR), (int) (cy + sin * outerSlotR) - 4,
                        hot ? 0xFFCFD6DC : (ok ? 0xFF8A939B : 0xFF5A626A));
            }
        }

        // 5. 中心信息 + 顶部全局提示 + 底部提示栏（文字部分）
        drawHub(g, state);
        drawTopBarText(g);
        drawBottomBarText(g);
    }

    /** 几何阶段的三块平色底：中心状态药丸 / 顶部提示条 / 底部提示栏。
     *  状态药丸抬高到 z=200，压在技能名字之上（见 render 里的说明）。 */
    private void drawBarShapes(GuiGraphics g, S2CWheelData state) {
        if (state != null && hovered >= 0) {
            Component status = cacheStatus[hovered];
            int col = statusColor(state, hovered);
            float w = scaledWidth(status, hubW);
            int cxI = (int) cx;
            int y = (int) cy - 12 + cacheDesc[hovered].size() * 10;
            g.pose().pushPose();
            g.pose().translate(0, 0, 200.0F);
            WheelShapes.fillRect(g, cxI - w / 2 - 5, y + 3, cxI + w / 2 + 5, y + 16, 0x50000000 | (col & 0x00FFFFFF));
            g.pose().popPose();
        }
        if (cacheTopVisible) {
            int w = this.font.width(cacheTopText);
            WheelShapes.fillRect(g, this.width / 2 - w / 2 - 6, 8, this.width / 2 + w / 2 + 6, 22, 0x5A0A0D12);
        }
        WheelShapes.fillRect(g, 0, this.height - 20, this.width, this.height, 0x8C05080C);
    }

    /** 中心盘文字：整块抬高一个 z 层（z=250，比状态药丸再高一点），永远压在技能名之上。
     *  文字内容全部读缓存，只在收到新状态包时重建。 */
    private void drawHub(GuiGraphics g, S2CWheelData state) {
        int cxI = (int) cx;
        int cyI = (int) cy;

        g.pose().pushPose();
        g.pose().translate(0, 0, 250.0F);

        if (state == null) {
            g.drawCenteredString(this.font, Component.translatable(KEY_BASE + "status.syncing"),
                    cxI, cyI - 4, 0xFFA0A0A0);
            g.pose().popPose();
            return;
        }

        if (hovered >= 0) {
            // 技能名（用技能本色提亮），太宽自动缩小；优先用配置 wheel.<skill>.name 的自定义名
            drawScaledCentered(g, cacheName[hovered], cxI, cyI - 28, hubW, WheelShapes.brighten(BASE_COLORS[hovered], 0.45F));
            // 描述，自动换行；同样优先配置 wheel.<skill>.desc
            int y = cyI - 12;
            for (FormattedCharSequence line : cacheDesc[hovered]) {
                g.drawCenteredString(this.font, line, cxI, y, 0xFFC8C8C8);
                y += 10;
            }
            // 状态行：底下那层同色半透明底已在几何阶段抬高画好，一眼分清 就绪/冷却/等级不足
            drawScaledCentered(g, cacheStatus[hovered], cxI, y + 6, hubW, statusColor(state, hovered));
        } else {
            // 中心盘内容（标题/统计/操作提示/技能点）全部支持配置 wheel.* 自定义，留空回退内置
            drawScaledCentered(g, cacheCenterTitle, cxI, cyI - 28, hubW, 0xFF67D8EF);
            drawScaledCentered(g, cacheCenterReady, cxI, cyI - 16, hubW, 0xFFC8C8C8);
            int y = cyI - 6;
            for (FormattedCharSequence line : cacheHintLines) {
                g.drawCenteredString(this.font, line, cxI, y, 0xFF79828A);
                y += 10;
            }
            // 技能点余额（记分榜 commander_points，配置里可自定义目标名）
            g.drawCenteredString(this.font, cacheCenterPoints, cxI, Math.min(y + 2, cyI + 26), 0xFFE8C86A);
        }

        g.pose().popPose();
    }

    /**
     * 文字缓存重建：只在收到新的状态包（轮盘打开时每秒一次）或中心盘尺寸变化时执行。
     * 渲染帧里只读缓存，不再每帧重复创建 Component、查语言表和重新换行。
     */
    private void refreshCaches(S2CWheelData state) {
        if (state == cacheState && cacheHubW == hubW) return;
        cacheState = state;
        cacheHubW = hubW;
        for (int i = 0; i < 6; i++) {
            // 名字优先用配置 wheel.<skill>.shortName 的自定义短名，留空回退内置文案
            String shortName = skillField(state, i, 1);
            cacheShort[i] = shortName.isBlank()
                    ? Component.translatable(KEY_BASE + skillKey(i) + ".short")
                    : Component.literal(shortName);
            String customName = skillField(state, i, 0);
            cacheName[i] = customName.isBlank()
                    ? Component.translatable(KEY_BASE + skillKey(i) + ".name")
                    : Component.literal(customName);
            String customDesc = skillField(state, i, 2);
            Component desc = customDesc.isBlank()
                    ? Component.translatable(KEY_BASE + skillKey(i) + ".desc")
                    : Component.literal(customDesc);
            cacheDesc[i] = this.font.split(desc, Math.max(1, hubW));
            cacheCdLabel[i] = Component.literal(String.format("%.1fs", cooldownTicks(state, i) / 20.0));
            cacheStatus[i] = statusOf(state, i);
        }
        S2CWheelData.WheelText t = wheelText(state);
        cacheCenterTitle = text(t.centerTitle(), "title");
        int ready = 0;
        for (int i = 0; i < 6; i++) if (usable(state, i)) ready++;
        String summary = t.centerSummary();
        cacheCenterReady = summary.isBlank()
                ? Component.translatable(KEY_BASE + "summary", ready, 6)
                : Component.literal(fmt(summary, "ready", String.valueOf(ready), "total", "6"));
        cacheHintLines = this.font.split(text(t.centerHint(), "hint.close"), Math.max(1, hubW + 24));
        // 技能点余额行：配置 wheel.centerPoints 可自定义，{points}=当前技能点
        String pointsTpl = t.centerPoints() == null ? "" : t.centerPoints();
        cacheCenterPoints = pointsTpl.isBlank()
                ? Component.translatable(KEY_BASE + "points", state == null ? 0 : state.playerPoints())
                : Component.literal(fmt(pointsTpl, "points", String.valueOf(state == null ? 0 : state.playerPoints())));
        // 顶部全局提示（系统关闭 / 非指挥官）
        cacheTopVisible = false;
        cacheTopText = null;
        cacheTopColor = 0xFFFF5555;
        if (state != null) {
            if (!state.systemEnabled()) {
                cacheTopVisible = true;
                cacheTopText = text(t.statusSystemOff(), "status.systemoff");
            } else if (!state.isCommander()) {
                cacheTopVisible = true;
                cacheTopText = text(t.statusNotCommander(), "status.notcommander");
                cacheTopColor = 0xFFFFAA55;
            }
        }
        cacheBottomText = Component.translatable(KEY_BASE + "hint.use");
    }

    /** 顶部全局提示文字（系统关闭 / 非指挥官），底色条已在几何阶段画好 */
    private void drawTopBarText(GuiGraphics g) {
        if (!cacheTopVisible) return;
        g.drawCenteredString(this.font, cacheTopText, this.width / 2, 12, cacheTopColor);
    }

    /** 底部半透明提示栏文字：怎么用、怎么关 */
    private void drawBottomBarText(GuiGraphics g) {
        g.drawCenteredString(this.font, cacheBottomText,
                this.width / 2, this.height - 15, 0xFF9AA3AB);
    }

    // ==================== 状态判断 ====================

    /** 服务端发来的自定义文案；没收到或为空时返回全空文案（各处会回退到语言文件内置文案） */
    private static S2CWheelData.WheelText wheelText(S2CWheelData state) {
        if (state == null || state.text() == null) return S2CWheelData.WheelText.EMPTY;
        return state.text();
    }

    /** 自定义文案优先；留空回退到语言文件的内置文案 */
    private static Component text(String cfgValue, String langKey) {
        return cfgValue == null || cfgValue.isBlank()
                ? Component.translatable(KEY_BASE + langKey)
                : Component.literal(cfgValue);
    }

    /** {key} 占位符替换，keyValues 依次是 key1, value1, key2, value2… */
    private static String fmt(String template, String... keyValues) {
        String out = template == null ? "" : template;
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            out = out.replace("{" + keyValues[i] + "}", keyValues[i + 1]);
        }
        return out;
    }

    /** 取某个技能的自定义文字：0=完整名，1=短名，2=说明；没有自定义时返回空串 */
    private static String skillField(S2CWheelData state, int i, int which) {
        List<S2CWheelData.SkillText> skills = wheelText(state).skills();
        if (skills == null || i < 0 || i >= skills.size()) return "";
        S2CWheelData.SkillText t = skills.get(i);
        if (t == null) return "";
        return switch (which) {
            case 0 -> t.name() == null ? "" : t.name();
            case 1 -> t.shortName() == null ? "" : t.shortName();
            default -> t.desc() == null ? "" : t.desc();
        };
    }

    /** 一行字在限宽 maxW 内显示时的实际占用宽度（超宽等比缩小后的宽度） */
    private float scaledWidth(Component text, float maxW) {
        float w = this.font.width(text);
        return w > maxW ? maxW : w;
    }

    /** 居中画一行字：太宽超过 maxW 时整体等比缩小（不换行），保证再长的文本也不溢出 */
    private void drawScaledCentered(GuiGraphics g, Component text, float x, float y, float maxW, int color) {
        float w = this.font.width(text);
        if (w > maxW) {
            float s = maxW / w;
            g.pose().pushPose();
            g.pose().translate(x, y, 0);
            g.pose().scale(s, s, 1.0F);
            g.pose().translate(-x, -y, 0);
            g.drawCenteredString(this.font, text, (int) x, (int) y, color);
            g.pose().popPose();
        } else {
            g.drawCenteredString(this.font, text, (int) x, (int) y, color);
        }
    }

    private static boolean usable(S2CWheelData state, int i) {
        if (state == null) return false;
        if (!state.systemEnabled() || !state.isCommander()) return false;
        S2CWheelData.Entry e = state.entries().get(i);
        if (!e.moduleOn() || e.cooldownTicks() > 0) return false;
        if (state.levelLimitActive() && e.requiredLevel() > state.playerLevel()) return false;
        return !state.pointsActive() || e.pointCost() <= state.playerPoints();
    }

    private static int cooldownTicks(S2CWheelData state, int i) {
        if (state == null || !state.entries().get(i).moduleOn()) return 0;
        return Math.max(0, state.entries().get(i).cooldownTicks());
    }

    /** 冷却转盘的占比：剩余冷却 / 打开以来见过的最大冷却；没在冷却返回 0 */
    private float cooldownFraction(S2CWheelData state, int i) {
        int cd = cooldownTicks(state, i);
        if (cd <= 0) {
            cdMax[i] = 0;
            return 0.0F;
        }
        cdMax[i] = Math.max(cdMax[i], cd);
        return cd / (float) cdMax[i];
    }

    private static Component statusOf(S2CWheelData state, int i) {
        S2CWheelData.WheelText t = wheelText(state);
        if (state == null) return Component.translatable(KEY_BASE + "status.syncing");
        if (!state.systemEnabled()) return text(t.statusSystemOff(), "status.systemoff");
        if (!state.isCommander()) return text(t.statusNotCommander(), "status.notcommander");
        S2CWheelData.Entry e = state.entries().get(i);
        if (!e.moduleOn()) return text(t.statusModuleOff(), "status.moduleoff");
        if (e.cooldownTicks() > 0) {
            String secs = String.format("%.1f", e.cooldownTicks() / 20.0);
            return t.statusCooldown().isBlank()
                    ? Component.translatable(KEY_BASE + "status.cooldown", secs)
                    : Component.literal(fmt(t.statusCooldown(), "seconds", secs));
        }
        if (state.levelLimitActive() && e.requiredLevel() > state.playerLevel()) {
            String req = String.valueOf(e.requiredLevel());
            String cur = String.valueOf(state.playerLevel());
            return t.statusLevel().isBlank()
                    ? Component.translatable(KEY_BASE + "status.level", req, cur)
                    : Component.literal(fmt(t.statusLevel(), "required", req, "current", cur));
        }
        if (state.pointsActive() && e.pointCost() > state.playerPoints()) {
            String cost = String.valueOf(e.pointCost());
            String cur = String.valueOf(state.playerPoints());
            return t.statusPoints().isBlank()
                    ? Component.translatable(KEY_BASE + "status.points", cost, cur)
                    : Component.literal(fmt(t.statusPoints(), "cost", cost, "current", cur));
        }
        // 连发惩罚生效中：就绪但消耗按倍率加倍（消耗数已含惩罚，见 Entry.pointCost）
        if (state.penaltyActive()) {
            String mult = String.valueOf(Math.max(1, state.penaltyMult()));
            return t.statusPenalty().isBlank()
                    ? Component.translatable(KEY_BASE + "status.penalty", mult)
                    : Component.literal(fmt(t.statusPenalty(), "mult", mult));
        }
        return text(t.statusReady(), "status.ready");
    }

    private static int statusColor(S2CWheelData state, int i) {
        if (state == null) return 0xFFA0A0A0;
        if (!state.systemEnabled() || !state.isCommander()) return 0xFFE86A6A;
        S2CWheelData.Entry e = state.entries().get(i);
        if (!e.moduleOn()) return 0xFFE86A6A;
        if (e.cooldownTicks() > 0) return 0xFFE8C86A;
        if (state.levelLimitActive() && e.requiredLevel() > state.playerLevel()) return 0xFFE8A05A;
        if (state.pointsActive() && e.pointCost() > state.playerPoints()) return 0xFFE86A9A;
        if (state.penaltyActive()) return 0xFFE8C86A;
        return 0xFF7EE87E;
    }

    private static String skillKey(int i) {
        return cn.blockforge.generated.nbt6commandervotesta.core.ModNetwork.SKILLS[i];
    }

    // ==================== 交互 ====================

    private int pickSector(double mx, double my) {
        double dx = mx - cx;
        double dy = my - cy;
        double dist = Math.sqrt(dx * dx + dy * dy);
        // 外圈槽位（数字键/冷却倒计时）也算进命中范围，方便悬停时在中心盘看该技能状态
        if (dist < innerR || dist > outerR + 16.0) return -1;
        double rel = Math.toDegrees(Math.atan2(dy, dx)) + 90.0; // 0 = 正上方
        if (rel < 0) rel += 360.0;
        return ((int) (rel / 60.0)) % 6;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && hovered >= 0) {
            use(hovered);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // 再按一次轮盘键（默认 V）= 关闭轮盘。
        // 轮盘开着时键盘输入只走这里（Screen.keyPressed），不再累计到 KeyMapping 的点击计数，
        // 所以关闭必须在这里判断，靠 WheelClient 的 tick 轮询是收不到这个键的。
        if (ClientSetup.WHEEL_KEY.matches(keyCode, scanCode)) {
            Minecraft.getInstance().setScreen(null);
            return true;
        }
        // 数字键 1-6 直接使用对应技能
        if (keyCode >= GLFW.GLFW_KEY_1 && keyCode <= GLFW.GLFW_KEY_6) {
            use(keyCode - GLFW.GLFW_KEY_1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void use(int index) {
        Minecraft.getInstance().getSoundManager()
                .play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        String skill = cn.blockforge.generated.nbt6commandervotesta.core.ModNetwork.SKILLS[index];
        // 炮击 / 空投 / 雾墙：先瞄准，左键确认才真正释放（服务端再过一遍所有检查）
        S2CWheelData state = WheelClient.state();
        String name = cacheName(index);
        if (skill.equals("airdrop")) {
            // 空投先弹 2 级菜单选物资类型，选完再瞄准
            List<S2CWheelData.AirdropType> types = state == null || state.airdropTypes() == null
                    ? List.of() : state.airdropTypes();
            Minecraft.getInstance().setScreen(null);
            if (types.isEmpty()) {
                // 服务端没配类型清单：按默认类型直接瞄准
                AimClient.start("airdrop", name, "", 32.0, 3.0, 0.0, false);
            } else {
                Minecraft.getInstance().setScreen(new AirdropSelectScreen(types));
            }
            return;
        }
        if (skill.equals("artillery") && state != null && !state.artilleryToolkit()) {
            Minecraft.getInstance().setScreen(null);
            AimClient.start("artillery", name, "", 128.0, 0.0, 0.0, false);
            return;
        }
        if (skill.equals("smoke")) {
            double range = state == null ? 32.0 : state.smokeRange();
            double up = state == null ? 3.0 : state.smokeUpOffset();
            double radius = state == null ? 3.0 : state.smokePreviewRadius();
            Minecraft.getInstance().setScreen(null);
            AimClient.start("smoke", name, "", range, up, radius, state == null || state.smokeBlockWalls());
            return;
        }
        WheelClient.sendUse(skill);
        // 选完技能自动关闭轮盘（服务端会另行判定冷却/等级并给出提示）
        Minecraft.getInstance().setScreen(null);
    }

    /** 悬停技能的显示名（纯文本）：自定义名优先，否则用语言文件的内置名 */
    private String cacheName(int index) {
        String custom = skillField(WheelClient.state(), index, 0);
        Component c = custom.isBlank()
                ? Component.translatable(KEY_BASE + skillKey(index) + ".name")
                : Component.literal(custom);
        return c.getString();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ==================== 矢量图标（每个技能一个，纯线条/圆点拼出） ====================

    private void drawIcon(GuiGraphics g, int skill, float x, float y, int color) {
        switch (skill) {
            case 0 -> { // 侦察扫描：雷达 / 放大镜
                WheelShapes.strokeCircle(g, x - 1.0F, y - 1.0F, 3.2F, color, 1.1F);
                WheelShapes.drawLine(g, x + 1.3F, y + 1.3F, x + 4.2F, y + 4.2F, 1.2F, color);
                WheelShapes.fillCircle(g, x - 1.0F, y - 1.0F, 0.9F, color);
            }
            case 1 -> { // 空投补给：降落伞 + 吊着的箱子
                WheelShapes.drawLine(g, x - 4.6F, y - 0.8F, x, y - 3.8F, 1.2F, color);
                WheelShapes.drawLine(g, x, y - 3.8F, x + 4.6F, y - 0.8F, 1.2F, color);
                WheelShapes.drawLine(g, x - 4.6F, y - 0.8F, x - 2.0F, y + 2.6F, 0.9F, color);
                WheelShapes.drawLine(g, x + 4.6F, y - 0.8F, x + 2.0F, y + 2.6F, 0.9F, color);
                WheelShapes.drawLine(g, x - 2.0F, y + 2.6F, x + 2.0F, y + 2.6F, 1.1F, color);
                WheelShapes.drawLine(g, x + 2.0F, y + 2.6F, x + 2.0F, y + 5.6F, 1.1F, color);
                WheelShapes.drawLine(g, x + 2.0F, y + 5.6F, x - 2.0F, y + 5.6F, 1.1F, color);
                WheelShapes.drawLine(g, x - 2.0F, y + 5.6F, x - 2.0F, y + 2.6F, 1.1F, color);
            }
            case 2 -> { // 战术雾墙：三团云 + 地面线
                WheelShapes.fillCircle(g, x - 3.2F, y + 0.4F, 2.1F, color);
                WheelShapes.fillCircle(g, x, y - 1.6F, 2.7F, color);
                WheelShapes.fillCircle(g, x + 3.2F, y + 0.4F, 2.1F, color);
                WheelShapes.drawLine(g, x - 5.0F, y + 3.4F, x + 5.0F, y + 3.4F, 1.0F, color);
            }
            case 3 -> { // 炮击支援：准星
                WheelShapes.strokeCircle(g, x, y, 3.4F, color, 1.1F);
                WheelShapes.drawLine(g, x, y - 6.2F, x, y - 3.4F, 1.1F, color);
                WheelShapes.drawLine(g, x, y + 3.4F, x, y + 6.2F, 1.1F, color);
                WheelShapes.drawLine(g, x - 6.2F, y, x - 3.4F, y, 1.1F, color);
                WheelShapes.drawLine(g, x + 3.4F, y, x + 6.2F, y, 1.1F, color);
                WheelShapes.fillCircle(g, x, y, 0.9F, color);
            }
            case 4 -> { // 全军突击：向上的箭头
                WheelShapes.drawLine(g, x, y + 5.0F, x, y - 3.0F, 1.3F, color);
                WheelShapes.arrowHead(g, x, y - 4.6F, 0.0F, -1.0F, 3.4F, color);
            }
            default -> { // 战略撤退：斜向左下的箭头
                WheelShapes.drawLine(g, x + 3.8F, y - 3.8F, x - 2.6F, y + 2.6F, 1.3F, color);
                WheelShapes.arrowHead(g, x - 4.0F, y + 4.0F, -0.7071F, 0.7071F, 3.4F, color);
            }
        }
    }

}
