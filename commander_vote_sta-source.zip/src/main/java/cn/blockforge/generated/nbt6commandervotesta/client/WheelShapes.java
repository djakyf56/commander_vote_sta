package cn.blockforge.generated.nbt6commandervotesta.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

/**
 * 技能轮盘（1 级技能轮盘 / 2 级空投资源轮盘）共用的纯代码绘制工具。
 * 不使用任何贴图，全部几何攒进"整帧一个顶点批次"再一次性提交：
 * 以前每个小图形各自 begin/end 一次，一帧几百次提交是最大的性能开销，
 * 抽成公共工具后两个轮盘都保持整帧只有一次提交。
 */
public final class WheelShapes {

    private WheelShapes() {
    }

    /** 开启本帧几何批次：渲染状态只设置一次，后面所有纯色图形都攒进同一个顶点缓冲 */
    public static void startBatch() {
        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        buf.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
    }

    /** 结束本帧几何批次：整帧攒下的全部图形一次性提交给显卡 */
    public static void endBatch() {
        Tesselator.getInstance().end();
        RenderSystem.enableCull();
    }

    /** 用三角形拼出一个圆环扇区（不含贴图，纯顶点颜色） */
    public static void fillSector(GuiGraphics g, float cx, float cy,
                                  float r0, float r1, float a0Deg, float a1Deg, int argb) {
        fillSectorGradient(g, cx, cy, r0, r1, a0Deg, a1Deg, argb, argb);
    }

    /** 扇区支持内/外两圈不同颜色：内圈压暗、外圈提亮，做出由内向外的渐变 */
    public static void fillSectorGradient(GuiGraphics g, float cx, float cy,
                                          float r0, float r1, float a0Deg, float a1Deg,
                                          int argbInner, int argbOuter) {
        Matrix4f m = g.pose().last().pose();
        float a0 = (float) Math.toRadians(a0Deg);
        float a1 = (float) Math.toRadians(a1Deg);
        int steps = Math.max(2, (int) Math.ceil((a1Deg - a0Deg) / 6.0F));
        for (int s = 0; s < steps; s++) {
            float ta = a0 + (a1 - a0) * s / steps;
            float tb = a0 + (a1 - a0) * (s + 1) / steps;
            addQuad(m, cx, cy, r0, r1, ta, tb, argbInner, argbOuter);
        }
    }

    /** 实心圆 = 从圆心到外缘的完整扇区 */
    public static void fillCircle(GuiGraphics g, float cx, float cy, float r, int argb) {
        fillSector(g, cx, cy, 0.0F, r, 0.0F, 360.0F, argb);
    }

    /** 矩形色块（两个三角形）。不用 GuiGraphics.fill 是因为它要自己开一次顶点缓冲，
     *  会和本帧的几何批次撞车（同一个 Tesselator 缓冲不能同时 begin 两次）。 */
    public static void fillRect(GuiGraphics g, float x0, float y0, float x1, float y1, int argb) {
        Matrix4f m = g.pose().last().pose();
        vertex(m, x0, y0, argb);
        vertex(m, x1, y0, argb);
        vertex(m, x1, y1, argb);
        vertex(m, x0, y0, argb);
        vertex(m, x1, y1, argb);
        vertex(m, x0, y1, argb);
    }

    /** 一条有粗细的线段（旋转的四边形），用来拼矢量图标 */
    public static void drawLine(GuiGraphics g, float x0, float y0, float x1, float y1, float w, int argb) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0E-4F) return;
        float px = -dy / len * w * 0.5F;
        float py = dx / len * w * 0.5F;
        Matrix4f m = g.pose().last().pose();
        vertex(m, x0 + px, y0 + py, argb);
        vertex(m, x1 + px, y1 + py, argb);
        vertex(m, x1 - px, y1 - py, argb);
        vertex(m, x0 + px, y0 + py, argb);
        vertex(m, x1 - px, y1 - py, argb);
        vertex(m, x0 - px, y0 - py, argb);
    }

    /** 圆环：用一圈短线段拼出来 */
    public static void strokeCircle(GuiGraphics g, float cx, float cy, float r, int color, float width) {
        int seg = 14;
        float px = cx, py = cy + r;
        for (int i = 1; i <= seg; i++) {
            double a = Math.PI * 2 * i / seg;
            float nx = cx + (float) Math.cos(a) * r;
            float ny = cy + (float) Math.sin(a) * r;
            drawLine(g, px, py, nx, ny, width, color);
            px = nx;
            py = ny;
        }
    }

    /** 箭头头部：从箭尖出发的两条短斜线 */
    public static void arrowHead(GuiGraphics g, float tipX, float tipY, float dx, float dy, float size, int color) {
        double ang = Math.atan2(dy, dx) + Math.PI;
        float a1 = (float) (ang + Math.toRadians(32));
        float a2 = (float) (ang - Math.toRadians(32));
        drawLine(g, tipX, tipY, tipX + (float) Math.cos(a1) * size, tipY + (float) Math.sin(a1) * size, 1.2F, color);
        drawLine(g, tipX, tipY, tipX + (float) Math.cos(a2) * size, tipY + (float) Math.sin(a2) * size, 1.2F, color);
    }

    public static void vertex(Matrix4f m, float x, float y, int argb) {
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >>> 16) & 0xFF;
        int gr = (argb >>> 8) & 0xFF;
        int bl = argb & 0xFF;
        Tesselator.getInstance().getBuilder().vertex(m, x, y, 0.0F).color(r, gr, bl, a).endVertex();
    }

    private static void addQuad(Matrix4f m, float cx, float cy,
                                float r0, float r1, float ta, float tb, int argbInner, int argbOuter) {
        float x0 = cx + (float) Math.cos(ta) * r0;
        float y0 = cy + (float) Math.sin(ta) * r0;
        float x1 = cx + (float) Math.cos(ta) * r1;
        float y1 = cy + (float) Math.sin(ta) * r1;
        float x2 = cx + (float) Math.cos(tb) * r1;
        float y2 = cy + (float) Math.sin(tb) * r1;
        float x3 = cx + (float) Math.cos(tb) * r0;
        float y3 = cy + (float) Math.sin(tb) * r0;
        vertex(m, x0, y0, argbInner);
        vertex(m, x1, y1, argbOuter);
        vertex(m, x2, y2, argbOuter);
        vertex(m, x0, y0, argbInner);
        vertex(m, x2, y2, argbOuter);
        vertex(m, x3, y3, argbInner);
    }

    /** 把颜色向白色方向提亮 f（0~1），用作悬停高亮 */
    public static int brighten(int argb, float f) {
        int a = (argb >>> 24) & 0xFF;
        int r = (int) (((argb >>> 16) & 0xFF) + (255 - ((argb >>> 16) & 0xFF)) * f);
        int gr = (int) (((argb >>> 8) & 0xFF) + (255 - ((argb >>> 8) & 0xFF)) * f);
        int b = (int) ((argb & 0xFF) + (255 - (argb & 0xFF)) * f);
        return (a << 24) | (r << 16) | (gr << 8) | b;
    }

    /** 把颜色整体乘一个系数压暗（0~1），用作扇区内侧渐变 */
    public static int shade(int argb, float f) {
        int a = (argb >>> 24) & 0xFF;
        int r = (int) (((argb >>> 16) & 0xFF) * f);
        int gr = (int) (((argb >>> 8) & 0xFF) * f);
        int b = (int) ((argb & 0xFF) * f);
        return (a << 24) | (r << 16) | (gr << 8) | b;
    }

    /** 把一个颜色的 alpha 乘以 f（0~1），用于描边随动画淡入 */
    public static int withAlpha(float f) {
        int a = (int) (0xFF * Math.max(0.0F, Math.min(1.0F, f)));
        return a << 24;
    }
}
