package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.client.CameraShakeClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 服务端 -> 客户端：一发炮弹在 (玩家附近) 爆炸，请让摄像机晃一下。
 * 只影响渲染（客户端改相机角度），不改任何游戏数值，玩家也不会被"推"。
 * strength = 0~1 的强度（爆心附近接近 1，远处更小），durationTicks = 持续多少 tick。
 */
public record S2CCameraShake(float strength, int durationTicks) {

    public S2CCameraShake(FriendlyByteBuf buf) {
        this(buf.readFloat(), buf.readVarInt());
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeFloat(Math.max(0.0F, Math.min(4.0F, strength)));
        buf.writeVarInt(Math.max(1, Math.min(400, durationTicks)));
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        // 只在客户端执行：把这次的强度交给 CameraShakeClient（多次爆炸取最强的一次）
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> CameraShakeClient.apply(strength, durationTicks)));
        ctx.get().setPacketHandled(true);
    }
}
