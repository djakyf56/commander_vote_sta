package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** 本模组的网络通道：技能轮盘的两个包（状态下发 / 操作上行）。 */
public final class ModNetwork {

    private static final String PROTOCOL = "3";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            GeneratedMod.id("main"), () -> PROTOCOL, v -> true, v -> true);

    /** 轮盘上六个技能的固定顺序（客户端按这个顺序编号 1-6） */
    public static final String[] SKILLS = {"scan", "airdrop", "smoke", "artillery", "assault", "retreat"};

    private ModNetwork() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(C2SWheelAction.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(C2SWheelAction::encode)
                .decoder(C2SWheelAction::new)
                .consumerMainThread(C2SWheelAction::handle)
                .add();
        CHANNEL.messageBuilder(S2CWheelData.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(S2CWheelData::encode)
                .decoder(S2CWheelData::new)
                .consumerMainThread(S2CWheelData::handle)
                .add();
        // 炮击落地时的摄像机摇晃（纯渲染，不发任何游戏数值）
        CHANNEL.messageBuilder(S2CCameraShake.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(S2CCameraShake::encode)
                .decoder(S2CCameraShake::new)
                .consumerMainThread(S2CCameraShake::handle)
                .add();
    }

    /** 从服务端配置与冷却表里组装一份轮盘状态，回给发起请求的玩家 */
    public static void replyWheelData(ServerPlayer player, Supplier<NetworkEvent.Context> ctx) {
        CommanderSavedData data = CommanderSavedData.get(player.server);
        cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig cfg =
                cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.INSTANCE;
        boolean levelLimitActive = cfg.levels.enabled && data.isLevelLimitEnabled();
        boolean pointsActive = cfg.skillPoints != null && cfg.skillPoints.enabledSafe();
        boolean penalized = SkillManager.isPenalized(player);
        double penaltyMult = cfg.penalty.enabled ? Math.max(1.0, cfg.penalty.multiplier) : 1.0;
        boolean artilleryToolkit = "toolkit".equalsIgnoreCase(cfg.artillery.mode);
        int globalRemain = TickHandler.cooldownRemaining(player, "global");

        List<S2CWheelData.Entry> entries = new ArrayList<>();
        for (String skill : SKILLS) {
            int cd = Math.max(TickHandler.cooldownRemaining(player, skill), globalRemain);
            int cost = 0;
            if (pointsActive) {
                cost = cfg.requiredPoints(skill);
                if (penalized) cost = (int) Math.ceil(cost * penaltyMult);
            }
            entries.add(new S2CWheelData.Entry(
                    cfg.moduleEnabled(skill),
                    levelLimitActive ? cfg.requiredLevel(skill) : 0,
                    cd,
                    cost));
        }

        // 空投 2 级菜单的物资类型清单（客户端只显示，选择后把 id 发回来）
        List<S2CWheelData.AirdropType> types = new ArrayList<>();
        if (cfg.airdrop.types != null) {
            for (cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.SupplyTypeEntry t : cfg.airdrop.types) {
                if (t == null || t.id == null || t.id.isBlank()) continue;
                String name = t.name == null || t.name.isBlank() ? t.id : t.name;
                String desc = t.desc == null ? "" : t.desc;
                boolean hasEntity = t.entity != null && !t.entity.isBlank();
                types.add(new S2CWheelData.AirdropType(t.id.trim(), name, desc, hasEntity));
            }
        }

        // 瞄准模式（雾墙预览）需要的客户端参数
        cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.SmokeCfg sm = cfg.smoke;
        float previewRadius;
        if (sm.count > 0) {
            previewRadius = (float) (((Math.min(sm.count - 1, 32)) / 2.0) * Math.max(0.5, sm.spreadStep));
        } else {
            previewRadius = (float) (sm.width / 2.0);
        }

        S2CWheelData msg = new S2CWheelData(
                data.isEnabled(),
                data.isCommander(player.getUUID()),
                levelLimitActive,
                SkillManager.currentLevel(player),
                pointsActive,
                SkillManager.currentPoints(player),
                penalized && pointsActive,
                (int) Math.max(1, Math.round(penaltyMult)),
                artilleryToolkit,
                (float) Math.max(2.0, sm.spawnRange),
                (float) Math.max(0.0, sm.upOffset),
                Math.max(0.0F, previewRadius),
                sm.blockWalls,
                // 炮击预览要用的参数（画散布圈 / 来袭方向用）
                (float) Math.max(0.0, cfg.artillery.scatter),
                !"scatter".equalsIgnoreCase(trimLanding(cfg.artillery.landing)),
                Math.max(0, cfg.artillery.strikes),
                SkillManager.isMortarApproach(cfg.artillery.approach),
                (float) Math.max(15.0, Math.min(80.0, cfg.artillery.mortarAngle)),
                mortarYawForClient(cfg.artillery.mortarBearing),
                entries,
                types,
                wheelText(cfg));
        CHANNEL.reply(msg, ctx.get());
    }

    /** 落点方式的原始写法（null 时按默认的 scatter 处理） */
    private static String trimLanding(String s) {
        return s == null ? "scatter" : s.trim().toLowerCase(java.util.Locale.ROOT);
    }

    /**
     * 客户端预览要用的来袭方位：配置写死 south/west/north/east 时给对应的固定角度；
     * 写"跟视线"（look）时传 NaN，让客户端按自己当时的视线折算——和真正释放时服务端
     * 按指挥官视线结算的规则一致，预览指向哪、炮弹就从哪来。
     */
    private static float mortarYawForClient(String bearing) {
        String s = bearing == null ? "look" : bearing.trim().toLowerCase(java.util.Locale.ROOT);
        return switch (s) {
            case "south", "from_south", "s" -> 0.0F;
            case "west", "from_west", "w" -> 90.0F;
            case "north", "from_north", "n" -> 180.0F;
            case "east", "from_east", "e" -> -90.0F;
            default -> Float.NaN; // 跟视线：客户端自己算
        };
    }

    /** 把配置 wheel 一节的自定义文案打包给客户端；空串=客户端回退到内置文案 */
    private static S2CWheelData.WheelText wheelText(cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig cfg) {
        cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.WheelCfg w = cfg.wheel;
        if (w == null) w = new cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.WheelCfg();
        List<S2CWheelData.SkillText> skills = new ArrayList<>(SKILLS.length);
        for (String skill : SKILLS) {
            cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.SkillText t = skillText(w, skill);
            if (t == null) t = new cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.SkillText();
            skills.add(new S2CWheelData.SkillText(orEmpty(t.name), orEmpty(t.shortName), orEmpty(t.desc)));
        }
        return new S2CWheelData.WheelText(
                orEmpty(w.centerTitle), orEmpty(w.centerSummary), orEmpty(w.centerHint),
                orEmpty(w.centerPoints),
                orEmpty(w.statusReady), orEmpty(w.statusCooldown), orEmpty(w.statusLevel),
                orEmpty(w.statusPoints), orEmpty(w.statusPenalty),
                orEmpty(w.statusModuleOff), orEmpty(w.statusNotCommander), orEmpty(w.statusSystemOff),
                skills);
    }

    private static cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.SkillText skillText(
            cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.WheelCfg w, String skill) {
        return switch (skill) {
            case "scan" -> w.scan;
            case "airdrop" -> w.airdrop;
            case "smoke" -> w.smoke;
            case "artillery" -> w.artillery;
            case "assault" -> w.assault;
            case "retreat" -> w.retreat;
            default -> new cn.blockforge.generated.nbt6commandervotesta.config.CommanderConfig.SkillText();
        };
    }

    private static String orEmpty(String s) {
        return s == null ? "" : s;
    }
}
