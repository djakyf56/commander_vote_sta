package cn.blockforge.generated.nbt6commandervotesta.core;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.scores.PlayerTeam;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 指挥官系统的持久数据：谁是指挥官、系统开关、等级限制开关。随世界保存。 */
public class CommanderSavedData extends SavedData {
    public static final String DATA_NAME = "commander_system";

    /** 指挥官：UUID -> 授予时的玩家名（旧存档可能没有名字，为 null）。名字用于离线也能查到他所在队伍。 */
    private final Map<UUID, String> commanders = new LinkedHashMap<>();
    private boolean enabled = true;
    private boolean levelLimitEnabled = true;

    public static CommanderSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                CommanderSavedData::load, CommanderSavedData::new, DATA_NAME);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean v) {
        enabled = v;
        setDirty();
    }

    public boolean isLevelLimitEnabled() {
        return levelLimitEnabled;
    }

    public void setLevelLimitEnabled(boolean v) {
        levelLimitEnabled = v;
        setDirty();
    }

    public boolean isCommander(UUID id) {
        return commanders.containsKey(id);
    }

    public void addCommander(UUID id, String name) {
        commanders.put(id, name);
        setDirty();
    }

    public void removeCommander(UUID id) {
        commanders.remove(id);
        setDirty();
    }

    public void clearCommanders() {
        commanders.clear();
        setDirty();
    }

    public Set<UUID> commanders() {
        return commanders.keySet();
    }

    /**
     * 指定队伍（按记分板队伍 id 匹配）当前是否已有别的指挥官。
     * 优先用授予时记下的玩家名去查 scoreboard 成员表，离线玩家也能查到；
     * 没有记录名字的老数据则退回按在线玩家当前队伍判断。
     *
     * @param exclude 排除的 UUID（通常是候选人自己），可为 null
     */
    public boolean hasCommanderInTeam(MinecraftServer server, String teamId, UUID exclude) {
        if (teamId == null) return false;
        for (Map.Entry<UUID, String> e : commanders.entrySet()) {
            if (exclude != null && e.getKey().equals(exclude)) continue;
            String name = e.getValue();
            if (name == null || name.isEmpty()) {
                ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
                if (p != null) name = p.getScoreboardName();
            }
            if (name == null || name.isEmpty()) continue;
            PlayerTeam team = server.getScoreboard().getPlayersTeam(name);
            if (team != null && teamId.equals(team.getName())) return true;
        }
        return false;
    }

    public static CommanderSavedData load(CompoundTag tag) {
        CommanderSavedData data = new CommanderSavedData();
        data.enabled = !tag.contains("Enabled") || tag.getBoolean("Enabled");
        data.levelLimitEnabled = !tag.contains("LevelLimit") || tag.getBoolean("LevelLimit");
        ListTag list = tag.getList("Commanders", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            String entry = list.getString(i);
            try {
                int sep = entry.indexOf('|');
                if (sep >= 0) { // 新格式 "uuid|玩家名"
                    data.commanders.put(UUID.fromString(entry.substring(0, sep)), entry.substring(sep + 1));
                } else { // 旧格式只有 uuid
                    data.commanders.put(UUID.fromString(entry), null);
                }
            } catch (IllegalArgumentException ignored) {
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("Enabled", enabled);
        tag.putBoolean("LevelLimit", levelLimitEnabled);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, String> e : commanders.entrySet()) {
            list.add(StringTag.valueOf(e.getValue() == null || e.getValue().isEmpty()
                    ? e.getKey().toString()
                    : e.getKey() + "|" + e.getValue()));
        }
        tag.put("Commanders", list);
        return tag;
    }
}