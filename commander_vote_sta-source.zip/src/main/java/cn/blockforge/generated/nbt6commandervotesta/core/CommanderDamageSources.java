package cn.blockforge.generated.nbt6commandervotesta.core;

import cn.blockforge.generated.nbt6commandervotesta.GeneratedMod;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * 炮击专用的伤害类型：不再是原版的爆炸伤害，而是数据包里自建的
 * {@code nbt_6_commander_vote_sta:commander_artillery}。
 *
 * <ul>
 *   <li>死亡信息绑在这个伤害类型上（death.attack.commander_artillery.*，可在语言文件里改）。</li>
 *   <li>加入了原版标签 {@code minecraft:is_explosion}（爆炸）——所以防爆护甲、
 *       摔落/爆炸相关的原版判定照常认它。</li>
 *   <li>加入了原版标签 {@code minecraft:bypasses_cooldown}（无视无敌帧）——连发炮弹
 *       即使落在同一小段时间内，每一发都全额扣血，不会被无敌帧吞掉伤害。</li>
 * </ul>
 */
public final class CommanderDamageSources {

    /** 数据包里定义的伤害类型 id：data/nbt_6_commander_vote_sta/damage_type/commander_artillery.json */
    public static final ResourceKey<DamageType> COMMANDER_ARTILLERY =
            ResourceKey.create(Registries.DAMAGE_TYPE, GeneratedMod.id("commander_artillery"));

    private CommanderDamageSources() {
    }

    /**
     * 造一个炮击伤害源。causingEntity = 指挥官，所以击杀者统计、战利品判定都记在指挥官头上；
     * 死亡消息由下面的匿名子类自己拼，保证带指挥官名字。
     * 万一伤害类型 JSON 丢了（极端情况），退回原版爆炸伤害，保证不会崩。
     */
    public static DamageSource artillery(ServerLevel level, Entity commander) {
        return new DamageSource(holder(level), commander, commander) {
            @Override
            public Component getLocalizedDeathMessage(LivingEntity victim) {
                if (getEntity() != null) {
                    // 死亡界面版：这份文案只发给"被炮击死的那名玩家"本人（第二人称）。
                    // 聊天框里给所有人看的第三人称版由客户端事件把同一条消息换掉，
                    // 见 client/DeathChatClient（原版里聊天和死亡界面共用这一条）。
                    // 语言键：death.attack.commander_artillery.screen
                    return Component.translatable("death.attack.commander_artillery.screen",
                            victim.getDisplayName(), getEntity().getDisplayName());
                }
                return super.getLocalizedDeathMessage(victim);
            }
        };
    }

    /** 从世界的伤害类型注册表里取我们的类型；取不到就退回原版爆炸 */
    private static Holder<DamageType> holder(ServerLevel level) {
        return level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(COMMANDER_ARTILLERY)
                .orElseGet(() -> level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                        .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE,
                                new net.minecraft.resources.ResourceLocation("minecraft", "explosion"))));
    }
}
